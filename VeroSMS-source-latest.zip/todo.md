# MGO Panel feature tracker

## Completed

- Fixed range deletion by detaching historical CDR foreign keys and removing dependent range-limit rows before deleting numbers and the range.
- Added the Return Number page for returning selected numbers or a quantity from a selected agent to the available pool.
- Added explicit agent block/unblock labeling using the existing status control.
- Added automatic low-traffic return: every ten minutes, numbers assigned for at least one hour with fewer than 20 received SMS are returned to the pool and logged.
- Added the `test` account bootstrap (`username: test`, `password: test123`) and automatic synchronization of each range's configured test number to that account.
- Redacted message content for the Test account while retaining number, sender, range, and time details.
- Added admin API key enable, rotation, and revoke controls plus endpoint documentation. Users can connect their own bots or applications using the key; the panel does not register or manage bots.

## Validation

- Python compilation passes.
- Flask route smoke test confirms `/api/sms/ranges`, `/api-access`, and `/sms/numbers/return` are registered.
- No Telegram bot registration model or route remains.

- Unit tests pass: 3 tests covering route registration, Test number synchronization, and automatic low-traffic return.
