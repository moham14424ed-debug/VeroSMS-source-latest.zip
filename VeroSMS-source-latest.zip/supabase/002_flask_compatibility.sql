-- Run this once after the initial Supabase schema.
-- The existing Flask application uses the status value 'activated'.
-- This migration keeps that value valid in Supabase.

alter table public.sms_numbers
    drop constraint if exists valid_number_status;

alter table public.sms_numbers
    add constraint valid_number_status
    check (
        status in (
            'available',
            'reserved',
            'assigned',
            'active',
            'activated',
            'blocked',
            'inactive'
        )
    );

-- Verify the constraint-compatible values currently in use.
select status, count(*)
from public.sms_numbers
group by status
order by status;
