import "dotenv/config";
import { spawn } from "child_process";
import { existsSync } from "fs";
import { resolve } from "path";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createProxyMiddleware } from "http-proxy-middleware";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startLegacyFlask(): Promise<number> {
  const flaskPort = Number(process.env.FLASK_PORT || "5050");
  const flaskDir = `${process.cwd()}/legacy_flask`;
  const configuredPython = process.env.PYTHON_BIN || "python3";
  // Prefer the project venv in preview; production uses the Docker venv.
  // Flask's SQLAlchemy config normalizes PostgreSQL to psycopg2.
  const localPython = resolve(process.cwd(), ".venv/bin/python");
  const pythonBin = configuredPython === "python3" && existsSync(localPython)
    ? localPython
    : configuredPython !== "python3" && !existsSync(configuredPython)
      ? "python3"
      : configuredPython;
  const child = spawn(pythonBin, ["run.py"], {
    cwd: flaskDir,
    env: { ...process.env, PORT: String(flaskPort), PYTHONUNBUFFERED: "1" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let childError = "";
  let childOutput = "";
  let spawnError = "";
  child.stdout?.on("data", chunk => {
    childOutput += chunk.toString();
  });
  child.stderr?.on("data", chunk => {
    childError += chunk.toString();
  });
  child.on("error", error => {
    spawnError = error instanceof Error ? error.message : String(error);
  });
  const stopChild = () => {
    if (!child.killed) child.kill("SIGTERM");
  };
  process.once("SIGTERM", stopChild);
  process.once("SIGINT", stopChild);
  const deadline = Date.now() + 20_000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) {
      const diagnostics = [spawnError, childError.trim(), childOutput.trim()]
        .filter(Boolean)
        .join("\n");
      throw new Error(
        `Flask process exited before readiness (code ${child.exitCode}, python ${pythonBin})` +
        (diagnostics ? `: ${diagnostics}` : "")
      );
    }
    try {
      const response = await fetch(`http://127.0.0.1:${flaskPort}/login`);
      if (response.ok) return flaskPort;
    } catch {
      // Flask is still booting; retry briefly without exposing a second port.
    }
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  stopChild();
  throw new Error(`Flask process did not become ready within 20 seconds${childError ? `: ${childError.trim()}` : ""}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  if (process.env.LEGACY_FLASK === "true") {
    const flaskPort = await startLegacyFlask();
    app.use(
      "/",
      createProxyMiddleware({
        target: `http://127.0.0.1:${flaskPort}`,
        changeOrigin: false,
        xfwd: true,
      })
    );
    const preferredPort = parseInt(process.env.PORT || "3000");
    server.listen(preferredPort, () => {
      console.log(`Server running on http://localhost:${preferredPort}/`);
    });
    return;
  }
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
