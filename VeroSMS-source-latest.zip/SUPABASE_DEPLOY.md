# تشغيل MGO Panel مع Supabase

هذا التحديث يضيف زر **Add Number** إلى صفحة Users في لوحة الإدارة، والنسخة الحالية تحتوي على اتصال Supabase داخل إعدادات Flask كما طُلب للنشر المباشر.

## 1. متغير الاتصال

يمكن استخدام متغير البيئة التالي عند النشر الآمن، وسيغلب على الاتصال المضمّن داخل الإعدادات:

```env
DATABASE_URL=postgresql://postgres:YOUR_DATABASE_PASSWORD@db.wtwjwqecxyoflujpgowm.supabase.co:5432/postgres?sslmode=require
FLASK_CONFIG=production
SESSION_COOKIE_SECURE=true
SECRET_KEY=ضع_قيمة_عشوائية_طويلة_هنا
```

لا تضع أقواسًا مربعة حول كلمة المرور ولا ترفع ملف `.env` إلى Git.

## 2. SQL

تم تنفيذ المخطط الأساسي في Supabase. إذا كانت قاعدة البيانات تحتوي على القيد `valid_number_status` من المخطط السابق، شغّل محتوى الملف التالي مرة واحدة من SQL Editor:

```text
supabase/002_flask_compatibility.sql
```

هذا يسمح بالقيمة `activated` التي يستخدمها التطبيق الحالي.

## 3. طريقة الاستخدام

1. افتح لوحة الإدارة.
2. اذهب إلى **Users**.
3. بجانب مستخدم من نوع Agent أو Client اضغط **Add Number**.
4. اختر الـ Range.
5. اكتب عدد الأرقام.
6. اضغط **Add Numbers**.

يأخذ التطبيق أرقامًا متاحة فقط من الـ Range المحدد، ويمنع إعادة تخصيص الأرقام التي تم تخصيصها لمستخدم آخر.

- المستخدم من نوع `agent` يحصل على الأرقام في `agent_id`.
- المستخدم من نوع `client` يحصل على الأرقام في `client_id`.
- أرقام العميل تظهر في **My Numbers**.
- أرقام الوكيل تظهر في **My Numbers** الخاصة بالوكيل.

## 4. النسخ الاحتياطي

استخدم Supabase Dashboard للنسخ الاحتياطي أو تصدير الجداول. التقرير التالي يعرض كل ربط بين المستخدمين والأرقام:

```sql
select *
from public.user_number_assignments
order by username, range_name, number;
```
