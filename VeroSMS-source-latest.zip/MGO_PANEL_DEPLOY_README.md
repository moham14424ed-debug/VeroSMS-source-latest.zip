# MGO Panel — Complete Site Package

هذه الحزمة تحتوي على كود الموقع الكامل: Flask dashboard، بوابة Node، ملفات Docker، واجهة الإدارة، Reset Password، واستيراد المستخدمين.

## مهم قبل النشر

- لا يوجد أي ملف `.env` أو كلمة مرور قاعدة بيانات داخل الحزمة.
- أنشئ متغيرات البيئة في منصة الاستضافة بدل كتابتها داخل الملفات.
- استخدم استضافة مدفوعة تعمل دائمًا إذا أردت إبقاء Provider Fetchers وScheduler يعملان طوال الوقت. الاستضافة serverless أو المجانية قد توقف العمليات الخلفية.

## متغيرات البيئة المطلوبة

```text
LEGACY_FLASK=true
SUPABASE_DATABASE_URL=postgresql+psycopg2://postgres.PROJECT_REF:YOUR_PASSWORD@POOLER_HOST:5432/postgres?sslmode=require
SECRET_KEY=ضع_قيمة_عشوائية_طويلة_وجديدة
SESSION_COOKIE_SECURE=true
ENABLE_PROVIDER_FETCHERS=true
ENABLE_SCHEDULER=true
AUTO_RETURN_AFTER_HOURS=1
AUTO_RETURN_MIN_SMS=20
PORT=3000
```

لا تستخدم `db....supabase.co` إذا كانت الاستضافة لا تدعم IPv6؛ استخدم رابط **Session Pooler** أو **Transaction Pooler** من Supabase.

## تشغيل Docker

```bash
docker build -t mgo-panel .
docker run --rm -p 3000:3000 \
  -e LEGACY_FLASK=true \
  -e SUPABASE_DATABASE_URL="$SUPABASE_DATABASE_URL" \
  -e SECRET_KEY="$SECRET_KEY" \
  -e ENABLE_PROVIDER_FETCHERS=true \
  -e ENABLE_SCHEDULER=true \
  mgo-panel
```

ثم افتح:

```text
http://localhost:3000/login
```

## تشغيل دون Docker

```bash
pnpm install
python3 -m venv .venv
.venv/bin/pip install -r legacy_flask/requirements.txt
pnpm dev
```

## Reset Password

صفحة الدخول تحتوي على **Reset Password**. التدفق هو:

1. إدخال username.
2. مطابقة البريد الإلكتروني المسجل للحساب.
3. إدخال كلمة المرور الجديدة وتأكيدها.

لا يتم عرض أو حفظ كلمة المرور القديمة، ولا يتم إرسالها عبر البريد أو تسجيلها في السجلات. جلسة الاستعادة مؤقتة وتنتهي خلال 15 دقيقة.

## استيراد المستخدمين

من لوحة الإدارة افتح Users ثم Backup / Import Backup وارفع ملف TXT أو CSV.

- الاستيراد يعمل بنمط **upsert**: يحدث المستخدم المطابق أو ينشئ المستخدم غير الموجود.
- لا يحذف أي مستخدم قديم.
- المطابقة تكون بالـ username أو البريد حسب صيغة الملف.
- إذا لم يحتوي الملف على password، يتم إنشاء كلمة مرور مؤقتة للمستخدم الجديد وتظهر مرة واحدة في رسالة الإدارة؛ يجب تغييرها عبر Reset Password.
- API معطل افتراضيًا للمستخدمين حتى يفعّله المدير يدويًا.

## الحسابات الافتراضية

غيّر كلمات المرور الافتراضية فور أول دخول، خصوصًا حساب المدير وحساب الاختبار إذا كانا موجودين في قاعدة البيانات.

## فحص قبل النشر

```bash
pnpm check
pnpm build
python3 legacy_flask/test_feature_updates.py
```

## ملاحظة عن قاعدة البيانات

التطبيق يستخدم `SUPABASE_DATABASE_URL` لقاعدة PostgreSQL الحية، ويحوّل رابط PostgreSQL تلقائيًا إلى سائق `psycopg2` الموجود ضمن `requirements.txt`. لا تحذف قاعدة البيانات أثناء النشر؛ نفّذ النسخ الاحتياطي من Supabase قبل أي ترحيل.
