# MGO PANEL — Deployment Package

This package contains the complete MGO PANEL source, Flask dashboard, Node/WebDev proxy, Dockerfile, tests, and MGO brand assets.

## Add Hadi SMS API from the admin panel

Open **Admin → Providers → Add Provider**, choose **Hadi SMS API**, paste the token supplied by the Hadi SMS administrator into **Secret / Password / Token**, and save. Username and password are not required for this provider.

The preset uses:

- URL: `http://147.135.212.197/crapi/had/viewstats`
- Method: `GET`
- Query parameter: `token={{password}}`
- Response path: `data`
- Number: `num`, sender: `cli`, message: `message`

For other providers, choose **API / JSON** and set the URL, GET/POST method, query/JSON/form payload, headers, response path, and field mapping without editing the source code. Use `{{password}}` and `{{username}}` placeholders in JSON settings.

## Publish news

Administrators can create, edit, activate, and delete news from **Admin → News**. Active news appears automatically in the dashboard's **News & Notifications** card.

## Local verification

```bash
pnpm install
pnpm run check
pnpm run build
python3 -m venv .venv
.venv/bin/pip install -r legacy_flask/requirements.txt
.venv/bin/python -m unittest -v legacy_flask/test_smoke.py
```

## Container deployment

The included `Dockerfile` installs Node and Python dependencies and starts the application through the production process defined by `package.json`.

Required production environment variables include `SECRET_KEY`, `DATABASE_URL`, and the OAuth variables used by the host. Do not commit `.env` files, API tokens, or local database files.

The MGO logo assets are located at `legacy_flask/app/static/img/mgo-panel-logo.png` and `legacy_flask/app/static/img/mgo-panel-mark.png`.
