from datetime import datetime

from app import db
from app.models.sms import SMSNumber, TestNumberAssignment
from app.models.user import User

TEST_NUMBERS_PER_RANGE = 10


def sync_test_number(range_obj, test_number):
    """Keep one configured test number visible to the dedicated test account."""
    test_user = User.query.filter_by(username="test").first()
    if not test_user:
        return None

    configured = "".join(ch for ch in (test_number or "") if ch.isdigit())
    old_test_numbers = SMSNumber.query.filter_by(range_id=range_obj.id, status="test").all()
    for old in old_test_numbers:
        if old.number != configured:
            old.client_id = None
            old.agent_id = None
            old.status = "available"
            old.assigned_at = None

    if not configured:
        return None

    existing = SMSNumber.query.filter_by(number=configured).first()
    if existing and existing.range_id != range_obj.id:
        raise ValueError("This test number already belongs to another range.")
    if not existing:
        existing = SMSNumber(
            range_id=range_obj.id,
            number=configured,
            prefix=range_obj.prefix,
            status="test",
            is_active=True,
            created_at=datetime.utcnow(),
        )
        db.session.add(existing)
    existing.client_id = test_user.id
    existing.agent_id = None
    existing.status = "test"
    existing.is_active = True
    existing.assigned_at = datetime.utcnow()
    return existing


def ensure_test_pool(range_obj, limit=TEST_NUMBERS_PER_RANGE):
    """Reserve a stable, shared pool of up to ten numbers for quality testing."""
    pool = SMSNumber.query.filter_by(range_id=range_obj.id, status="test_pool").order_by(SMSNumber.id).all()
    if len(pool) >= limit:
        return pool[:limit]

    needed = limit - len(pool)
    candidates = SMSNumber.query.filter(
        SMSNumber.range_id == range_obj.id,
        SMSNumber.agent_id.is_(None),
        SMSNumber.client_id.is_(None),
        SMSNumber.is_active.is_(True),
        SMSNumber.status.in_(["available", "reserved"]),
    ).order_by(SMSNumber.id).limit(needed).all()
    for number in candidates:
        number.status = "test_pool"
        number.assigned_at = None
        number.agent_id = None
        number.client_id = None
    if candidates:
        db.session.flush()
    return pool + candidates


def add_test_numbers_for_user(user, range_obj, limit=TEST_NUMBERS_PER_RANGE):
    """Give a user access to the same fixed test pool, without duplicating rows."""
    pool = ensure_test_pool(range_obj, limit=limit)
    if not pool:
        return []
    existing_ids = {
        row.number_id for row in TestNumberAssignment.query.filter_by(
            user_id=user.id, range_id=range_obj.id
        ).all()
    }
    new_rows = []
    for number in pool:
        if number.id in existing_ids:
            continue
        new_rows.append(TestNumberAssignment(
            user_id=user.id,
            number_id=number.id,
            range_id=range_obj.id,
        ))
    if new_rows:
        db.session.add_all(new_rows)
    return [row.number for row in new_rows]


def reset_number_to_pool(number):
    number.agent_id = None
    number.client_id = None
    number.client_payout = 0.0
    number.agent_payout = 0.0
    number.status = "available"
    number.assigned_at = None
    return number
