import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from config import config

db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()

def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    # The Node gateway terminates HTTPS before forwarding to Flask. Trust the
    # gateway headers so Flask-Login and secure cookies use the public origin.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)
    CORS(app)

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please login to continue.'
    login_manager.login_message_category = 'warning'

    from app.models.user import User
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.admin import admin_bp
    from app.routes.developer import dev_bp
    from app.routes.sms_monitor import monitor_bp
    from app.routes.provider import provider_bp
    from app.routes.billing import billing_bp
    from app.routes.api import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(dev_bp)
    app.register_blueprint(monitor_bp)
    app.register_blueprint(provider_bp)
    app.register_blueprint(billing_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    with app.app_context():
        db.create_all()
        # Add API provider columns to existing installations without requiring
        # the administrator to edit SQL or recreate the database.
        from sqlalchemy import inspect, text
        provider_columns = {
            'auth_mode': "VARCHAR(20) DEFAULT 'basic'",
            'request_method': "VARCHAR(10) DEFAULT 'GET'",
            'request_format': "VARCHAR(20) DEFAULT 'query'",
            # MySQL does not allow DEFAULT values on TEXT columns.
            'request_params': "TEXT",
            'request_headers': "TEXT",
            'response_path': "VARCHAR(200) DEFAULT 'data'",
            'number_field': "VARCHAR(100) DEFAULT 'num'",
            'sender_field': "VARCHAR(100) DEFAULT 'cli'",
            'message_field': "VARCHAR(100) DEFAULT 'message'",
            'date_field': "VARCHAR(100) DEFAULT 'dt'",
        }
        existing_provider_columns = {c['name'] for c in inspect(db.engine).get_columns('providers')}
        for column, definition in provider_columns.items():
            if column not in existing_provider_columns:
                db.session.execute(text(f'ALTER TABLE providers ADD COLUMN {column} {definition}'))

        existing_user_columns = {c['name'] for c in inspect(db.engine).get_columns('users')}
        if 'api_enabled' not in existing_user_columns:
            db.session.execute(text("ALTER TABLE users ADD COLUMN api_enabled BOOLEAN NOT NULL DEFAULT FALSE"))
        # Existing tokens must not silently grant access after this migration.
        db.session.execute(text("UPDATE users SET api_enabled = FALSE WHERE api_enabled IS NULL"))
        db.session.commit()

        from app.models.user import User, Role
        from app.models.sms import AgentRangeLimit
        from app.models.wallet import Wallet, WithdrawalRequest
        from app.models.billing import AgentBankAccount, CreditNote

        # Roles create
        for role_name, display in [
            ('admin', 'Administrator'),
            ('agent', 'Agent'),
            ('client', 'Client'),
            ('developer', 'Developer')
        ]:
            if not Role.query.filter_by(name=role_name).first():
                db.session.add(Role(name=role_name, display_name=display))
        db.session.commit()

        # Auto create admin
        admin_role = Role.query.filter_by(name='admin').first()
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                email='admin@panel.com',
                password_hash=bcrypt.generate_password_hash('admin123').decode('utf-8'),
                role=admin_role,
                is_active=True
            )
            db.session.add(admin)
            db.session.commit()

        # Dedicated non-production account for safe UI/API demonstrations.
        # Its message view is redacted by the user-facing routes.
        test_role = Role.query.filter_by(name='client').first()
        if not User.query.filter_by(username='test').first():
            test_user = User(
                username='test',
                email='test@panel.local',
                password_hash=bcrypt.generate_password_hash('test123').decode('utf-8'),
                role=test_role,
                is_active=True
            )
            db.session.add(test_user)
            db.session.commit()

        # Background provider loops are opt-in. Serverless containers can be
        # recycled at any time, so the dashboard remains reliable by default.
        if os.environ.get('ENABLE_PROVIDER_FETCHERS', 'false').lower() == 'true':
            from app.fetcher import start_all_providers
            start_all_providers(app)

    # ---- Weekly Credit Note auto-generator (APScheduler) ----
    if os.environ.get('ENABLE_SCHEDULER', 'false').lower() == 'true' and (os.environ.get('WERKZEUG_RUN_MAIN') != 'true' or not app.debug):
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from app.scheduler_jobs import generate_weekly_credit_notes, auto_return_low_traffic_numbers

            scheduler = BackgroundScheduler(daemon=True)
            scheduler.add_job(
                func=lambda: generate_weekly_credit_notes(app),
                trigger='interval',
                hours=24,
                id='weekly_credit_note_job',
                replace_existing=True
            )
            scheduler.add_job(
                func=lambda: auto_return_low_traffic_numbers(app),
                trigger='interval',
                minutes=10,
                id='auto_return_low_traffic_job',
                replace_existing=True
            )
            scheduler.start()
        except Exception as e:
            print(f'Scheduler failed to start: {e}')

    return app
