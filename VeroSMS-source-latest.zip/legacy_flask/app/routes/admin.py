from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash, Response
from flask_login import login_required, current_user
from app import db
from app.models.sms import SMDRange, SMSNumber, SMSCDR, TestNumberAssignment
from app.models.provider import OTPLog
from app.models.user import User, Role
from app.models.activity import ActivityLog, News
from app.services_number_lifecycle import reset_number_to_pool, sync_test_number, ensure_test_pool
from datetime import datetime, timedelta, date
from functools import wraps
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload
import csv
import io
import json
import re
import secrets

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        if not current_user.is_admin():
            flash('Admin access required.', 'danger')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated

# ============ ADMIN DASHBOARD ============

@admin_bp.route('/')
@admin_required
def index():
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    total_numbers = SMSNumber.query.count()
    total_ranges = SMDRange.query.count()
    total_cdr = SMSCDR.query.count()
    today = datetime.utcnow().date()
    today_sms = SMSCDR.query.filter(
        db.func.date(SMSCDR.created_at) == today
    ).count()
    active_today_users = User.query.filter(
        User.is_active.is_(True),
        db.func.date(User.last_login) == today
    ).count()
    top_rows = db.session.query(
        User.username,
        User.email,
        db.func.count(SMSCDR.id).label('code_count')
    ).join(
        SMSCDR,
        db.func.coalesce(SMSCDR.client_id, SMSCDR.user_id) == User.id
    ).filter(
        db.func.date(SMSCDR.created_at) == today
    ).group_by(User.id, User.username, User.email).order_by(
        db.func.count(SMSCDR.id).desc()
    ).limit(10).all()
    recent_news = News.query.filter_by(is_active=True).order_by(
        News.created_at.desc()
    ).limit(5).all()
    return render_template('admin/index.html',
        stats={
            'total_users': total_users,
            'active_users': active_users,
            'total_numbers': total_numbers,
            'total_ranges': total_ranges,
            'total_cdr': total_cdr,
            'today_sms': today_sms,
            'active_today_users': active_today_users
        },
        recent_news=recent_news,
        top_users=top_rows
    )

# ============ USER MANAGEMENT ============

@admin_bp.route('/users')
@admin_required
def users():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    role_filter = request.args.get('role', '')
    query = User.query.options(joinedload(User.role), joinedload(User.agent))
    if search:
        query = query.filter(
            db.or_(
                User.username.like(f'%{search}%'),
                User.email.like(f'%{search}%'),
                User.name.like(f'%{search}%')
            )
        )
    if role_filter:
        role_obj = Role.query.filter_by(name=role_filter).first()
        if role_obj:
            query = query.filter_by(role_id=role_obj.id)
    users_list = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    roles = Role.query.all()
    agents = User.query.filter(User.role.has(name='agent')).all()
    return render_template('admin/users.html',
        users=users_list, roles=roles, agents=agents)


@admin_bp.route('/users/export')
@admin_required
def export_users():
    """Export user profile data without password hashes or API secrets."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'id', 'username', 'email', 'name', 'company', 'country', 'contact',
        'role', 'agent', 'is_active', 'api_enabled', 'sms_count', 'sms_limit',
        'created_at', 'last_login'
    ])
    for user in User.query.order_by(User.id).all():
        writer.writerow([
            user.id, user.username, user.email, user.name or '', user.company or '',
            user.country or '', user.contact or '', user.role.name if user.role else '',
            user.agent.username if user.agent else '', bool(user.is_active),
            bool(user.api_enabled), user.sms_count or 0, user.sms_limit or 0,
            user.created_at.isoformat() if user.created_at else '',
            user.last_login.isoformat() if user.last_login else ''
        ])
    return Response(
        output.getvalue(),
        mimetype='text/csv; charset=utf-8',
        headers={'Content-Disposition': 'attachment; filename=mgo_users_export.csv'}
    )


def _parse_user_export(text):
    """Parse the panel's human-readable USER EXPORT backup format."""
    rows = []
    for block in re.split(r'\n-{8,}\n?', text):
        block = block.strip()
        if not block or not block.startswith('USER EXPORT') and 'Username:' not in block:
            continue
        row = {}
        patterns = {
            'username': r'Username:\s*([^|\n]+)',
            'role': r'Role:\s*([^\n]+)',
            'name': r'Name:\s*([^|\n]*)',
            'email': r'Email:\s*([^|\n]+)',
            'is_active': r'Active:\s*([^\n]+)',
            'agent': r'Agent:\s*([^|\n]*)',
            'company': r'Company:\s*([^|\n]*)',
            'country': r'Country:\s*([^\n]+)',
            'contact': r'Contact:\s*([^|\n]*)',
            'address': r'Address:\s*([^|\n]*)',
            'skype': r'Skype:\s*([^\n]+)',
            'sms_count': r'SMS count/limit:\s*(\d+)\s*/',
            'sms_limit': r'SMS count/limit:\s*\d+\s*/\s*(\d+)',
            'api_enabled': r'API enabled:\s*([^|\n]+)',
        }
        for key, pattern in patterns.items():
            match = re.search(pattern, block, flags=re.IGNORECASE)
            if match:
                value = match.group(1).strip()
                row[key] = '' if value.lower() in ('none', 'null', '-') else value
        if row.get('username') and row.get('email'):
            rows.append(row)
    return rows


@admin_bp.route('/users/import-backup', methods=['GET', 'POST'])
@admin_required
def import_users_backup():
    """Restore users from a UTF-8 CSV, TSV, semicolon-separated, or JSONL text file."""
    if request.method == 'GET':
        return render_template('admin/import_users_backup.html')

    uploaded = request.files.get('backup_file')
    if not uploaded or not uploaded.filename:
        flash('Please select a backup text file.', 'danger')
        return redirect(url_for('admin.import_users_backup'))

    try:
        raw = uploaded.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024:
            raise ValueError('The backup file must be smaller than 2 MB.')
        text = raw.decode('utf-8-sig')
        stripped = text.lstrip()
        if stripped.startswith('USER EXPORT'):
            rows = _parse_user_export(text)
        elif stripped.startswith('{') or stripped.startswith('['):
            payload = json.loads(text)
            rows = payload if isinstance(payload, list) else payload.get('users', [])
        else:
            sample = text[:4096]
            dialect = csv.Sniffer().sniff(sample, delimiters=',;\t|')
            rows = list(csv.DictReader(io.StringIO(text), dialect=dialect))
    except (UnicodeDecodeError, ValueError, csv.Error, json.JSONDecodeError) as exc:
        flash(f'Could not read the backup file: {exc}', 'danger')
        return redirect(url_for('admin.import_users_backup'))

    if not rows or len(rows) > 1000:
        flash('The file must contain between 1 and 1000 user records.', 'danger')
        return redirect(url_for('admin.import_users_backup'))

    role_cache = {role.name.lower(): role for role in Role.query.all()}
    created = updated = skipped = 0
    generated_passwords = []
    errors = []

    for index, raw_row in enumerate(rows, start=2):
        row = {str(k).strip().lower(): (str(v).strip() if v is not None else '') for k, v in raw_row.items() if k}
        username = row.get('username', '')
        email = row.get('email', '')
        if not username or not email:
            errors.append(f'Row {index}: username and email are required.')
            skipped += 1
            continue

        role_name = (row.get('role') or 'client').lower()
        role = role_cache.get(role_name) or role_cache.get({'user': 'client', 'administrator': 'admin'}.get(role_name, ''))
        if not role:
            errors.append(f'Row {index}: unknown role "{role_name}".')
            skipped += 1
            continue

        user = User.query.filter(
            db.or_(User.username == username, User.email == email)
        ).first()
        if user is None:
            user = User(username=username, email=email, role=role, is_active=True)
            db.session.add(user)
            created += 1
        else:
            updated += 1
            user.email = email
            user.role = role

        user.name = row.get('name') or user.name
        user.company = row.get('company') or user.company
        user.country = row.get('country') or user.country
        user.skype = row.get('skype') or user.skype
        user.contact = row.get('contact') or user.contact
        user.sms_limit = int(row.get('sms_limit') or user.sms_limit or 0)
        user.is_active = row.get('is_active', 'true').lower() not in ('0', 'false', 'no', 'inactive', 'blocked')
        user.api_enabled = row.get('api_enabled', 'false').lower() in ('1', 'true', 'yes', 'enabled')
        if not user.api_enabled:
            user.api_token = None

        agent_username = row.get('agent')
        if agent_username:
            parent_agent = User.query.filter_by(username=agent_username).first()
            if parent_agent:
                user.agent_id = parent_agent.id

        password_hash = row.get('password_hash')
        password = row.get('password')
        if password_hash:
            user.password_hash = password_hash
        elif password:
            user.set_password(password)
        elif not user.password_hash:
            temporary_password = secrets.token_urlsafe(9)
            user.set_password(temporary_password)
            generated_passwords.append(f'{username}: {temporary_password}')
        # API access remains disabled until an administrator explicitly enables it.

    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        flash(f'Import failed and no records were saved: {exc}', 'danger')
        return redirect(url_for('admin.import_users_backup'))

    ActivityLog.log(current_user.id, 'admin_import_users_backup', f'Imported users backup: {created} created, {updated} updated, {skipped} skipped', ip_address=request.remote_addr)
    flash(f'Backup imported: {created} created, {updated} updated, {skipped} skipped.', 'success')
    if generated_passwords:
        flash('Generated passwords: ' + ' | '.join(generated_passwords), 'warning')
    for error in errors[:10]:
        flash(error, 'warning')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/view/<int:user_id>')
@admin_required
def view_user(user_id):
    user = User.query.get_or_404(user_id)
    return render_template('admin/user_view.html', user=user)

@admin_bp.route('/users/create', methods=['GET', 'POST'])
@admin_required
def create_user():
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        email = (request.form.get('email') or '').strip().lower()
        password = request.form.get('password')
        role_id = request.form.get('role_id', type=int)
        agent_id = request.form.get('agent_id', type=int)
        name = request.form.get('name')
        company = request.form.get('company')
        country = request.form.get('country')
        sms_limit = request.form.get('sms_limit', 0, type=int)
        if not username or not email or not password:
            flash('Username, email, and password are required.', 'danger')
            return redirect(url_for('admin.create_user'))
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.create_user'))
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return redirect(url_for('admin.create_user'))
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return redirect(url_for('admin.create_user'))
        role = Role.query.get(role_id)
        if not role:
            flash('Invalid role selected.', 'danger')
            return redirect(url_for('admin.create_user'))
        user = User(
            username=username,
            email=email,
            role=role,
            name=name,
            company=company,
            country=country,
            agent_id=agent_id if agent_id else None,
            sms_limit=sms_limit,
            is_active=True
        )
        user.set_password(password)
        db.session.add(user)
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash('Could not create user. Username or email may already exist.', 'danger')
            return redirect(url_for('admin.create_user'))
        ActivityLog.log(
            current_user.id,
            'admin_create_user',
            f'Created user {username} with role {role.display_name}',
            ip_address=request.remote_addr
        )
        flash(f'User {username} created successfully.', 'success')
        return redirect(url_for('admin.users'))
    roles = Role.query.all()
    agents = User.query.filter(User.role.has(name='agent')).all()
    return render_template('admin/user_form.html', roles=roles, agents=agents, user=None)

@admin_bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_user(user_id):
    user = User.query.get_or_404(user_id)
    if request.method == 'POST':
        email = (request.form.get('email') or '').strip().lower()
        if User.query.filter(User.email == email, User.id != user.id).first():
            flash('Email already registered by another user.', 'danger')
            return redirect(url_for('admin.edit_user', user_id=user.id))
        user.email = email
        user.name = request.form.get('name')
        user.company = request.form.get('company')
        user.country = request.form.get('country')
        user.skype = request.form.get('skype')
        user.contact = request.form.get('contact')
        user.sms_limit = request.form.get('sms_limit', 0, type=int)
        user.agent_id = request.form.get('agent_id', type=int) or None
        role_id = request.form.get('role_id', type=int)
        if role_id:
            user.role_id = role_id
        user.is_active = bool(request.form.get('is_active'))
        new_password = request.form.get('password')
        if new_password and len(new_password) >= 6:
            user.set_password(new_password)
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash('Could not update user. Please check the submitted values.', 'danger')
            return redirect(url_for('admin.edit_user', user_id=user.id))
        ActivityLog.log(
            current_user.id,
            'admin_edit_user',
            f'Edited user {user.username}',
            ip_address=request.remote_addr
        )
        flash(f'User {user.username} updated.', 'success')
        return redirect(url_for('admin.users'))
    roles = Role.query.all()
    agents = User.query.filter(User.role.has(name='agent')).all()
    return render_template('admin/user_form.html', roles=roles, agents=agents, user=user)

@admin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('Cannot delete your own account.', 'danger')
        return redirect(url_for('admin.users'))
    username = user.username
    db.session.delete(user)
    db.session.commit()
    ActivityLog.log(current_user.id, 'admin_delete_user', f'Deleted user {username}', ip_address=request.remote_addr)
    flash(f'User {username} deleted.', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:user_id>/add-number', methods=['GET', 'POST'])
@admin_required
def add_numbers_to_user(user_id):
    """Assign available numbers from one range to an admin-selected user."""
    user = User.query.get_or_404(user_id)
    role_name = user.role.name if user.role else None

    if role_name not in ('agent', 'client'):
        flash('Numbers can only be assigned to agent or client users.', 'danger')
        return redirect(url_for('admin.users'))

    if request.method == 'POST':
        range_id = request.form.get('range_id', type=int)
        numbers_count = request.form.get('numbers_count', 0, type=int)

        if not range_id or numbers_count < 1:
            flash('Select a range and enter a valid number of numbers.', 'danger')
            return redirect(url_for('admin.add_numbers_to_user', user_id=user.id))
        if numbers_count > 10000:
            flash('You can add a maximum of 10,000 numbers at a time.', 'danger')
            return redirect(url_for('admin.add_numbers_to_user', user_id=user.id))

        sms_range = SMDRange.query.filter_by(id=range_id, is_active=True).first()
        if not sms_range:
            flash('Invalid or inactive range.', 'danger')
            return redirect(url_for('admin.add_numbers_to_user', user_id=user.id))

        ensure_test_pool(sms_range)
        # Lock selected available rows in PostgreSQL so two admins cannot
        # allocate the same number concurrently.
        available_query = SMSNumber.query.filter(
            SMSNumber.range_id == sms_range.id,
            SMSNumber.agent_id.is_(None),
            SMSNumber.client_id.is_(None),
            SMSNumber.is_active.is_(True),
            SMSNumber.status.in_(['available', 'reserved']),
            SMSNumber.status != 'test_pool'
        ).order_by(SMSNumber.id).with_for_update(skip_locked=True)
        selected_numbers = available_query.limit(numbers_count).all()

        if len(selected_numbers) < numbers_count:
            db.session.rollback()
            flash(
                f'Only {len(selected_numbers)} numbers are available in this range.',
                'warning'
            )
            return redirect(url_for('admin.add_numbers_to_user', user_id=user.id))

        owner_field = 'agent_id' if role_name == 'agent' else 'client_id'
        for number in selected_numbers:
            setattr(number, owner_field, user.id)
            number.status = 'reserved' if role_name == 'agent' else 'activated'
            number.assigned_at = datetime.utcnow()

        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash('Numbers could not be assigned because the data changed. Please retry.', 'danger')
            return redirect(url_for('admin.add_numbers_to_user', user_id=user.id))
        ActivityLog.log(
            current_user.id,
            'admin_add_numbers_to_user',
            f'Assigned {len(selected_numbers)} numbers from range {sms_range.prefix} to {user.username}',
            ip_address=request.remote_addr
        )
        flash(
            f'{len(selected_numbers)} numbers added to {user.username} successfully.',
            'success'
        )
        return redirect(url_for('admin.users'))

    ranges = SMDRange.query.filter_by(is_active=True).order_by(
        SMDRange.country, SMDRange.prefix
    ).all()
    assigned_filter = SMSNumber.agent_id if role_name == 'agent' else SMSNumber.client_id
    current_numbers = SMSNumber.query.filter(assigned_filter == user.id).count()
    available_counts = dict(
        db.session.query(SMSNumber.range_id, db.func.count(SMSNumber.id))
        .filter(
            SMSNumber.agent_id.is_(None),
            SMSNumber.client_id.is_(None),
            SMSNumber.is_active.is_(True),
            SMSNumber.status.in_(['available', 'reserved']),
            SMSNumber.status != 'test_pool'
        )
        .group_by(SMSNumber.range_id)
        .all()
    )

    return render_template(
        'admin/add_numbers_to_user.html',
        user=user,
        ranges=ranges,
        current_numbers=current_numbers,
        available_counts=available_counts
    )

@admin_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
@admin_required
def toggle_user_status(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot toggle own status'}), 400
    user.is_active = not user.is_active
    db.session.commit()
    return jsonify({'success': True, 'is_active': user.is_active})


@admin_bp.route('/api-access', methods=['GET', 'POST'])
@admin_required
def api_access():
    if request.method == 'POST':
        user_id = request.form.get('user_id', type=int)
        action = request.form.get('action', 'enable')
        user = User.query.get_or_404(user_id)
        if user.is_admin() and action in ('revoke', 'disable'):
            flash('The administrator API access cannot be changed from this page.', 'danger')
        elif action in ('revoke', 'disable'):
            user.api_token = None
            user.api_enabled = False
            db.session.commit()
            flash(f'API access revoked for {user.username}.', 'success')
        else:
            if not user.api_token:
                user.generate_api_token()
            user.api_enabled = True
            db.session.commit()
            flash(f'API access enabled for {user.username}. Copy the new key from the table.', 'success')
        return redirect(url_for('admin.api_access'))

    search = request.args.get('search', '').strip()
    users_query = User.query
    if search:
        users_query = users_query.filter(
            db.or_(
                User.username.ilike(f'%{search}%'),
                User.email.ilike(f'%{search}%')
            )
        )
    users_with_api = users_query.order_by(User.username).all()
    return render_template('admin/api_access.html', users=users_with_api, search=search)

# ============ SMS RANGES ============

@admin_bp.route('/ranges')
@admin_required
def sms_ranges():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    query = SMDRange.query
    if search:
        query = query.filter(
            db.or_(
                SMDRange.prefix.like(f'%{search}%'),
                SMDRange.country.like(f'%{search}%')
            )
        )
    ranges_list = query.order_by(SMDRange.country).paginate(
        page=page, per_page=25, error_out=False
    )
    return render_template('admin/sms_ranges.html', ranges=ranges_list)

@admin_bp.route('/ranges/create', methods=['GET', 'POST'])
@admin_required
def create_sms_range():
    if request.method == 'POST':
        name = (request.form.get('name') or '').strip()
        prefix = ''.join(ch for ch in (request.form.get('prefix') or '') if ch.isdigit())
        country = (request.form.get('country') or '').strip()
        test_number = request.form.get('test_number')
        application = request.form.get('application', '')
        daily_limit = request.form.get('daily_limit', 50, type=int)
        payout = request.form.get('payout', 0.0, type=float)
        csv_file = request.files.get('csv_file')
        csv_numbers = []
        if not prefix or not country:
            flash('Range country and numeric prefix are required.', 'danger')
            return redirect(url_for('admin.create_sms_range'))
        if csv_file and csv_file.filename:
            try:
                raw = csv_file.read()
                try:
                    content = raw.decode('utf-8')
                except UnicodeDecodeError:
                    content = raw.decode('latin-1')
                lines = content.strip().splitlines()
                for line in lines:
                    cell = line.split(',')[0].strip()
                    if cell:
                        digits = ''.join(ch for ch in cell if ch.isdigit())
                        if digits and digits not in csv_numbers:
                            csv_numbers.append(digits)
            except Exception as e:
                flash(f'Error reading file: {str(e)}', 'danger')
                return redirect(url_for('admin.create_sms_range'))
        sms_range = SMDRange(
            name=name,
            prefix=prefix,
            country=country,
            test_number=test_number,
            application=application if application else None,
            daily_limit=daily_limit,
            payout=payout,
            cost_per_sms=0.005,
            is_active=True
        )
        db.session.add(sms_range)
        db.session.flush()
        try:
            sync_test_number(sms_range, test_number)
            db.session.commit()
        except (ValueError, IntegrityError) as exc:
            db.session.rollback()
            flash('Range could not be created. Check that the test number is not already used.', 'danger')
            return redirect(url_for('admin.create_sms_range'))
        created_count = 0
        skip_count = 0
        if csv_numbers:
            normalized_numbers = [
                value if value.startswith(prefix) else f'{prefix}{value}'
                for value in csv_numbers
            ]
            existing_numbers = {
                num[0] for num in db.session.query(SMSNumber.number).filter(
                    SMSNumber.number.in_(normalized_numbers)
                ).all()
            }
            for num_str in csv_numbers:
                num_clean = num_str.strip()
                if not num_clean:
                    continue
                if not num_clean.startswith(prefix):
                    num_clean = f"{prefix}{num_clean}"
                if num_clean in existing_numbers:
                    skip_count += 1
                    continue
                num = SMSNumber(
                    range_id=sms_range.id,
                    number=num_clean,
                    prefix=prefix,
                    status='available',
                    is_active=True
                )
                db.session.add(num)
                created_count += 1
                existing_numbers.add(num_clean)
            db.session.commit()
        test_pool = ensure_test_pool(sms_range)
        if test_pool:
            db.session.commit()
        ActivityLog.log(
            current_user.id,
            'admin_create_range',
            f'Created range {prefix} and added {created_count} numbers',
            ip_address=request.remote_addr
        )
        result_msg = f'Range {prefix} created with {created_count} numbers and {len(test_pool)} fixed test numbers.'
        if skip_count > 0:
            result_msg += f' ({skip_count} skipped - already exist)'
        flash(result_msg, 'success')
        return redirect(url_for('admin.sms_ranges'))
    return render_template('admin/range_form.html', range_obj=None)

@admin_bp.route('/ranges/<int:range_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_sms_range(range_id):
    range_obj = SMDRange.query.get_or_404(range_id)
    if request.method == 'POST':
        range_obj.name = request.form.get('name')
        range_obj.prefix = request.form.get('prefix')
        range_obj.country = request.form.get('country')
        range_obj.application = request.form.get('application') or None
        range_obj.operator = request.form.get('operator')
        range_obj.network_type = request.form.get('network_type')
        range_obj.mcc = request.form.get('mcc')
        range_obj.mnc = request.form.get('mnc')
        range_obj.daily_limit = request.form.get('daily_limit', 50, type=int)
        range_obj.payout = request.form.get('payout', 0.0, type=float)
        range_obj.cost_per_sms = request.form.get('cost_per_sms', 0.005, type=float)
        range_obj.currency = request.form.get('currency', 'USD')
        range_obj.rate = request.form.get('rate', 0.0, type=float)
        range_obj.test_number = request.form.get('test_number')
        range_obj.memo = request.form.get('memo')
        range_obj.is_active = bool(request.form.get('is_active'))
        try:
            sync_test_number(range_obj, range_obj.test_number)
            ensure_test_pool(range_obj)
            db.session.commit()
        except ValueError as exc:
            db.session.rollback()
            flash(str(exc), 'danger')
            return redirect(url_for('admin.edit_sms_range', range_id=range_id))
        ActivityLog.log(
            current_user.id,
            'admin_edit_range',
            f'Edited range {range_obj.prefix}',
            ip_address=request.remote_addr
        )
        flash(f'Range {range_obj.prefix} updated.', 'success')
        return redirect(url_for('admin.sms_ranges'))
    return render_template('admin/range_form.html', range_obj=range_obj)

@admin_bp.route('/ranges/<int:range_id>/test-numbers', methods=['POST'])
@admin_required
def add_range_test_numbers(range_id):
    """Append manually entered fixed quality-test numbers to an existing range."""
    range_obj = SMDRange.query.get_or_404(range_id)
    raw_text = request.form.get('test_numbers', '')
    candidates = []
    for token in re.split(r'[\s,;]+', raw_text):
        digits = ''.join(ch for ch in token if ch.isdigit())
        if not digits:
            continue
        if range_obj.prefix and not digits.startswith(str(range_obj.prefix)):
            digits = f'{range_obj.prefix}{digits}'
        if digits not in candidates:
            candidates.append(digits)
    current_pool = SMSNumber.query.filter_by(
        range_id=range_obj.id, status='test_pool'
    ).order_by(SMSNumber.id).all()
    current_values = {item.number for item in current_pool}
    new_values = [value for value in candidates if value not in current_values]
    if not candidates:
        flash('Enter at least one test number, one number per line.', 'danger')
        return redirect(url_for('admin.sms_ranges'))
    if len(current_pool) + len(new_values) > 10:
        flash('A range can have a maximum of 10 fixed test numbers.', 'danger')
        return redirect(url_for('admin.sms_ranges'))
    added = 0
    skipped = 0
    try:
        existing_numbers = {
            item.number: item
            for item in SMSNumber.query.filter(SMSNumber.number.in_(candidates)).all()
        }
        for number_value in candidates:
            number = existing_numbers.get(number_value)
            if number and number.range_id != range_obj.id:
                raise ValueError(f'{number_value} already belongs to another range.')
            if number and number.status == 'test':
                skipped += 1
                continue
            if not number:
                number = SMSNumber(
                    range_id=range_obj.id,
                    number=number_value,
                    prefix=range_obj.prefix,
                    status='test_pool',
                    is_active=True,
                    created_at=datetime.utcnow(),
                )
                db.session.add(number)
            else:
                number.status = 'test_pool'
                number.agent_id = None
                number.client_id = None
                number.assigned_at = None
                number.is_active = True
            added += 1
        db.session.commit()
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), 'danger')
        return redirect(url_for('admin.sms_ranges'))
    flash(
        f'{added} fixed test number(s) saved for {range_obj.country} / +{range_obj.prefix}.'
        + (f' {skipped} skipped.' if skipped else ''),
        'success'
    )
    ActivityLog.log(
        current_user.id,
        'admin_add_range_test_numbers',
        f'Added {added} test numbers to range {range_obj.prefix}',
        ip_address=request.remote_addr
    )
    return redirect(url_for('admin.sms_ranges'))

@admin_bp.route('/ranges/<int:range_id>/delete', methods=['GET', 'POST'])
@admin_required
def delete_sms_range(range_id):
    range_obj = SMDRange.query.get_or_404(range_id)
    range_info = f'{range_obj.name or range_obj.prefix} - {range_obj.country}'
    try:
        # Preserve historical CDR rows while removing their foreign-key links.
        SMSCDR.query.filter_by(range_id=range_id).update(
            {SMSCDR.range_id: None, SMSCDR.number_id: None},
            synchronize_session=False
        )
        # OTP logs are historical records too, but their number FK must be
        # cleared before the referenced SMS numbers can be removed.
        range_number_ids = db.session.query(SMSNumber.id).filter(
            SMSNumber.range_id == range_id
        ).scalar_subquery()
        OTPLog.query.filter(OTPLog.number_id.in_(range_number_ids)).update(
            {OTPLog.number_id: None},
            synchronize_session=False
        )
        TestNumberAssignment.query.filter_by(range_id=range_id).delete(
            synchronize_session=False
        )
        db.session.query(SMSNumber).filter_by(range_id=range_id).delete(
            synchronize_session=False
        )
        from app.models.sms import AgentRangeLimit
        AgentRangeLimit.query.filter_by(range_id=range_id).delete(
            synchronize_session=False
        )
        db.session.delete(range_obj)
        db.session.commit()
    except Exception:
        db.session.rollback()
        flash('Range could not be deleted safely. No data was changed.', 'danger')
        return redirect(url_for('admin.sms_ranges'))
    ActivityLog.log(
        current_user.id,
        'admin_delete_range',
        f'Deleted range {range_info}',
        ip_address=request.remote_addr
    )
    flash(f'Range {range_info} deleted.', 'success')
    return redirect(url_for('admin.sms_ranges'))

# ============ SMS NUMBERS ============

@admin_bp.route('/sms/numbers')
@admin_required
def sms_numbers():
    per_page = request.args.get('per_page', 50, type=int)
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    agent_filter = request.args.get('agent', '')
    query = SMSNumber.query
    if search:
        query = query.filter(SMSNumber.number.like(f'%{search}%'))
    if agent_filter == 'none':
        query = query.filter(SMSNumber.agent_id.is_(None))
    elif agent_filter:
        query = query.filter_by(agent_id=agent_filter)
    if per_page == 99999:
        all_numbers = query.order_by(SMSNumber.created_at.desc()).all()
        class FakePaginate:
            def __init__(self, items):
                self.items = items
                self.total = len(items)
                self.page = 1
                self.pages = 1
                self.has_prev = False
                self.has_next = False
                self.prev_num = None
                self.next_num = None
        numbers = FakePaginate(all_numbers)
    else:
        numbers = query.order_by(SMSNumber.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
    agents = User.query.filter(User.role.has(name='agent')).all()
    return render_template('admin/sms_numbers.html',
        numbers=numbers, agents=agents, per_page=per_page)

@admin_bp.route('/sms/numbers/bulk-delete', methods=['POST'])
@admin_required
def bulk_delete_numbers():
    number_ids = request.form.getlist('number_ids')
    if not number_ids:
        flash('No numbers selected!', 'danger')
        return redirect(url_for('admin.sms_numbers'))
    deleted = 0
    for nid in number_ids:
        num = SMSNumber.query.get(int(nid))
        if num:
            db.session.delete(num)
            deleted += 1
    db.session.commit()
    ActivityLog.log(
        current_user.id,
        'admin_bulk_delete_numbers',
        f'Bulk deleted {deleted} numbers',
        ip_address=request.remote_addr
    )
    flash(f'{deleted} numbers permanently deleted!', 'success')
    return redirect(url_for('admin.sms_numbers'))

@admin_bp.route('/sms/numbers/reclaim', methods=['POST'])
@admin_required
def admin_reclaim_numbers():
    number_ids = request.form.getlist('number_ids')
    if not number_ids:
        flash('No numbers selected!', 'danger')
        return redirect(url_for('admin.sms_numbers'))
    done = 0
    for nid in number_ids:
        num = SMSNumber.query.get(int(nid))
        if num and num.agent_id:
            reset_number_to_pool(num)
            done += 1
    db.session.commit()
    ActivityLog.log(
        current_user.id,
        'admin_reclaim_numbers',
        f'Reclaimed {done} numbers back to range',
        ip_address=request.remote_addr
    )
    flash(f'{done} numbers reclaimed and returned to range!', 'success')
    return redirect(url_for('admin.sms_numbers'))

@admin_bp.route('/sms/numbers/<int:number_id>/reclaim', methods=['POST'])
@admin_required
def admin_reclaim_single(number_id):
    num = SMSNumber.query.get_or_404(number_id)
    reset_number_to_pool(num)
    db.session.commit()
    ActivityLog.log(
        current_user.id,
        'admin_reclaim_single',
        f'Reclaimed number {num.number} back to range',
        ip_address=request.remote_addr
    )
    flash(f'Number {num.number} reclaimed and returned to range!', 'success')
    return redirect(url_for('admin.sms_numbers'))


@admin_bp.route('/sms/numbers/return', methods=['GET', 'POST'])
@admin_required
def return_numbers_from_agent():
    """Return a chosen quantity or selected numbers from an agent to the pool."""
    agents = User.query.filter(User.role.has(name='agent')).order_by(
        User.is_active.desc(), User.username
    ).all()
    agent_id = request.values.get('agent_id', type=int)
    selected_agent = User.query.get(agent_id) if agent_id else None

    if request.method == 'POST':
        if not selected_agent or not selected_agent.is_agent():
            flash('Choose a valid agent first.', 'danger')
            return redirect(url_for('admin.return_numbers_from_agent'))
        selected_ids = {int(value) for value in request.form.getlist('number_ids') if value.isdigit()}
        range_id = request.form.get('range_id', type=int)
        quantity = request.form.get('quantity', 0, type=int)
        query = SMSNumber.query.filter(SMSNumber.agent_id == selected_agent.id)
        if range_id:
            query = query.filter(SMSNumber.range_id == range_id)
        if selected_ids:
            query = query.filter(SMSNumber.id.in_(selected_ids))
        elif quantity > 0:
            query = query.order_by(SMSNumber.assigned_at.asc(), SMSNumber.id.asc()).limit(min(quantity, 10000))
        else:
            flash('Select numbers or enter a quantity to return.', 'danger')
            return redirect(url_for('admin.return_numbers_from_agent', agent_id=selected_agent.id))
        numbers = query.all()
        for number in numbers:
            reset_number_to_pool(number)
        db.session.commit()
        ActivityLog.log(
            current_user.id,
            'admin_return_numbers',
            f'Returned {len(numbers)} numbers from agent {selected_agent.username}',
            ip_address=request.remote_addr
        )
        flash(f'{len(numbers)} numbers returned to the available pool.', 'success')
        return redirect(url_for('admin.return_numbers_from_agent', agent_id=selected_agent.id))

    numbers = []
    ranges = []
    if selected_agent:
        numbers = SMSNumber.query.filter_by(agent_id=selected_agent.id).order_by(
            SMSNumber.assigned_at.asc(), SMSNumber.number
        ).all()
        range_ids = {number.range_id for number in numbers}
        ranges = SMDRange.query.filter(SMDRange.id.in_(range_ids)).order_by(
            SMDRange.country, SMDRange.prefix
        ).all() if range_ids else []
    return render_template(
        'admin/return_numbers.html',
        agents=agents,
        selected_agent=selected_agent,
        numbers=numbers,
        ranges=ranges
    )

@admin_bp.route('/sms/numbers/<int:number_id>/delete', methods=['POST'])
@admin_required
def delete_number(number_id):
    number = SMSNumber.query.get_or_404(number_id)
    num_str = number.number
    db.session.delete(number)
    db.session.commit()
    ActivityLog.log(
        current_user.id,
        'admin_delete_number',
        f'Permanently deleted number {num_str}',
        ip_address=request.remote_addr
    )
    flash(f'Number {num_str} permanently deleted.', 'success')
    return redirect(url_for('admin.sms_numbers'))

# ============ SMS CDR ============

@admin_bp.route('/sms/cdr')
@admin_required
def sms_cdr():
    page = request.args.get('page', 1, type=int)
    fdate1 = request.args.get('fdate1', datetime.utcnow().strftime('%Y-%m-%d'))
    fdate2 = request.args.get('fdate2', datetime.utcnow().strftime('%Y-%m-%d'))
    def parse_date(date_str):
        try:
            return datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
        except (ValueError, TypeError):
            try:
                return datetime.strptime(date_str, '%Y-%m-%d')
            except (ValueError, TypeError):
                return datetime.utcnow()
    date1 = parse_date(fdate1)
    date2 = parse_date(fdate2).replace(hour=23, minute=59, second=59)
    query = SMSCDR.query.filter(
        SMSCDR.created_at >= date1,
        SMSCDR.created_at <= date2
    )
    cdr_records = query.order_by(SMSCDR.created_at.desc()).paginate(
        page=page, per_page=50, error_out=False
    )
    totals = db.session.query(
        db.func.count(SMSCDR.id).label('total'),
        db.func.sum(SMSCDR.profit).label('total_profit')
    ).filter(
        SMSCDR.created_at >= date1,
        SMSCDR.created_at <= date2
    ).first()
    return render_template('admin/sms_cdr.html',
        cdr_records=cdr_records,
        totals=totals,
        fdate1=fdate1,
        fdate2=fdate2
    )

# ============ ACTIVITY LOGS ============

@admin_bp.route('/activity')
@admin_required
def activity_logs():
    page = request.args.get('page', 1, type=int)
    user_filter = request.args.get('user', '')
    action_filter = request.args.get('action', '')
    query = ActivityLog.query
    if user_filter:
        query = query.filter_by(user_id=user_filter)
    if action_filter:
        query = query.filter_by(action=action_filter)
    activities = query.order_by(ActivityLog.created_at.desc()).paginate(
        page=page, per_page=50, error_out=False
    )
    users = User.query.all()
    return render_template('admin/activity.html', activities=activities, users=users)

# ============ NEWS ============

@admin_bp.route('/news')
@admin_required
def news():
    page = request.args.get('page', 1, type=int)
    news_list = News.query.order_by(News.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template('admin/news.html', news_list=news_list)

@admin_bp.route('/news/create', methods=['GET', 'POST'])
@admin_required
def create_news():
    if request.method == 'POST':
        headline = request.form.get('headline')
        content = request.form.get('content')
        if not headline:
            flash('Headline is required.', 'danger')
            return redirect(url_for('admin.create_news'))
        news_item = News(
            headline=headline,
            content=content,
            created_by=current_user.id,
            is_active=True
        )
        db.session.add(news_item)
        db.session.commit()
        flash('News created.', 'success')
        return redirect(url_for('admin.news'))
    return render_template('admin/news_form.html', news=None)

@admin_bp.route('/news/<int:news_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_news(news_id):
    news_item = News.query.get_or_404(news_id)
    if request.method == 'POST':
        news_item.headline = request.form.get('headline')
        news_item.content = request.form.get('content')
        news_item.is_active = bool(request.form.get('is_active'))
        db.session.commit()
        flash('News updated.', 'success')
        return redirect(url_for('admin.news'))
    return render_template('admin/news_form.html', news=news_item)

@admin_bp.route('/news/<int:news_id>/delete', methods=['POST'])
@admin_required
def delete_news(news_id):
    news_item = News.query.get_or_404(news_id)
    db.session.delete(news_item)
    db.session.commit()
    flash('News deleted.', 'success')
    return redirect(url_for('admin.news'))

# ============ RANGE DAILY LIMIT ============

@admin_bp.route('/agent-limits')
@admin_required
def agent_limits():
    ranges = SMDRange.query.filter_by(is_active=True).order_by(SMDRange.country).all()
    return render_template('admin/agent_limits.html', ranges=ranges)

@admin_bp.route('/agent-limits/set/<int:range_id>', methods=['POST'])
@admin_required
def set_range_limit(range_id):
    sms_range = SMDRange.query.get_or_404(range_id)
    daily_limit = request.form.get('daily_limit', 50, type=int)
    sms_range.daily_limit = daily_limit
    db.session.commit()
    flash(f'{sms_range.country} daily limit set to {daily_limit}!', 'success')
    return redirect(url_for('admin.agent_limits'))

@admin_bp.route('/ranges/set-payout/<int:range_id>', methods=['POST'])
@admin_required
def set_range_payout(range_id):
    sms_range = SMDRange.query.get_or_404(range_id)
    payout = request.form.get('payout', 0.0, type=float)
    sms_range.payout = payout
    db.session.commit()
    flash(f'{sms_range.country} payout set to ${payout:.4f}/OTP!', 'success')
    return redirect(url_for('admin.sms_ranges'))

# ============ AGENT OTP STATS ============

@admin_bp.route('/agent-otp-stats')
@admin_required
def agent_otp_stats():
    from app.models.provider import OTPLog
    today = datetime.utcnow().date()
    week_ago = today - timedelta(days=7)
    first_of_month = today.replace(day=1)

    agents = User.query.filter(User.role.has(name='agent')).all()

    stats = []
    for agent in agents:
        agent_number_ids = [n.id for n in SMSNumber.query.filter_by(agent_id=agent.id).all()]

        if not agent_number_ids:
            stats.append({
                'agent': agent,
                'today': 0,
                'week': 0,
                'month': 0,
                'total': 0
            })
            continue

        today_count = OTPLog.query.filter(
            OTPLog.number_id.in_(agent_number_ids),
            db.func.date(OTPLog.received_at) == today
        ).count()

        week_count = OTPLog.query.filter(
            OTPLog.number_id.in_(agent_number_ids),
            OTPLog.received_at >= week_ago
        ).count()

        month_count = OTPLog.query.filter(
            OTPLog.number_id.in_(agent_number_ids),
            OTPLog.received_at >= first_of_month
        ).count()

        total_count = OTPLog.query.filter(
            OTPLog.number_id.in_(agent_number_ids)
        ).count()

        stats.append({
            'agent': agent,
            'today': today_count,
            'week': week_count,
            'month': month_count,
            'total': total_count
        })

    stats.sort(key=lambda x: x['total'], reverse=True)

    return render_template('admin/agent_otp_stats.html', stats=stats)

# ============ ADD NUMBERS TO AGENT ============

@admin_bp.route('/add-numbers-to-agent', methods=['GET', 'POST'])
@admin_required
def add_numbers_to_agent():
    search = request.args.get('search', '')
    agents_query = User.query.filter(User.role.has(name='agent'))
    if search:
        agents_query = agents_query.filter(
            db.or_(
                User.username.like(f'%{search}%'),
                User.name.like(f'%{search}%')
            )
        )
    agents = agents_query.all()
    ranges = SMDRange.query.filter_by(is_active=True).all()
    if request.method == 'POST':
        agent_id = request.form.get('agent_id', type=int)
        range_id = request.form.get('range_id', type=int)
        count = request.form.get('count', 0, type=int)
        if not agent_id or not range_id or count <= 0 or count > 10000:
            flash('All fields are required!', 'danger')
            return redirect(url_for('admin.add_numbers_to_agent'))
        agent = User.query.get(agent_id)
        sms_range = SMDRange.query.get(range_id)
        if not agent or not agent.is_agent() or not sms_range or not sms_range.is_active:
            flash('Invalid agent or range!', 'danger')
            return redirect(url_for('admin.add_numbers_to_agent'))
        ensure_test_pool(sms_range)
        available = SMSNumber.query.filter(
            SMSNumber.range_id == range_id,
            SMSNumber.agent_id.is_(None),
            SMSNumber.client_id.is_(None),
            SMSNumber.is_active.is_(True),
            SMSNumber.status.in_(['available', 'reserved']),
            SMSNumber.status != 'test_pool'
        ).order_by(SMSNumber.id).with_for_update(skip_locked=True).limit(count).all()
        if not available:
            flash('No available numbers in this range!', 'warning')
            return redirect(url_for('admin.add_numbers_to_agent'))
        added = 0
        for num in available:
            num.agent_id = agent_id
            num.status = 'reserved'
            num.assigned_at = datetime.utcnow()
            added += 1
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash('Numbers could not be added because another operation changed the range. Please retry.', 'danger')
            return redirect(url_for('admin.add_numbers_to_agent'))
        ActivityLog.log(
            current_user.id,
            'admin_add_numbers_to_agent',
            f'Added {added} numbers from {sms_range.prefix} to agent {agent.username}',
            ip_address=request.remote_addr
        )
        flash(f'{added} numbers added to {agent.username} successfully!', 'success')
        return redirect(url_for('admin.add_numbers_to_agent'))
    return render_template('admin/add_numbers_to_agent.html',
        agents=agents, ranges=ranges, search=search)

# ============ AGENT ROUTES ============

@admin_bp.route('/agent/add-numbers', methods=['GET', 'POST'])
@login_required
def agent_add_numbers():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        range_id = request.form.get('range_id', type=int)
        numbers_count = request.form.get('numbers_count', 0, type=int)
        if not range_id or numbers_count < 1 or numbers_count > 10000:
            flash('Please select a range.', 'danger')
            return redirect(url_for('admin.agent_add_numbers'))
        sms_range = SMDRange.query.get(range_id)
        if not sms_range:
            flash('Invalid range.', 'danger')
            return redirect(url_for('admin.agent_add_numbers'))
        if sms_range.daily_limit > 0:
            today_taken = SMSNumber.query.filter(
                SMSNumber.agent_id == current_user.id,
                SMSNumber.range_id == range_id,
                db.func.date(SMSNumber.assigned_at) == date.today()
            ).count()
            daily_remaining = sms_range.daily_limit - today_taken
            if daily_remaining <= 0:
                flash(f'Daily limit reached! Limit: {sms_range.daily_limit}/day', 'danger')
                return redirect(url_for('admin.agent_add_numbers'))
            numbers_count = min(numbers_count, daily_remaining)
        ensure_test_pool(sms_range)
        available_numbers = SMSNumber.query.filter_by(
            range_id=range_id,
            agent_id=None,
            client_id=None,
            is_active=True
        ).filter(
            SMSNumber.status.in_(['available', 'reserved']),
            SMSNumber.status != 'test_pool'
        ).order_by(SMSNumber.id).with_for_update(skip_locked=True).limit(numbers_count).all()
        if not available_numbers:
            flash('No available numbers in this range.', 'warning')
            return redirect(url_for('admin.agent_add_numbers'))
        numbers_added = 0
        for num in available_numbers:
            num.agent_id = current_user.id
            num.status = 'reserved'
            num.assigned_at = datetime.utcnow()
            numbers_added += 1
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash('Numbers could not be added because another operation changed the range. Please retry.', 'danger')
            return redirect(url_for('admin.agent_add_numbers'))
        ActivityLog.log(
            current_user.id,
            'agent_add_numbers',
            f'Added {numbers_added} numbers from range {sms_range.prefix}',
            ip_address=request.remote_addr
        )
        flash(f'{numbers_added} numbers added successfully!', 'success')
        return redirect(url_for('admin.agent_my_numbers'))

    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    search = request.args.get('search', '')
    ranges_query = SMDRange.query.filter_by(is_active=True)
    if search:
        ranges_query = ranges_query.filter(
            db.or_(
                SMDRange.name.like(f'%{search}%'),
                SMDRange.country.like(f'%{search}%'),
                SMDRange.prefix.like(f'%{search}%')
            )
        )
    ranges_query = ranges_query.order_by(SMDRange.country)

    if per_page == 99999:
        all_ranges = ranges_query.all()
        class FakePaginate:
            def __init__(self, items):
                self.items = items
                self.total = len(items)
                self.page = 1
                self.pages = 1
                self.has_prev = False
                self.has_next = False
                self.prev_num = None
                self.next_num = None
        ranges = FakePaginate(all_ranges)
    else:
        ranges = ranges_query.paginate(page=page, per_page=per_page, error_out=False)

    current_numbers = SMSNumber.query.filter_by(agent_id=current_user.id).count()
    return render_template('admin/agent_add_numbers.html',
        ranges=ranges,
        current_numbers=current_numbers,
        per_page=per_page
    )

@admin_bp.route('/agent/my-numbers')
@login_required
def agent_my_numbers():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    search = request.args.get('search', '')
    frange = request.args.get('frange', '')
    fclient = request.args.get('fclient', '')
    query = SMSNumber.query.filter_by(agent_id=current_user.id)
    if search:
        query = query.filter(SMSNumber.number.like(f'%{search}%'))
    if frange:
        query = query.filter_by(range_id=frange)
    if fclient == 'none':
        query = query.filter(SMSNumber.client_id.is_(None))
    elif fclient:
        query = query.filter_by(client_id=fclient)
    if per_page == 99999:
        all_numbers = query.order_by(SMSNumber.number).all()
        class FakePaginate:
            def __init__(self, items):
                self.items = items
                self.total = len(items)
                self.page = 1
                self.pages = 1
                self.has_prev = False
                self.has_next = False
                self.prev_num = None
                self.next_num = None
        numbers = FakePaginate(all_numbers)
    else:
        numbers = query.order_by(SMSNumber.number).paginate(
            page=page, per_page=per_page, error_out=False
        )
    total_numbers = SMSNumber.query.filter_by(agent_id=current_user.id).count()
    assigned_count = SMSNumber.query.filter(
        SMSNumber.agent_id == current_user.id,
        SMSNumber.client_id.isnot(None)
    ).count()
    free_count = total_numbers - assigned_count
    range_ids = [
        r[0] for r in db.session.query(SMSNumber.range_id)
        .filter(SMSNumber.agent_id == current_user.id, SMSNumber.range_id.isnot(None))
        .distinct().all()
    ]
    ranges = SMDRange.query.filter(SMDRange.id.in_(range_ids)).all() if range_ids else []
    clients = User.query.filter_by(agent_id=current_user.id).all()
    return render_template('admin/agent_my_numbers.html',
        numbers=numbers,
        total_numbers=total_numbers,
        assigned_count=assigned_count,
        free_count=free_count,
        ranges=ranges,
        clients=clients,
        per_page=per_page
    )

@admin_bp.route('/agent/bulk-assign', methods=['POST'])
@login_required
def agent_bulk_assign():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    number_ids = request.form.getlist('number_ids')
    client_id = request.form.get('client_id', type=int)
    client_payout = request.form.get('client_payout', 0.0, type=float)
    if not number_ids:
        flash('No numbers selected!', 'danger')
        return redirect(url_for('admin.agent_my_numbers'))
    if not client_id:
        flash('Please select a client!', 'danger')
        return redirect(url_for('admin.agent_my_numbers'))
    client = User.query.get(client_id)
    if not client or client.agent_id != current_user.id:
        flash('Invalid client!', 'danger')
        return redirect(url_for('admin.agent_my_numbers'))
    assigned = 0
    skipped = 0
    for nid in number_ids:
        num = SMSNumber.query.get(int(nid))
        if num and num.agent_id == current_user.id:
            if num.client_id and num.client_id != client_id:
                skipped += 1
                continue
            num.client_id = client_id
            num.client_payout = client_payout
            num.status = 'activated'
            num.assigned_at = datetime.utcnow()
            assigned += 1
    db.session.commit()
    msg = f'{assigned} numbers assigned to {client.username} at ${client_payout}/OTP!'
    if skipped > 0:
        msg += f' ({skipped} skipped — already assigned to another client)'
    flash(msg, 'success')
    return redirect(url_for('admin.agent_my_numbers'))

@admin_bp.route('/agent/bulk-unassign', methods=['POST'])
@login_required
def agent_bulk_unassign():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    number_ids = request.form.getlist('number_ids')
    if not number_ids:
        flash('No numbers selected!', 'danger')
        return redirect(url_for('admin.agent_my_numbers'))
    done = 0
    for nid in number_ids:
        num = SMSNumber.query.get(int(nid))
        if num and num.agent_id == current_user.id:
            num.client_id = None
            num.client_payout = 0.0
            num.status = 'reserved'
            done += 1
    db.session.commit()
    flash(f'{done} numbers unassigned!', 'success')
    return redirect(url_for('admin.agent_my_numbers'))

@admin_bp.route('/agent/return-numbers', methods=['POST'])
@login_required
def agent_return_numbers():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    number_ids = request.form.getlist('number_ids')
    if not number_ids:
        flash('No numbers selected!', 'danger')
        return redirect(url_for('admin.agent_my_numbers'))
    done = 0
    for nid in number_ids:
        num = SMSNumber.query.get(int(nid))
        if num and num.agent_id == current_user.id:
            num.agent_id = None
            num.client_id = None
            num.client_payout = 0.0
            num.agent_payout = 0.0
            num.status = 'available'
            num.assigned_at = None
            done += 1
    db.session.commit()
    flash(f'{done} numbers returned to range!', 'success')
    return redirect(url_for('admin.agent_my_numbers'))

@admin_bp.route('/agent/download-numbers', methods=['POST'])
@login_required
def agent_download_numbers():
    number_ids = request.form.getlist('number_ids')
    if number_ids:
        numbers = SMSNumber.query.filter(
            SMSNumber.id.in_([int(x) for x in number_ids]),
            SMSNumber.agent_id == current_user.id
        ).all()
    else:
        numbers = SMSNumber.query.filter_by(agent_id=current_user.id).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Number', 'Range', 'Client', 'Status', 'OTP Price', 'Assigned At'])
    for num in numbers:
        writer.writerow([
            num.number,
            f"+{num.sms_range.prefix} - {num.sms_range.country}" if num.sms_range else '',
            num.client.username if num.client else 'Unassigned',
            num.status,
            num.client_payout,
            num.assigned_at.strftime('%Y-%m-%d %H:%M') if num.assigned_at else ''
        ])
    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=numbers.csv'}
    )

@admin_bp.route('/agent/create-client', methods=['GET', 'POST'])
@login_required
def agent_create_client():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        company = request.form.get('company')
        country = request.form.get('country')
        if not username or not email or not password:
            flash('Username, email, and password are required.', 'danger')
            return redirect(url_for('admin.agent_create_client'))
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.agent_create_client'))
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return redirect(url_for('admin.agent_create_client'))
        client_role = Role.query.filter_by(name='client').first()
        if not client_role:
            flash('Client role not found.', 'danger')
            return redirect(url_for('admin.agent_create_client'))
        client = User(
            username=username,
            email=email,
            role_id=client_role.id,
            name=name,
            company=company,
            country=country,
            agent_id=current_user.id,
            is_active=True
        )
        client.set_password(password)
        db.session.add(client)
        db.session.commit()
        ActivityLog.log(
            current_user.id,
            'agent_create_client',
            f'Created client {username}',
            ip_address=request.remote_addr
        )
        flash(f'Client {username} created successfully!', 'success')
        return redirect(url_for('admin.agent_clients'))
    return render_template('admin/agent_create_client.html')

@admin_bp.route('/agent/clients')
@login_required
def agent_clients():
    if not (current_user.is_agent() or current_user.is_admin()):
        flash('Access denied.', 'danger')
        return redirect(url_for('main.dashboard'))
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    query = User.query.filter_by(agent_id=current_user.id)
    if search:
        query = query.filter(
            db.or_(
                User.username.like(f'%{search}%'),
                User.email.like(f'%{search}%'),
                User.name.like(f'%{search}%')
            )
        )
    clients = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    return render_template('admin/agent_clients.html', clients=clients)
