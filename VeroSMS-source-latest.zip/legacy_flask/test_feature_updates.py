import os
import sys
import unittest
from datetime import datetime, timedelta
from io import BytesIO

os.environ["ENABLE_SCHEDULER"] = "false"
sys.path.insert(0, os.path.dirname(__file__))

from app import bcrypt, create_app, db
from app.models.sms import SMDRange, SMSNumber, TestNumberAssignment
from app.models.provider import OTPLog
from app.models.user import Role, User
from app.scheduler_jobs import auto_return_low_traffic_numbers
from app.services_number_lifecycle import sync_test_number, add_test_numbers_for_user
from app.routes.admin import _parse_user_export


class FeatureUpdateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app("testing")
        cls.ctx = cls.app.app_context()
        cls.ctx.push()

    @classmethod
    def tearDownClass(cls):
        db.session.remove()
        cls.ctx.pop()

    def tearDown(self):
        db.session.rollback()

    def test_required_routes_are_registered(self):
        routes = {rule.rule for rule in self.app.url_map.iter_rules()}
        self.assertIn("/api/sms/ranges", routes)
        self.assertIn("/api/sms/numbers/request", routes)
        self.assertIn("/api-access", routes)
        self.assertIn("/sms/numbers/return", routes)
        self.assertIn("/agent/api-docs", routes)
        self.assertIn("/reset-password", routes)
        self.assertIn("/ranges/<int:range_id>/test-numbers", routes)

    def test_reset_password_requires_username_email_then_new_password(self):
        role = Role.query.filter_by(name="client").one()
        user = User(
            username="reset_unit_user",
            email="reset-unit@example.test",
            role=role,
            is_active=True,
            password_hash=bcrypt.generate_password_hash("oldpass123").decode("utf-8"),
        )
        db.session.add(user)
        db.session.commit()
        client = self.app.test_client()

        first = client.post("/reset-password", data={"username": "reset_unit_user"})
        self.assertEqual(first.status_code, 302)
        second = client.post("/reset-password", data={"email": "reset-unit@example.test"})
        self.assertEqual(second.status_code, 302)
        third = client.post("/reset-password", data={"password": "newpass123", "password_confirm": "newpass123"})
        self.assertEqual(third.status_code, 302)
        self.assertTrue(User.query.filter_by(username="reset_unit_user").one().check_password("newpass123"))

    def test_user_export_parser_reads_attached_backup_format(self):
        export = """USER EXPORT
========================================================================
ID: 1 | Username: demo_agent | Role: agent
Name: Demo Agent | Email: demo@example.test | Active: True
Agent:  | Company: Demo Co | Country: Indonesia
Contact:  | Address:  | Skype:
SMS count/limit: 0/100 | Assigned numbers: 0
API enabled: False | Created: 2026-09-24T19:34:14
------------------------------------------------------------------------
"""
        rows = _parse_user_export(export)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["username"], "demo_agent")
        self.assertEqual(rows[0]["role"], "agent")
        self.assertEqual(rows[0]["sms_limit"], "100")
        self.assertEqual(rows[0]["api_enabled"], "False")

    def test_api_is_denied_until_admin_enables_it(self):
        user = User.query.filter_by(username="admin").one()
        user.api_token = "unit-api-token"
        user.api_enabled = False
        db.session.commit()
        client = self.app.test_client()
        denied = client.get("/api/sms/cdr/stats", headers={"X-API-Token": "unit-api-token"})
        self.assertEqual(denied.status_code, 403)
        user.api_enabled = True
        db.session.commit()
        allowed = client.get("/api/sms/cdr/stats", headers={"X-API-Token": "unit-api-token"})
        self.assertEqual(allowed.status_code, 200)
        user.api_enabled = False
        user.api_token = None
        db.session.commit()

    def test_admin_can_import_text_user_backup(self):
        admin = User.query.filter_by(username="admin").one()
        client = self.app.test_client()
        with client.session_transaction() as session:
            session["_user_id"] = str(admin.id)
            session["_fresh"] = True

        csv_data = b"username,email,password,role,name,is_active\nbackup_user,backup@example.test,Backup123!,client,Backup User,true\n"
        response = client.post(
            "/users/import-backup",
            data={"backup_file": (BytesIO(csv_data), "users.csv")},
            content_type="multipart/form-data",
        )

        self.assertEqual(response.status_code, 302)
        imported = User.query.filter_by(username="backup_user").one()
        self.assertTrue(imported.check_password("Backup123!"))
        self.assertEqual(imported.role.name, "client")

    def test_range_test_number_is_assigned_to_test_account(self):
        test_user = User.query.filter_by(username="test").one()
        sms_range = SMDRange(name="Unit Test Range", prefix="999", country="Testland", is_active=True)
        db.session.add(sms_range)
        db.session.flush()
        number = sync_test_number(sms_range, "999123456")
        db.session.commit()

        self.assertIsNotNone(number)
        self.assertEqual(number.client_id, test_user.id)
        self.assertEqual(number.status, "test")
        self.assertEqual(number.number, "999123456")

    def test_fixed_test_pool_is_shared_and_idempotent(self):
        role = Role.query.filter_by(name="client").one()
        user = User(
            username="pool_unit_user",
            email="pool-unit@example.test",
            password_hash=bcrypt.generate_password_hash("poolpass123").decode("utf-8"),
            role=role,
            is_active=True,
        )
        sms_range = SMDRange(name="Pool Range", prefix="997", country="Testland", is_active=True)
        db.session.add_all([user, sms_range])
        db.session.flush()
        db.session.add_all([
            SMSNumber(
                range_id=sms_range.id,
                number=f"997000{i:04d}",
                prefix="997",
                status="available",
                is_active=True,
            )
            for i in range(12)
        ])
        db.session.flush()

        first = add_test_numbers_for_user(user, sms_range)
        db.session.commit()
        second = add_test_numbers_for_user(user, sms_range)
        db.session.commit()
        assignments = TestNumberAssignment.query.filter_by(
            user_id=user.id, range_id=sms_range.id
        ).all()
        pool_numbers = SMSNumber.query.filter_by(range_id=sms_range.id, status="test_pool").all()

        self.assertEqual(len(first), 10)
        self.assertEqual(len(second), 0)
        self.assertEqual(len(assignments), 10)
        self.assertEqual(len(pool_numbers), 10)

    def test_admin_can_save_test_numbers_from_multiline_note(self):
        admin = User.query.filter_by(username="admin").one()
        sms_range = SMDRange(name="Manual Test", prefix="20", country="Egypt", is_active=True)
        db.session.add(sms_range)
        db.session.commit()
        range_id = sms_range.id
        admin_id = admin.id
        client = self.app.test_client()
        with client.session_transaction() as session:
            session["_user_id"] = str(admin_id)
            session["_fresh"] = True
        response = client.post(
            f"/ranges/{range_id}/test-numbers",
            data={"test_numbers": "201012345678\n+201012345679\n+201012345678"},
        )
        self.assertEqual(response.status_code, 302)
        pool = SMSNumber.query.filter_by(range_id=range_id, status="test_pool").all()
        self.assertEqual(len(pool), 2)
        self.assertEqual({item.number for item in pool}, {"201012345678", "201012345679"})

    def test_admin_news_create_page_is_available(self):
        admin = User.query.filter_by(username="admin").one()
        client = self.app.test_client()
        with client.session_transaction() as session:
            session["_user_id"] = str(admin.id)
            session["_fresh"] = True
        response = client.get("/news/create")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Publish announcement", response.data)

    def test_admin_can_delete_range_with_historical_otp_log(self):
        admin = User.query.filter_by(username="admin").one()
        sms_range = SMDRange(name="Delete Range", prefix="996", country="Testland", is_active=True)
        db.session.add(sms_range)
        db.session.flush()
        number = SMSNumber(
            range_id=sms_range.id,
            number="996123456",
            prefix="996",
            status="available",
            is_active=True,
        )
        db.session.add(number)
        db.session.flush()
        range_id = sms_range.id
        number_id = number.id
        otp_log = OTPLog(number_id=number_id, number=number.number, otp="123456")
        db.session.add(otp_log)
        db.session.commit()
        otp_log_id = otp_log.id

        client = self.app.test_client()
        with client.session_transaction() as session:
            session["_user_id"] = str(admin.id)
            session["_fresh"] = True
        response = client.post(f"/ranges/{range_id}/delete")

        self.assertEqual(response.status_code, 302)
        self.assertIsNone(db.session.get(SMDRange, range_id))
        self.assertIsNone(db.session.get(SMSNumber, number_id))
        self.assertIsNone(db.session.get(OTPLog, otp_log_id).number_id)

    def test_auto_return_reclaims_low_traffic_number(self):
        role = Role.query.filter_by(name="agent").one()
        agent = User(
            username="unit_agent",
            email="unit-agent@example.test",
            password_hash=bcrypt.generate_password_hash("unit123").decode("utf-8"),
            role=role,
            is_active=True,
        )
        sms_range = SMDRange(name="Traffic Range", prefix="998", country="Testland", is_active=True)
        db.session.add_all([agent, sms_range])
        db.session.flush()
        number = SMSNumber(
            range_id=sms_range.id,
            number="998123456",
            prefix="998",
            agent_id=agent.id,
            status="reserved",
            assigned_at=datetime.utcnow() - timedelta(hours=2),
            is_active=True,
        )
        db.session.add(number)
        db.session.commit()

        returned = auto_return_low_traffic_numbers(self.app)
        db.session.refresh(number)
        self.assertGreaterEqual(returned, 1)
        self.assertIsNone(number.agent_id)
        self.assertEqual(number.status, "available")


if __name__ == "__main__":
    unittest.main(verbosity=2)
