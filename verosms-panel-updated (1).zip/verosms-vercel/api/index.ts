// Single catch-all serverless function (Vercel Hobby allows only 12 functions).
// Never touch `req.body` here: the app reads the raw request stream itself.
import type { IncomingMessage, ServerResponse } from 'http';
import { handle } from '../src/app';

export const config = { maxDuration: 60 };

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  await handle(req, res);
}
