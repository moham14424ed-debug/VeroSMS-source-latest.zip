import nunjucks from 'nunjucks';
import { templates } from './generated/assets';
import { Ctx, urlFor } from './http';

const loader = {
  getSource(name: string) {
    const src = templates[name];
    if (src === undefined) return null as any;
    return { src, path: name, noCache: false };
  },
};

export const env = new nunjucks.Environment(loader as any, { autoescape: true, throwOnUndefined: false });

// ── Jinja-compatible filters ──
function sprintf(fmt: string, ...args: any[]): string {
  let i = 0;
  return String(fmt).replace(/%([-+ 0#]*)(\d+)?(?:\.(\d+))?([sdifrx%])/g, (_m, flags: string, width: string, prec: string, type: string) => {
    if (type === '%') return '%';
    const arg = args[i++];
    let out: string;
    switch (type) {
      case 'd':
      case 'i':
        out = String(Math.trunc(Number(arg) || 0));
        break;
      case 'f': {
        const n = Number(arg);
        out = (Number.isFinite(n) ? n : 0).toFixed(prec === undefined ? 6 : Number(prec));
        break;
      }
      case 'x':
        out = Math.trunc(Number(arg) || 0).toString(16);
        break;
      default:
        out = String(arg ?? '');
    }
    if (flags.includes('+') && /^\d/.test(out)) out = '+' + out;
    if (width) out = flags.includes('-') ? out.padEnd(+width) : out.padStart(+width, flags.includes('0') ? '0' : ' ');
    return out;
  });
}
env.addFilter('format', (fmt: string, ...args: any[]) => sprintf(fmt, ...args));
env.addFilter('max', (a: any) => (Array.isArray(a) && a.length ? Math.max(...a) : a));
env.addFilter('min', (a: any) => (Array.isArray(a) && a.length ? Math.min(...a) : a));
env.addFilter('tojson', (v: any) =>
  new nunjucks.runtime.SafeString(
    JSON.stringify(v ?? null).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029'),
  ),
);
/** Python-style `text[:n]` replacement: `{{ text|cut(60) }}` */
env.addFilter('cut', (s: any, n: number) => (s === null || s === undefined ? '' : String(s).slice(0, n)));
env.addFilter('money', (v: any, d = 4) => (Number(v) || 0).toFixed(d));

export interface RenderCtx {
  c: Ctx;
  data?: Record<string, any>;
}

const anonymous = {
  is_authenticated: false,
  username: '',
  is_admin: () => false,
  is_agent: () => false,
  is_client: () => false,
  is_developer: () => false,
};

export function renderTemplate(c: Ctx, name: string, data: Record<string, any> = {}): string {
  const flashes = () => c.popFlashes();
  const request = {
    args: c.query,
    endpoint: c.endpoint,
    path: c.path,
    base_url: c.baseUrl,
    url_root: c.baseUrl + '/',
    method: c.method,
  };
  const ctx = {
    request,
    current_user: c.user || anonymous,
    url_for: (endpoint: string, kw?: any) => {
      const { __keywords, ...params } = kw && typeof kw === 'object' ? kw : ({} as any);
      return urlFor(endpoint, params);
    },
    get_flashed_messages: (arg?: any) => {
      const withCats = arg === true || (arg && arg.with_categories);
      const list = flashes();
      return withCats ? list : list.map((x) => x[1]);
    },
    ...data,
  };
  return env.render(name, ctx);
}

export function render(c: Ctx, name: string, data: Record<string, any> = {}, status = 200) {
  c.html(renderTemplate(c, name, data), status);
}
