import { Queryable, Row, tx } from '../db';
import { UserError, startOfUtcDay } from '../util';
import { ensureTestPool } from './lifecycle';

export type OwnerRole = 'agent' | 'client';

/**
 * Atomically assigns up to `count` free numbers of a range to a user.
 * Rows are locked with FOR UPDATE SKIP LOCKED, so two people can never get the same number.
 */
export async function allocateFromRange(
  t: Queryable,
  opts: { range: Row; role: OwnerRole; ownerId: number; count: number; random?: boolean },
): Promise<Row[]> {
  const { range, role, ownerId, count, random } = opts;
  if (count < 1) return [];
  await ensureTestPool(t, range); // keep the 10 quality-test numbers out of the sellable pool
  const ownerCol = role === 'agent' ? 'agent_id' : 'client_id';
  const status = role === 'agent' ? 'reserved' : 'activated';
  const payoutCol = role === 'agent' ? 'agent_payout' : 'client_payout';
  return t.query(
    `update sms_numbers set ${ownerCol} = $2, status = $3, assigned_at = now(), ${payoutCol} = $4
     where id in (
       select id from sms_numbers
       where range_id = $1 and agent_id is null and client_id is null and is_active
         and status in ('available','reserved')
       order by ${random ? 'random()' : 'id'}
       limit $5 for update skip locked)
     returning id, number`,
    [range.id, ownerId, status, Number(range.payout) || 0, count],
  );
}

export interface QuotaInfo {
  range_id: number;
  total_limit: number;
  taken_count: number;
  daily_limit: number;
  remaining: number;
}

/**
 * Self-service: a user takes `count` random numbers of a range, bounded by the limit the
 * administrator granted to that user for that range. Throws UserError with a readable reason.
 */
export async function requestNumbers(user: { id: number; role: OwnerRole }, rangeId: number, wanted: number) {
  if (!Number.isInteger(wanted) || wanted < 1) throw new UserError('Enter a valid quantity.');
  return tx(async (t) => {
    const range = await t.one(`select * from sms_ranges where id = $1 and is_active`, [rangeId]);
    if (!range) throw new UserError('This range is not available.');
    const limit = await t.one(`select * from agent_range_limits where agent_id = $1 and range_id = $2 for update`, [user.id, rangeId]);
    if (!limit || Number(limit.total_limit) <= 0) {
      throw new UserError('You have no limit on this range yet. Contact the administrator to get one.');
    }
    let allowed = Number(limit.total_limit) - Number(limit.taken_count);
    if (allowed <= 0) {
      throw new UserError(`You reached your limit on this range (${limit.total_limit} numbers). Contact the administrator to increase it.`);
    }
    if (Number(limit.daily_limit) > 0) {
      const today = Number(
        await t.scalar(`select count(*) from sms_numbers where range_id = $1 and (agent_id = $2 or client_id = $2) and assigned_at >= $3`, [rangeId, user.id, startOfUtcDay()]),
      );
      const dailyLeft = Number(limit.daily_limit) - today;
      if (dailyLeft <= 0) throw new UserError(`Daily limit reached for this range (${limit.daily_limit}/day). Try again tomorrow.`);
      allowed = Math.min(allowed, dailyLeft);
    }
    const take = Math.min(wanted, allowed);
    const got = await allocateFromRange(t, { range, role: user.role, ownerId: user.id, count: take, random: true });
    if (!got.length) throw new UserError('No free numbers are available in this range right now.');
    await t.exec(`update agent_range_limits set taken_count = taken_count + $3 where agent_id = $1 and range_id = $2`, [user.id, rangeId, got.length]);
    return { range, got, requested: wanted, clamped: take < wanted, remaining: allowed - got.length };
  });
}

/** Limits of one user across ranges (for the user page and the admin editor). */
export async function limitsForUser(q: Queryable, userId: number): Promise<Row[]> {
  return q.query(
    `select r.id, r.name, r.prefix, r.country, r.operator, r.payout, r.is_active,
            coalesce(l.total_limit, 0) as total_limit, coalesce(l.taken_count, 0) as taken_count,
            coalesce(l.daily_limit, 0) as daily_limit,
            greatest(coalesce(l.total_limit, 0) - coalesce(l.taken_count, 0), 0) as remaining,
            (select count(*) from sms_numbers n where n.range_id = r.id and n.agent_id is null and n.client_id is null
               and n.is_active and n.status in ('available','reserved')) as available
     from sms_ranges r
     left join agent_range_limits l on l.range_id = r.id and l.agent_id = $1
     where r.is_active
     order by r.country, r.prefix`,
    [userId],
  );
}

export async function setLimit(q: Queryable, userId: number, rangeId: number, total: number, daily = 0, resetTaken = false) {
  await q.exec(
    `insert into agent_range_limits (agent_id, range_id, total_limit, daily_limit, taken_count)
     values ($1,$2,$3,$4,0)
     on conflict (agent_id, range_id) do update
       set total_limit = excluded.total_limit, daily_limit = excluded.daily_limit,
           taken_count = case when $5::boolean then 0 else agent_range_limits.taken_count end`,
    [userId, rangeId, Math.max(0, total), Math.max(0, daily), resetTaken],
  );
}
