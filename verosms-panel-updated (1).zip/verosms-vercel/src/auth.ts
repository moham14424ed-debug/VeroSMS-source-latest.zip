import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { Ctx, Handler, signValue, safeEqual, urlFor } from './http';
import { db } from './db';
import { getUserById } from './models';

export const hashPassword = (pw: string) => bcrypt.hash(pw, 12);
export const checkPassword = async (pw: string, hash: string) => {
  try {
    return await bcrypt.compare(pw, hash);
  } catch {
    return false;
  }
};

/** Fingerprint of the stored hash: changing the password invalidates old cookies. */
export const pwFingerprint = (hash: string) => crypto.createHash('sha256').update(hash).digest('base64url').slice(0, 12);

/** Runs before every request: loads the logged-in user (if any) into `c.user`. */
export async function loadUser(c: Ctx): Promise<void> {
  const uid = c.session.uid;
  if (!uid) return;
  const row = await db.one(`select password_hash, is_active from users where id = $1`, [uid]);
  if (!row || !row.is_active || pwFingerprint(row.password_hash) !== c.session.pv) {
    c.setSession({ uid: undefined, pv: undefined });
    return;
  }
  c.user = await getUserById(uid);
}

export function loginUser(c: Ctx, user: { id: number }, passwordHash: string) {
  c.setSession({ uid: user.id, pv: pwFingerprint(passwordHash) });
}

export const logoutUser = (c: Ctx) => c.setSession({ uid: undefined, pv: undefined });

// ── guards ──
export const loginRequired: Handler = (c) => {
  if (c.user) return;
  c.flash('Please log in to access this page.', 'warning');
  c.redirect(urlFor('auth.login', c.method === 'GET' && c.path !== '/' ? { next: c.path } : {}));
  return false;
};

const deny = (c: Ctx, message: string) => {
  c.flash(message, 'danger');
  c.redirect(urlFor('main.dashboard'));
  return false;
};

export const adminRequired: Handler = (c) => {
  if (loginRequired(c) === false) return false;
  if (!c.user.is_admin()) return deny(c, 'Admin access required.');
};
export const agentRequired: Handler = (c) => {
  if (loginRequired(c) === false) return false;
  if (!(c.user.is_agent() || c.user.is_admin())) return deny(c, 'Access denied.');
};
export const devRequired: Handler = (c) => {
  if (loginRequired(c) === false) return false;
  if (!(c.user.is_admin() || c.user.is_developer())) return deny(c, 'Developer or Admin access required.');
};
export const notClient: Handler = (c) => {
  if (loginRequired(c) === false) return false;
  if (c.user.is_client()) return deny(c, 'Access denied!');
};
export const clientOnly: Handler = (c) => {
  if (loginRequired(c) === false) return false;
  if (!c.user.is_client()) return deny(c, 'Access denied.');
};
/** Agents and clients can self-serve numbers; plain admins/developers use the admin pages. */
export const memberRequired: Handler = (c) => {
  if (loginRequired(c) === false) return false;
  if (!(c.user.is_agent() || c.user.is_client() || c.user.is_admin())) return deny(c, 'Access denied.');
};

// ── login captcha (signed so it cannot be forged and survives multiple tabs) ──
export function newCaptcha() {
  const a = crypto.randomInt(1, 10);
  const b = crypto.randomInt(1, 10);
  const exp = Math.floor(Date.now() / 1000) + 20 * 60;
  return { a, b, exp, sig: signValue(`captcha:${a}:${b}:${exp}`) };
}
export function verifyCaptcha(a: number, b: number, exp: number, sig: string, answer: string): boolean {
  if (!(a >= 1 && a <= 9 && b >= 1 && b <= 9) || exp < Date.now() / 1000) return false;
  if (!safeEqual(sig || '', signValue(`captcha:${a}:${b}:${exp}`))) return false;
  return Number(answer.trim()) === a + b && /^\d+$/.test(answer.trim());
}
