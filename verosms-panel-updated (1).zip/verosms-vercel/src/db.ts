import { Pool, PoolClient, types } from 'pg';
import { config } from './config';

/**
 * Date that mimics the bits of Python's datetime used by the Jinja templates
 * (`created_at.strftime('%Y-%m-%d %H:%M')`). Values are always UTC.
 */
export class PyDate extends Date {
  strftime(fmt: string): string {
    const p2 = (n: number) => String(n).padStart(2, '0');
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return String(fmt).replace(/%([a-zA-Z%])/g, (_m, c: string) => {
      switch (c) {
        case 'Y': return String(this.getUTCFullYear());
        case 'y': return p2(this.getUTCFullYear() % 100);
        case 'm': return p2(this.getUTCMonth() + 1);
        case 'd': return p2(this.getUTCDate());
        case 'H': return p2(this.getUTCHours());
        case 'I': return p2(this.getUTCHours() % 12 || 12);
        case 'M': return p2(this.getUTCMinutes());
        case 'S': return p2(this.getUTCSeconds());
        case 'p': return this.getUTCHours() < 12 ? 'AM' : 'PM';
        case 'B': return months[this.getUTCMonth()];
        case 'b': return months[this.getUTCMonth()].slice(0, 3);
        case 'A': return days[this.getUTCDay()];
        case 'a': return days[this.getUTCDay()].slice(0, 3);
        case '%': return '%';
        default: return '%' + c;
      }
    });
  }
  isoformat(): string {
    return this.toISOString().replace('Z', '');
  }
  toString(): string {
    return this.strftime('%Y-%m-%d %H:%M:%S');
  }
}

// timestamptz / timestamp → PyDate (UTC); bigint & numeric → number
types.setTypeParser(1184, (v: string) => new PyDate(v));
types.setTypeParser(1114, (v: string) => new PyDate(v.replace(' ', 'T') + 'Z'));
types.setTypeParser(20, (v: string) => parseInt(v, 10));
types.setTypeParser(1082, (v: string) => v); // date → 'YYYY-MM-DD'
types.setTypeParser(1700, (v: string) => parseFloat(v));

export type Row = Record<string, any>;
export interface Queryable {
  query<T = Row>(text: string, params?: any[]): Promise<T[]>;
  one<T = Row>(text: string, params?: any[]): Promise<T | null>;
  scalar<T = any>(text: string, params?: any[]): Promise<T | null>;
  exec(text: string, params?: any[]): Promise<number>;
}

let pool: Pool | null = null;

function buildPool(): Pool {
  const raw = config.databaseUrl;
  if (!raw) throw new Error('DATABASE_URL is not configured');
  const u = new URL(raw);
  const sslmode = (u.searchParams.get('sslmode') || '').toLowerCase();
  u.searchParams.delete('sslmode');
  const local = ['localhost', '127.0.0.1', '::1'].includes(u.hostname);
  const useSsl = sslmode ? sslmode !== 'disable' : !local;
  const p = new Pool({
    connectionString: u.toString(),
    // Managed PostgreSQL providers may use certificates not trusted by Node.
    ssl: useSsl ? { rejectUnauthorized: false } : false,
    max: Number(process.env.PG_POOL_MAX || 3),
    idleTimeoutMillis: 8000,
    connectionTimeoutMillis: 10000,
    statement_timeout: 25000,
  });
  p.on('error', (err: Error) => console.error('[pg] idle client error', err.message));
  return p;
}

export function getPool(): Pool {
  if (!pool) pool = buildPool();
  return pool;
}

export async function closePool(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
  }
}

function norm(params?: any[]): any[] {
  return (params || []).map((v) => {
    if (v === undefined) return null;
    if (v instanceof Date) return v.toISOString();
    return v;
  });
}

function wrap(run: (text: string, params: any[]) => Promise<{ rows: any[]; rowCount: number | null }>): Queryable {
  return {
    async query(text, params) {
      return (await run(text, norm(params))).rows as any;
    },
    async one(text, params) {
      const rows = (await run(text, norm(params))).rows;
      return (rows[0] as any) ?? null;
    },
    async scalar(text, params) {
      const rows = (await run(text, norm(params))).rows;
      if (!rows.length) return null;
      const first = rows[0];
      return first[Object.keys(first)[0]] ?? null;
    },
    async exec(text, params) {
      const r = await run(text, norm(params));
      return r.rowCount ?? 0;
    },
  } as Queryable;
}

export const db: Queryable = wrap((text, params) => getPool().query(text, params));

/** Runs `fn` inside a transaction (BEGIN/COMMIT, ROLLBACK on error). */
export async function tx<T>(fn: (t: Queryable) => Promise<T>): Promise<T> {
  const client: PoolClient = await getPool().connect();
  try {
    await client.query('BEGIN');
    const t = wrap((text, params) => client.query(text, params));
    const result = await fn(t);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch {
      /* ignore */
    }
    throw err;
  } finally {
    client.release();
  }
}

export function isUniqueViolation(err: any): boolean {
  return !!err && err.code === '23505';
}

/** Escapes LIKE wildcards in user supplied search text. */
export function likeEscape(s: string): string {
  return s.replace(/[\\%_]/g, (m) => '\\' + m);
}
