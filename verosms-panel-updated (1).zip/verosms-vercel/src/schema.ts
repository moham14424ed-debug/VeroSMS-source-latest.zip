import crypto from 'crypto';
import { db, tx } from './db';
import { config } from './config';
import { schemaSql } from './generated/assets';
import { hashPassword } from './auth';

export const SCHEMA_VERSION = '2026-10-16.1';

let ready: Promise<void> | null = null;

/** Creates / upgrades the schema once per cold start, then seeds roles and default accounts. */
export function ensureReady(): Promise<void> {
  if (!ready) {
    ready = init().catch((e) => {
      ready = null;
      throw e;
    });
  }
  return ready;
}

async function currentVersion(): Promise<string | null> {
  try {
    return (await db.scalar<string>(`select value from app_meta where key = 'schema_version'`)) ?? null;
  } catch (e: any) {
    if (e && e.code === '42P01') return null; // table does not exist yet
    throw e;
  }
}

async function init() {
  if ((await currentVersion()) !== SCHEMA_VERSION) {
    await tx(async (t) => {
      await t.exec('select pg_advisory_xact_lock(727274)');
      if ((await currentVersion()) === SCHEMA_VERSION) return; // another instance finished first
      await t.exec(schemaSql);
      await t.exec(
        `insert into app_meta (key, value) values ('schema_version', $1)
         on conflict (key) do update set value = excluded.value, updated_at = now()`,
        [SCHEMA_VERSION],
      );
    });
  }
  await seed();
}

async function seed() {
  const roleRows = await db.query(`select id, name from roles`);
  const roles = new Map(roleRows.map((r) => [r.name, r.id]));
  const hasAdmin = await db.scalar(`select 1 from users u join roles r on r.id = u.role_id where r.name = 'admin' limit 1`);
  if (!hasAdmin && roles.get('admin')) {
    let pw = config.adminPassword;
    const generated = !pw;
    if (generated) pw = crypto.randomBytes(9).toString('base64url');
    const taken = await db.scalar(`select 1 from users where username = 'admin'`);
    if (!taken) {
      await db.exec(
        `insert into users (username, email, password_hash, role_id, is_active) values ('admin', 'admin@panel.com', $1, $2, true)
         on conflict do nothing`,
        [await hashPassword(pw), roles.get('admin')],
      );
      if (generated) console.warn(`[setup] Created admin account. Username: admin  Password: ${pw}  (set ADMIN_PASSWORD to choose your own)`);
      else console.warn('[setup] Created admin account "admin" with the password from ADMIN_PASSWORD.');
    }
  }
  const testUser = await db.scalar(`select 1 from users where username = 'test'`);
  if (!testUser && roles.get('client')) {
    await db.exec(
      `insert into users (username, email, password_hash, role_id, is_active) values ('test', 'test@panel.local', $1, $2, true) on conflict do nothing`,
      [await hashPassword(config.testPassword), roles.get('client')],
    );
  }
}
