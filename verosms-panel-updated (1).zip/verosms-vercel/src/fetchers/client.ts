/** Tiny cookie-jar HTTP client on top of the global fetch (Node 18+). Session state can be serialised to the DB. */

export const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
export const BASE_HEADERS: Record<string, string> = {
  'User-Agent': UA,
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9',
};
export const AJAX_HEADERS: Record<string, string> = {
  'User-Agent': UA,
  Accept: 'application/json, text/javascript, */*; q=0.01',
  'Accept-Language': 'en-US,en;q=0.9',
  'X-Requested-With': 'XMLHttpRequest',
};

export interface Resp {
  status: number;
  url: string;
  text: string;
  contentType: string;
  history: string[];
}

export interface ReqOpts {
  method?: string;
  headers?: Record<string, string>;
  params?: Record<string, any>;
  form?: Record<string, any>;
  json?: any;
  timeout?: number;
  basicAuth?: [string, string];
}

export class Client {
  jar: Record<string, string>;
  host = '';
  constructor(jar: Record<string, string> = {}) {
    this.jar = { ...jar };
  }
  cookie(name: string): string | undefined {
    return this.jar[name];
  }
  private cookieHeader(): string {
    return Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join('; ');
  }
  private store(res: Response) {
    const list: string[] = (res.headers as any).getSetCookie?.() ?? [];
    for (const sc of list) {
      const [pair, ...attrs] = sc.split(';');
      const i = pair.indexOf('=');
      if (i < 1) continue;
      const name = pair.slice(0, i).trim();
      const val = pair.slice(i + 1).trim();
      const expired = attrs.some((a) => /^\s*max-age\s*=\s*0\s*$/i.test(a)) || val === 'deleted';
      if (expired) delete this.jar[name];
      else this.jar[name] = val;
    }
  }

  async request(url: string, o: ReqOpts = {}): Promise<Resp> {
    let method = (o.method || 'GET').toUpperCase();
    let cur = new URL(url);
    if (o.params) for (const [k, v] of Object.entries(o.params)) cur.searchParams.set(k, v == null ? '' : String(v));
    if (!this.host) this.host = cur.host;
    let body: string | undefined;
    const headers: Record<string, string> = { ...BASE_HEADERS, ...(o.headers || {}) };
    if (o.form) {
      body = new URLSearchParams(Object.entries(o.form).map(([k, v]) => [k, v == null ? '' : String(v)] as [string, string])).toString();
      headers['Content-Type'] = 'application/x-www-form-urlencoded';
    } else if (o.json !== undefined) {
      body = JSON.stringify(o.json);
      headers['Content-Type'] = 'application/json';
    }
    if (o.basicAuth) headers.Authorization = 'Basic ' + Buffer.from(`${o.basicAuth[0]}:${o.basicAuth[1]}`).toString('base64');

    const history: string[] = [];
    for (let hop = 0; hop < 8; hop++) {
      const h = { ...headers };
      if (cur.host === this.host && Object.keys(this.jar).length) h.Cookie = this.cookieHeader();
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), o.timeout ?? 20000);
      let res: Response;
      try {
        res = await fetch(cur, { method, headers: h, body: method === 'GET' || method === 'HEAD' ? undefined : body, redirect: 'manual', signal: ctrl.signal });
      } catch (e: any) {
        throw new Error(e?.name === 'AbortError' ? 'timeout' : `connection error: ${e?.cause?.code || e?.message || e}`);
      } finally {
        clearTimeout(timer);
      }
      if (cur.host === this.host) this.store(res);
      const loc = res.headers.get('location');
      if (res.status >= 300 && res.status < 400 && loc) {
        history.push(cur.toString());
        cur = new URL(loc, cur);
        if (res.status !== 307 && res.status !== 308) {
          method = 'GET';
          body = undefined;
          delete headers['Content-Type'];
        }
        continue;
      }
      const text = await res.text();
      return { status: res.status, url: cur.toString(), text, contentType: res.headers.get('content-type') || '', history };
    }
    throw new Error('too many redirects');
  }
  get(url: string, o: ReqOpts = {}) {
    return this.request(url, { ...o, method: 'GET' });
  }
  post(url: string, o: ReqOpts = {}) {
    return this.request(url, { ...o, method: 'POST' });
  }
}
