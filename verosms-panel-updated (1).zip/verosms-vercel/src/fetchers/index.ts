/** Provider polling: login (cached in DB), fetch, OTP detection, saving OTP logs + CDR rows. */
import { config } from '../config';
import { db, tx } from '../db';
import { digitsOnly, errMsg } from '../util';
import { Client } from './client';
import { FetchResult, panelFetch, panelLogin, Row, Session } from './panels';

export function detectOtp(text: string | null | undefined): string | null {
  if (!text) return null;
  const t = String(text).replace(/<#>\s*/g, '');
  let m = t.match(/(\d{3,4}-\d{3,4})(?!\d)/);
  if (m) return m[1];
  m = t.match(/(?:code|otp|pin|passcode|verif\w*|codigo|كود|رمز|رقم|Password|Confirmation)[^\d]*(\d{4,8})/i);
  if (m) return m[1];
  m = t.match(/:\s*(\d{4,8})\b/);
  if (m) return m[1];
  for (const mm of t.matchAll(/(?<![/\-\d])(\d{4,6})(?![/\-\d])/g)) {
    if (/^20\d\d$/.test(mm[1])) continue;
    return mm[1];
  }
  return null;
}

function jsonPath(value: any, path: string | null | undefined, dflt: any = undefined) {
  let cur = value;
  for (const part of (path || '').split('.')) {
    if (!part) continue;
    if (cur == null) return dflt;
    cur = Array.isArray(cur) ? cur[Number(part)] : cur[part];
    if (cur === undefined) return dflt;
  }
  return cur;
}
const subst = (v: any, u: string, p: string): any =>
  typeof v === 'string' ? v.split('{{username}}').join(u || '').split('{{password}}').join(p || '')
  : Array.isArray(v) ? v.map((x) => subst(x, u, p))
  : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, subst(x, u, p)]))
  : v;

/** Configurable JSON API provider. */
export async function apiFetch(p: any): Promise<Row[]> {
  let params: any, headers: any;
  try {
    params = subst(JSON.parse(p.request_params || '{}'), p.username, p.password);
    headers = subst(JSON.parse(p.request_headers || '{}'), p.username, p.password);
  } catch (e) {
    throw new Error(`Invalid provider JSON settings: ${errMsg(e)}`);
  }
  const method = (p.request_method || 'GET').toUpperCase();
  const fmt = p.request_format || 'query';
  const o: any = { method, headers: { Accept: 'application/json', ...headers }, timeout: 20000 };
  if ((p.auth_mode || '').toLowerCase() === 'basic' && (p.username || p.password)) o.basicAuth = [p.username || '', p.password || ''];
  if (method === 'GET' || fmt === 'query') o.params = params;
  else if (fmt === 'form') o.form = params;
  else o.json = params;
  const r = await new Client().request(p.url, o);
  if (r.status >= 400) throw new Error(`HTTP ${r.status} from provider`);
  let payload: any;
  try {
    payload = JSON.parse(r.text);
  } catch {
    throw new Error('Provider did not return JSON');
  }
  if (payload && !Array.isArray(payload) && payload.status === 'error') throw new Error(payload.msg || 'Provider API returned an error');
  let rows = jsonPath(payload, p.response_path || 'data', payload);
  if (rows && !Array.isArray(rows) && typeof rows === 'object') rows = [rows];
  if (!Array.isArray(rows)) return [];
  const out: Row[] = [];
  for (const row of rows) {
    const number = jsonPath(row, p.number_field || 'num', '');
    if (!number) continue;
    out.push({ number: String(number), cli: String(jsonPath(row, p.sender_field || 'cli', '') ?? ''), sms: String(jsonPath(row, p.message_field || 'message', '') ?? '') });
  }
  return out;
}

/** Stores one received OTP (deduplicated by number + otp) and mirrors it into the CDR of the number owner. */
export async function saveOtp(providerId: number | null, number: string, otp: string, sender: string, message: string): Promise<boolean> {
  const num = digitsOnly(number);
  if (!num) return false;
  return tx(async (t) => {
    await t.exec(`select pg_advisory_xact_lock(hashtext($1))`, [`otp:${num}:${otp}`]);
    if (await t.scalar(`select 1 from otp_logs where number = $1 and otp = $2 limit 1`, [num, otp])) return false;
    const last = num.slice(-10);
    const sn = await t.one(`select * from sms_numbers where number like $1 order by (number = $2) desc, id limit 1`, [`%${last}`, num]);
    const userId = sn ? sn.client_id || sn.agent_id : null;
    await t.exec(`insert into otp_logs (provider_id, number, otp, sender, message, number_id, user_id) values ($1,$2,$3,$4,$5,$6,$7)`, [providerId, num, otp, sender.slice(0, 255), message, sn?.id ?? null, userId]);
    if (sn) {
      const ap = Number(sn.agent_payout) || 0;
      const cp = Number(sn.client_payout) || 0;
      await t.exec(
        `insert into sms_cdr (number_id, range_id, user_id, client_id, caller_id, destination, cli, message, currency, agent_payout, client_payout, profit, sms_type, status)
         values ($1,$2,$3,$4,$5,$6,$5,$7,'USD',$8,$9,$10,'received','completed')`,
        [sn.id, sn.range_id, sn.agent_id, sn.client_id, sender.slice(0, 255), num, message, ap, cp, cp - ap],
      );
    }
    return true;
  });
}

export async function saveRows(providerId: number | null, rows: Row[]): Promise<number> {
  let saved = 0;
  for (const r of rows) {
    if (!r.number) continue;
    const otp = detectOtp(r.sms);
    if (!otp) continue;
    if (await saveOtp(providerId, r.number, otp, r.cli, r.sms)) saved++;
  }
  return saved;
}

async function runProvider(p: any): Promise<{ status: string; saved: number; error?: string }> {
  let rows: FetchResult;
  if (p.ptype === 'api') {
    rows = await apiFetch(p);
  } else {
    let sess: Session | null = null;
    try {
      sess = p.session_state ? JSON.parse(p.session_state) : null;
    } catch {}
    if (sess && sess.url !== p.url.replace(/\/+$/, '') && p.ptype !== 'konekta') sess = null;
    rows = sess ? await panelFetch(p.ptype, sess) : null;
    if (rows === null) {
      // no session or it expired → log in again once
      sess = await panelLogin(p.name, p.ptype, p.username, p.password, p.url);
      rows = await panelFetch(p.ptype, sess);
      if (rows === null) throw new Error('Session rejected right after login');
    }
    await db.exec(`update providers set session_state = $2 where id = $1`, [p.id, JSON.stringify(sess)]);
  }
  const saved = await saveRows(p.id, rows);
  return { status: 'ok', saved };
}

/** Claims the provider (atomic, so parallel pollers never double-fetch) and runs it. */
export async function pollProvider(id: number, force = false) {
  const claimed = await db.one(
    `update providers set last_fetch_at = timezone('utc', now())
     where id = $1 and (is_active or $2::boolean)
       and ($2::boolean or last_fetch_at is null or last_fetch_at < timezone('utc', now()) - make_interval(secs => greatest(fetch_interval, $3::int)))
     returning *`,
    [id, force, config.minFetchInterval],
  );
  if (!claimed) return null;
  let res: { status: string; saved: number; error?: string };
  try {
    res = await runProvider(claimed);
  } catch (e) {
    res = { status: 'error', saved: 0, error: errMsg(e).slice(0, 500) };
    await db.exec(`update providers set session_state = null where id = $1`, [id]).catch(() => {});
  }
  await db.exec(`update providers set last_status = $2, last_error = $3 where id = $1`, [id, res.status, res.error ?? null]).catch(() => {});
  return { id, name: claimed.name, ...res };
}

/** Polls every active provider that is due. Used by cron, the browser ticker and GitHub Actions. */
export async function pollDue(deadlineMs = 50000) {
  const ids = (await db.query(`select id from providers where is_active order by last_fetch_at nulls first`)).map((r) => r.id as number);
  const work = Promise.allSettled(ids.map((id) => pollProvider(id)));
  const timeout = new Promise<'timeout'>((r) => setTimeout(() => r('timeout'), deadlineMs));
  const out = await Promise.race([work, timeout]);
  if (out === 'timeout') return { providers: ids.length, results: [], timedOut: true };
  return { providers: ids.length, results: out.map((o) => (o.status === 'fulfilled' ? o.value : { status: 'error', error: errMsg((o as any).reason) })).filter(Boolean), timedOut: false };
}
