/** Ports of the supported SMS panel scrapers (login + CDR fetch). A session is {cookies, path, url}. */
import { AJAX_HEADERS, BASE_HEADERS, Client, Resp } from './client';

export interface Session {
  cookies: Record<string, string>;
  path: string;
  url: string;
}
export interface Row {
  number: string;
  cli: string;
  sms: string;
}
/** null = session expired (re-login needed) */
export type FetchResult = Row[] | null;

const LOGIN_SIGNALS = ['sign in', 'signin', 'please sign', 'log in', 'please login', 'authentication required', 'session expired', 'unauthorized', 'access denied'];
const INVALID = new Set(['None', '', 'null', '—', '****', '***', '**', '*', 'N/A', '$']);

const pad = (n: number) => String(n).padStart(2, '0');
const fmt = (d: Date) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
function dates(): [string, string] {
  const now = new Date();
  return [`${fmt(new Date(now.getTime() - 86400000))} 00:00:00`, `${fmt(now)} 23:59:59`];
}
const unescapeHtml = (s: string) =>
  s.replace(/&(#x?[0-9a-f]+|amp|lt|gt|quot|apos|nbsp);/gi, (m, g) => {
    const l = g.toLowerCase();
    if (l[0] === '#') return String.fromCodePoint(l[1] === 'x' ? parseInt(l.slice(2), 16) : parseInt(l.slice(1), 10));
    return ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' } as any)[l] ?? m;
  });

export function solveCaptcha(html: string): string {
  for (const re of [/What is\s*(\d+)\s*\+\s*(\d+)/i, /(\d+)\s*\+\s*(\d+)\s*=/i, /captcha[^>]*>\s*(\d+)\s*\+\s*(\d+)/i, />(\d+)\s*\+\s*(\d+)</i, /(\d+)\s*\+\s*(\d+)/i]) {
    const m = html.match(re);
    if (m) return String(+m[1] + +m[2]);
  }
  for (const re of [/What is\s*(\d+)\s*-\s*(\d+)/i, /(\d+)\s*-\s*(\d+)\s*=/i]) {
    const m = html.match(re);
    if (m) return String(Math.max(0, +m[1] - +m[2]));
  }
  const plain = html.replace(/<[^>]*>/g, ' ');
  let m = plain.match(/(\d+)\s*\+\s*(\d+)/);
  if (m) return String(+m[1] + +m[2]);
  m = plain.match(/(\d+)\s*-\s*(\d+)/);
  if (m) return String(Math.max(0, +m[1] - +m[2]));
  return '0';
}

function expired(r: Resp): boolean {
  if (r.status === 401 || r.status === 403) return true;
  const u = r.url.toLowerCase();
  if (['/login', '/signin', '/sign-in', '/auth/login'].some((x) => u.includes(x))) return true;
  const json = r.contentType.toLowerCase().includes('json');
  if (r.history.length) {
    const last = r.history[r.history.length - 1].toLowerCase();
    if (['/login', '/signin', '/sign-in'].some((x) => last.includes(x)) && !json) {
      const p = r.text.slice(0, 1500).toLowerCase();
      if (p.includes('<html') && ['sign in', 'please login', 'signin'].some((w) => p.includes(w))) return true;
    }
  }
  if (!json) {
    const t = r.text.slice(0, 3000).toLowerCase();
    if ((t.includes('<html') || t.includes('<form')) && LOGIN_SIGNALS.some((w) => t.includes(w))) return true;
  }
  return false;
}
const isJson = (r: Resp) => {
  const t = r.text.trim();
  return !!t && (r.contentType.toLowerCase().includes('json') || t[0] === '[' || t[0] === '{');
};

/** Parses DataTables-style JSON into rows. */
export function parseRows(text: string, maskOnly = false): Row[] {
  text = text.trim();
  if (!text || text.startsWith('<')) return [];
  let js: any;
  try {
    js = JSON.parse(text);
  } catch {
    const cut = text.lastIndexOf(']');
    if (cut <= 0) return [];
    try {
      js = JSON.parse(text.slice(0, cut + 1));
    } catch {
      return [];
    }
  }
  const rows: any[] = Array.isArray(js) ? js : js && typeof js === 'object' ? js.aaData || js.data || [] : [];
  if (!Array.isArray(rows)) return [];
  const out: Row[] = [];
  for (const row of rows) {
    if (Array.isArray(row)) {
      if (row.length < 4 || String(row[0]).startsWith('0,')) continue;
      const num = String(row[2]).trim().replace(/^\++/, '');
      if (!/^\d+$/.test(num) || num === '0') continue;
      let sms = '';
      for (const col of [5, 4, 6]) {
        const v = row.length > col && row[col] != null ? String(row[col]).trim() : '';
        if (v && !INVALID.has(v) && !/^\*+$/.test(v)) {
          sms = unescapeHtml(v);
          break;
        }
      }
      if (maskOnly && !sms) continue;
      out.push({ number: num, cli: String(row[3] ?? ''), sms });
    } else if (row && typeof row === 'object') {
      const num = String(row.number ?? row.num ?? row.msisdn ?? '').trim().replace(/^\++/, '');
      if (!/^\d+$/.test(num) || num === '0') continue;
      let sms = String(row.sms ?? row.message ?? row.text ?? '').trim();
      if (INVALID.has(sms) || /^\*+$/.test(sms)) sms = '';
      if (maskOnly && !sms) continue;
      out.push({ number: num, cli: String(row.cli ?? row.service ?? row.sender ?? '').trim(), sms: unescapeHtml(sms) });
    }
  }
  return out;
}

const cdrParams = (d1: string, d2: string): Record<string, string> => ({
  // RouteCore/INTS exposes SMSCDRReports through a DataTables server-side endpoint.
  // Without these fields the endpoint returns 403 instead of the JSON rows.
  fdate1: d1, fdate2: d2, frange: '', fclient: '', fnum: '', fcli: '', fgdate: '', fgmonth: '', fgrange: '', fgclient: '', fgnumber: '', fgcli: '', fg: '0',
  sEcho: '1', iDisplayStart: '0', iDisplayLength: '500', iSortCol_0: '0', sSortDir_0: 'desc', iSortingCols: '1',
});
const csrfOf = (html: string) => {
  for (const re of [/name=["']_token["'][^>]+value=["']([^"']+)["']/, /value=["']([^"']+)["'][^>]+name=["']_token["']/, /meta[^>]+name=["']csrf-token["'][^>]+content=["']([^"']+)["']/]) {
    const m = html.match(re);
    if (m) return m[1];
  }
  return '';
};
const hasSid = (c: Client) => !!(c.cookie('PHPSESSID') || c.cookie('session') || c.cookie('laravel_session'));
const pathFromUrl = (u: string, dflt = 'agent') => (u.includes('reseller') ? 'reseller' : u.includes('client') ? 'client' : u.includes('agent') ? 'agent' : dflt);
const looksLoggedOut = (u: string) => ['/login', '/signin', '/sign-in'].some((x) => u.toLowerCase().includes(x));
const sesskeyOf = (html: string) => html.match(/sesskey=([A-Za-z0-9+/=_-]+)/)?.[1] || '';
const connErr = (e: any) => /connection error|timeout/.test(String(e?.message));

async function openLogin(c: Client, bn: string, url: string, page: string): Promise<Resp> {
  let r: Resp;
  try {
    r = await c.get(`${url}/${page}`, { timeout: 20000 });
  } catch (e: any) {
    throw new Error(`${bn} · server unreachable: ${e.message}`);
  }
  const low = r.text.toLowerCase();
  if (r.status === 403 || r.status === 401 || low.includes('not in allowlist') || low.includes('not allowed')) throw new Error(`${bn} · IP blocked (HTTP ${r.status}) — the panel only allows its own whitelisted IPs`);
  return r;
}

const session = (c: Client, path: string, url: string): Session => ({ cookies: c.jar, path, url });
const restore = (s: Session) => new Client(s.cookies);

// ───────────────────────── generic ints / standard panels ─────────────────────────

async function coreFetch(c: Client, url: string, path: string): Promise<FetchResult> {
  const [d1, d2] = dates();
  const paths = [...new Set([path, 'agent', 'client', 'reseller'])];
  for (const p of paths) {
    const base = cdrParams(d1, d2);
    for (const ep of [`${url}/${p}/res/data_smscdr.php`, `${url}/${p}/res/data_smscdrreports.php`]) {
      try {
        const r = await c.get(ep, { params: base, headers: { ...AJAX_HEADERS, Referer: `${url}/${p}/SMSCDRStats` } });
        if (expired(r)) return null;
        if (isJson(r)) {
          const rows = parseRows(r.text);
          if (rows.length) return rows;
        }
      } catch (e) {
        if (connErr(e)) break;
      }
    }
    let sesskey = '';
    for (const ep of [`${url}/${p}/SMSCDRStats`, `${url}/${p}/SMSCDRReports`]) {
      if (sesskey) break;
      try {
        const rs = await c.get(ep, { headers: { Referer: `${url}/${p}/SMSDashboard` } });
        if (expired(rs)) return null;
        sesskey = sesskeyOf(rs.text);
      } catch {}
    }
    if (sesskey) {
      for (const ep of [`${url}/${p}/res/data_smscdr.php`, `${url}/${p}/res/data_smscdrreports.php`]) {
        try {
          const r = await c.get(ep, { params: { ...base, sesskey }, headers: { ...AJAX_HEADERS, Referer: `${url}/${p}/SMSCDRStats` } });
          if (expired(r)) return null;
          if (isJson(r)) {
            const rows = parseRows(r.text);
            if (rows.length) return rows;
          }
        } catch {}
      }
    }
    try {
      const r = await c.get(`${url}/${p}/res/data_testsmscdr.php`, { params: { fdate1: d1, fdate2: d2, fg: '0' }, headers: { ...AJAX_HEADERS, Referer: `${url}/${p}/SMSTestPanel` }, timeout: 15000 });
      if (expired(r)) return null;
      if (isJson(r)) {
        const rows = parseRows(r.text);
        if (rows.length) return rows;
      }
    } catch {}
  }
  return [];
}

/** Used by `ints`, `standard`, `timesms` style panels (captcha + optional csrf token). */
async function formLogin(bn: string, user: string, pw: string, url: string, loginPage: string, postPage: string, extra: Record<string, string> = {}, needSid = true): Promise<Session> {
  const c = new Client();
  const r = await openLogin(c, bn, url, loginPage);
  const csrf = csrfOf(r.text);
  const form: Record<string, any> = { username: user, password: pw, capt: solveCaptcha(r.text), ...extra };
  if (csrf) form._token = csrf;
  let r2: Resp;
  try {
    r2 = await c.post(`${url}/${postPage}`, { form, headers: { Referer: `${url}/${loginPage}`, Origin: new URL(url).origin } });
  } catch (e: any) {
    throw new Error(`${bn} · sign-in failed: ${e.message}`);
  }
  if (needSid && !hasSid(c)) throw new Error(`${bn} · no session cookie after login`);
  if (looksLoggedOut(r2.url)) throw new Error(`${bn} · login failed — wrong username/password or captcha`);
  return session(c, pathFromUrl(r2.url), url);
}

const intsLogin = (bn: string, u: string, p: string, url: string) => formLogin(bn, u, p, url, 'login', 'signin', { 'g-recaptcha-response': '' });
const standardLogin = (bn: string, u: string, p: string, url: string) =>
  url.includes('/sms') ? formLogin(bn, u, p, url, 'SignIn', 'signmein', { 'g-recaptcha-response': '' }) : formLogin(bn, u, p, url, 'login', 'signin', { 'g-recaptcha-response': '' });
const timesmsLogin = (bn: string, u: string, p: string, url: string) => formLogin(bn, u, p, url, 'login', 'signin');

async function imsLogin(user: string, pw: string, url: string): Promise<Session> {
  const c = new Client();
  try { await c.get(url); } catch {}
  const etkkOf = (h: string) => h.match(/name=['"]etkk['"][^>]+value=['"]([^'"]+)['"]/)?.[1] || h.match(/value=['"]([^'"]+)['"][^>]+name=['"]etkk['"]/)?.[1] || '';
  for (let attempt = 0; attempt < 3; attempt++) {
    const r = await openLogin(c, 'ImsPanel', url, 'login');
    const post = (etkk: string, capt: string) => c.post(`${url}/signin`, { form: { username: user, password: pw, capt, etkk }, headers: { Origin: new URL(url).origin, Referer: `${url}/login` } });
    let r2 = await post(etkkOf(r.text), solveCaptcha(r.text)).catch(() => null);
    if (r2 && looksLoggedOut(r2.url)) {
      const e2 = etkkOf(r2.text);
      r2 = await post(e2, solveCaptcha(r2.text)).catch(() => null);
    }
    if (r2 && !looksLoggedOut(r2.url)) {
      const u = r2.url.toLowerCase();
      const role = ['reseller', 'agent', 'admin', 'client'].find((x) => u.includes(x)) || 'client';
      return session(c, role, url);
    }
  }
  throw new Error('ImsPanel · login failed (wrong credentials or captcha)');
}
async function imsFetch(s: Session): Promise<FetchResult> {
  const c = restore(s);
  const { url, path } = s;
  try { await c.get(`${url}/${path}/SMSDashboard`, { timeout: 15000 }); } catch {}
  let sesskey = '';
  try {
    const rs = await c.get(`${url}/${path}/SMSCDRStats`, { timeout: 15000 });
    if (expired(rs)) return null;
    sesskey = sesskeyOf(rs.text);
  } catch {}
  const [d1, d2] = dates();
  const params: Record<string, string> = cdrParams(d1, d2);
  if (sesskey) params.sesskey = sesskey;
  try {
    const r = await c.get(`${url}/${path}/res/data_smscdr.php`, { params, headers: { ...AJAX_HEADERS, Referer: `${url}/${path}/SMSCDRStats` } });
    if (expired(r)) return null;
    return parseRows(r.text);
  } catch {
    return [];
  }
}

async function konektaLogin(user: string, pw: string): Promise<Session> {
  const url = 'https://konektapremium.net';
  const c = new Client();
  const r = await openLogin(c, 'Konekta', url, 'sign-in');
  const r2 = await c.post(`${url}/signin`, { form: { username: user, password: pw, capt: solveCaptcha(r.text) }, headers: { Referer: `${url}/sign-in` } });
  if (!['dashboard', 'agent', 'client', 'reseller', 'smscdr', 'sms'].some((x) => r2.url.toLowerCase().includes(x))) throw new Error(`Konekta · login failed — unexpected URL: ${r2.url}`);
  if (!hasSid(c)) throw new Error('Konekta · no session cookie after login');
  return session(c, 'agent', url);
}

/** Shared "SMSCDRReports + sesskey + data_smscdr" fetch used by timesms/roxy/numberpanel/sniper. */
async function reportFetch(s: Session, opts: { pages: string[]; paths?: string[]; maskOnly?: boolean; test?: boolean; minimal?: boolean }): Promise<FetchResult> {
  const c = restore(s);
  const { url } = s;
  const [d1, d2] = dates();
  for (const p of opts.paths || [s.path]) {
    let sesskey = '';
    for (const pg of opts.pages) {
      try {
        const rs = await c.get(`${url}/${p}/${pg}`, { headers: { Referer: `${url}/${p}/SMSDashboard` }, timeout: 15000 });
        if (expired(rs)) return null;
        sesskey = sesskeyOf(rs.text);
        if (sesskey) break;
      } catch (e) {
        if (connErr(e)) return [];
      }
    }
    const params: Record<string, string> = opts.minimal ? { fdate1: d1, fdate2: d2, fg: '0' } : cdrParams(d1, d2);
    if (sesskey) params.sesskey = sesskey;
    try {
      const r = await c.get(`${url}/${p}/res/data_smscdr.php`, { params, headers: { ...AJAX_HEADERS, Referer: `${url}/${p}/${opts.pages[0]}` } });
      if (expired(r)) return null;
      const rows = parseRows(r.text, opts.maskOnly);
      if (rows.length) return rows;
    } catch (e) {
      if (connErr(e)) return [];
    }
    if (opts.test) {
      try {
        const r = await c.get(`${url}/${p}/res/data_testsmscdr.php`, { params: { fdate1: d1, fdate2: d2, fg: '0' }, headers: { ...AJAX_HEADERS, Referer: `${url}/${p}/SMSTestPanel` }, timeout: 15000 });
        if (expired(r)) return null;
        const rows = parseRows(r.text, opts.maskOnly);
        if (rows.length) return rows;
      } catch (e) {
        if (connErr(e)) return [];
      }
    }
  }
  return [];
}

async function roxyLogin(bn: string, user: string, pw: string, url: string): Promise<Session> {
  const c = new Client();
  const r = await openLogin(c, bn, url, 'Login');
  const r2 = await c.post(`${url}/signin`, { form: { username: user, password: pw, capt: solveCaptcha(r.text), 'g-recaptcha-response': '' }, headers: { Referer: `${url}/Login` } });
  if (!hasSid(c)) throw new Error(`${bn} · no session cookie after login`);
  if (looksLoggedOut(r2.url)) throw new Error(`${bn} · login failed — wrong username/password or captcha`);
  return session(c, r2.url.includes('agent') ? 'agent' : 'client', url);
}
async function voicegateLogin(bn: string, user: string, pw: string, url: string): Promise<Session> {
  const c = new Client();
  const r = await openLogin(c, bn, url, 'SignIn');
  const capt = solveCaptcha(r.text);
  const form: Record<string, any> = { username: user, password: pw };
  if (capt && capt !== '0') form.capt = capt;
  const r2 = await c.post(`${url}/signmein`, { form, headers: { Referer: `${url}/SignIn` } });
  if (!hasSid(c)) throw new Error(`${bn} · no session cookie after login`);
  if (looksLoggedOut(r2.url)) throw new Error(`${bn} · login failed — wrong username/password or captcha`);
  return session(c, r2.url.includes('reseller') ? 'reseller' : r2.url.includes('agent') ? 'agent' : 'client', url);
}
async function voicegateFetch(s: Session): Promise<FetchResult> {
  const c = restore(s);
  const [d1, d2] = dates();
  const params = { fdate1: d1, fdate2: d2, ftermination: '', fclient: '', fnum: '', fcli: '', fgdate: '0', fgtermination: '0', fgclient: '0', fgnumber: '0', fgcli: '0', fg: '0' };
  for (const p of [...new Set([s.path, 'reseller', 'agent', 'client'])]) {
    try {
      const r = await c.get(`${s.url}/${p}/ajax/dt_reports.php`, { params, headers: { ...AJAX_HEADERS, Referer: `${s.url}/${p}/Reports` }, timeout: 15000 });
      if (expired(r)) return null;
      const rows = parseRows(r.text);
      if (rows.length) return rows;
    } catch {}
  }
  return [];
}
async function numberpanelLogin(bn: string, user: string, pw: string, url: string): Promise<Session> {
  const c = new Client();
  const r = await openLogin(c, bn, url, 'login');
  const m = r.text.match(/What is (\d+)\s*\+\s*(\d+)/i);
  await c.post(`${url}/signin`, { form: { username: user, password: pw, capt: m ? +m[1] + +m[2] : 0 }, headers: { Referer: `${url}/login` } }).then((r2) => {
    if (!c.cookie('PHPSESSID')) throw new Error(`${bn} · login failed — no PHPSESSID`);
    (c as any)._p = r2.url.includes('agent') ? 'agent' : 'client';
  });
  return session(c, (c as any)._p, url);
}
async function sniperLogin(bn: string, user: string, pw: string, url: string): Promise<Session> {
  const s = await formLogin(bn, user, pw, url, 'login', 'signin', {}, true);
  return { ...s, path: 'agent' };
}

// ───────────────────────── dispatch ─────────────────────────

export async function panelLogin(name: string, ptype: string, user: string, pw: string, url: string): Promise<Session> {
  url = url.replace(/\/+$/, '');
  switch (ptype) {
    case 'ims': return imsLogin(user, pw, url);
    case 'konekta': return konektaLogin(user, pw);
    case 'standard': return standardLogin(name, user, pw, url);
    case 'timesms': return timesmsLogin(name, user, pw, url);
    case 'roxy': return roxyLogin(name, user, pw, url);
    case 'voicegate': return voicegateLogin(name, user, pw, url);
    case 'numberpanel': return numberpanelLogin(name, user, pw, url);
    case 'sniper': return sniperLogin(name, user, pw, url);
    default: return intsLogin(name, user, pw, url); // ints, proofsms and anything unknown
  }
}

export async function panelFetch(ptype: string, s: Session): Promise<FetchResult> {
  const c = () => restore(s);
  switch (ptype) {
    case 'ims': return imsFetch(s);
    case 'konekta':
    case 'standard':
    default:
      if (ptype === 'timesms') return reportFetch(s, { pages: ['SMSCDRReports', 'SMSCDRStats'] });
      if (ptype === 'roxy') return reportFetch(s, { pages: ['SMSCDRReports'], paths: [...new Set([s.path, 'agent', 'client'])], maskOnly: true, test: true });
      if (ptype === 'voicegate') return voicegateFetch(s);
      if (ptype === 'numberpanel') return reportFetch(s, { pages: ['SMSCDRStats'], minimal: true });
      if (ptype === 'sniper') return reportFetch(s, { pages: ['SMSCDRReports'] });
      if (ptype === 'proofsms') return reportFetch(s, { pages: ['SMSCDRStats'], paths: ['agent', 'client'], test: true, minimal: true });
      return coreFetch(c(), s.url, s.path);
  }
}
void BASE_HEADERS;
