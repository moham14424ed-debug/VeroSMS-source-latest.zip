/** Local development server: `npm run dev`. Serves /static from public/ and everything else through the app. */
import http from 'http';
import fs from 'fs';
import path from 'path';
import { handle } from './app';

const root = path.resolve(__dirname, '..', 'public');
const types: Record<string, string> = { '.css': 'text/css', '.js': 'application/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webp': 'image/webp', '.woff2': 'font/woff2' };

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', 'http://localhost');
  if (url.pathname.startsWith('/static/')) {
    const file = path.normalize(path.join(root, url.pathname));
    if (file.startsWith(root) && fs.existsSync(file) && fs.statSync(file).isFile()) {
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
      return fs.createReadStream(file).pipe(res);
    }
  }
  handle(req, res).catch((e) => {
    console.error(e);
    res.writeHead(500).end('error');
  });
});
const port = Number(process.env.PORT || 3000);
server.listen(port, () => console.log(`http://localhost:${port}`));
