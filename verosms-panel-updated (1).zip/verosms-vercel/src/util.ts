import { PyDate } from './db';

export interface Pagination<T = any> {
  items: T[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
  has_prev: boolean;
  has_next: boolean;
  prev_num: number | null;
  next_num: number | null;
  iter_pages: () => number[];
}

/** "All rows" marker used by the legacy `per_page=99999` selector. */
export const ALL_ROWS = 99999;

export function pageParams(pageIn: number | null, perPageIn: number | null, defPer = 25) {
  const page = Math.max(1, pageIn || 1);
  let perPage = perPageIn && perPageIn > 0 ? perPageIn : defPer;
  const all = perPage >= ALL_ROWS;
  if (!all) perPage = Math.min(perPage, 1000);
  return { page: all ? 1 : page, perPage, all, limit: all ? 100000 : perPage, offset: all ? 0 : (page - 1) * perPage };
}

export function makePagination<T>(items: T[], total: number, page: number, perPage: number, all = false): Pagination<T> {
  const pages = all ? 1 : Math.ceil(total / perPage);
  return {
    items,
    total,
    page,
    per_page: perPage,
    pages,
    has_prev: page > 1,
    has_next: page < pages,
    prev_num: page > 1 ? page - 1 : null,
    next_num: page < pages ? page + 1 : null,
    iter_pages: () => Array.from({ length: Math.max(pages, 1) }, (_, i) => i + 1),
  };
}

export const utcnow = () => new PyDate();

export function startOfUtcDay(d: Date = new Date()): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}
export function addDays(d: Date, n: number): Date {
  return new Date(d.getTime() + n * 86400000);
}
export const ymd = (d: Date) => d.toISOString().slice(0, 10);

/** Parses 'YYYY-MM-DD' or 'YYYY-MM-DD HH:MM:SS' (UTC). Falls back to now. */
export function parseDateInput(s: string | null | undefined): Date {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}):(\d{2}))?$/.exec((s || '').trim());
  if (!m) return new Date();
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)));
  return isNaN(d.getTime()) ? new Date() : d;
}

export const digitsOnly = (s: string | null | undefined) => (s || '').replace(/\D/g, '');

// ── CSV (Python `csv.writer` compatible, QUOTE_MINIMAL, CRLF) ──
export function csvCell(v: any): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'boolean') return v ? 'True' : 'False';
  const s = String(v);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
export const csvRow = (cells: any[]) => cells.map(csvCell).join(',') + '\r\n';
export const toCsv = (rows: any[][]) => rows.map(csvRow).join('');

/** Minimal RFC-4180 CSV parser returning rows of cells. */
export function parseCsv(text: string, delimiter = ','): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else q = false;
      } else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === delimiter) {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      cell = '';
      if (row.length > 1 || row[0] !== '') rows.push(row);
      row = [];
    } else cell += ch;
  }
  row.push(cell);
  if (row.length > 1 || row[0] !== '') rows.push(row);
  return rows;
}

export function randomToken(bytes = 32): string {
  return require('crypto').randomBytes(bytes).toString('base64url');
}

export function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

export function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/** An error whose message is safe to show to the user (flash message). */
export class UserError extends Error {}

/** Map with Python-dict style `get(key, default)` so ported Jinja templates keep working. */
export class PyDict<V = any> extends Map<any, V> {
  get(key: any, dflt?: any): any {
    return super.has(key) ? super.get(key) : dflt;
  }
}
