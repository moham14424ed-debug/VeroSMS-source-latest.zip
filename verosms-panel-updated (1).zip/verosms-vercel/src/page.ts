import { db } from './db';
import { makePagination, pageParams, Pagination } from './util';

/**
 * Paginates `baseSql` (a SELECT without ORDER BY/LIMIT). Mirrors Flask-SQLAlchemy's
 * `paginate(error_out=False)`; `per_page >= 99999` returns every row on one page.
 */
export async function paginate<T = any>(
  baseSql: string,
  params: any[],
  orderBy: string,
  pageIn: number | null,
  perPageIn: number | null,
  defPer = 25,
  countSql?: string,
): Promise<Pagination<T>> {
  const p = pageParams(pageIn, perPageIn, defPer);
  const total = Number(await db.scalar(countSql ?? `select count(*) from (${baseSql}) q`, params)) || 0;
  const rows = await db.query<T>(`${baseSql} order by ${orderBy} limit ${p.limit} offset ${p.offset}`, params);
  return makePagination(rows, total, p.page, p.perPage, p.all);
}

/** Builds `where` fragments with numbered placeholders. */
export class Where {
  parts: string[] = [];
  params: any[] = [];
  add(sql: string, ...vals: any[]): this {
    let s = sql;
    for (const v of vals) {
      this.params.push(v);
      s = s.replace('?', '$' + this.params.length);
    }
    this.parts.push(s);
    return this;
  }
  raw(sql: string): this {
    this.parts.push(sql);
    return this;
  }
  get sql(): string {
    return this.parts.length ? ' where ' + this.parts.join(' and ') : '';
  }
}
