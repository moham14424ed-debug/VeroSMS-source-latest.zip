import { GET, POST, urlFor } from '../http';
import { db } from '../db';
import { render } from '../views';
import { adminRequired } from '../auth';
import { pollProvider } from '../fetchers';
import { logActivity, hydrateCdrs, attachUsers } from '../models';
import { startOfUtcDay, addDays, errMsg } from '../util';

const counts = async () => {
  const today = startOfUtcDay();
  const r = await db.one(`select count(*) filter (where created_at >= $1 and created_at < $2) as today, count(*) as total from sms_cdr where sms_type = 'received'`, [today, addDays(today, 1)]);
  return { today_count: Number(r!.today), total_count: Number(r!.total) };
};

async function latest(limit: number) {
  const rows = await db.query(`select * from sms_cdr where sms_type = 'received' order by created_at desc, id desc limit $1`, [limit]);
  await hydrateCdrs(rows);
  await attachUsers(rows, 'user_id', 'owner');
  return rows;
}

GET('monitor.index', '/monitor/', adminRequired, async (c) => {
  const received = await latest(50);
  const providers = await db.query(`select id, name, ptype, is_active, last_fetch_at, last_status, last_error, fetch_interval from providers order by name`);
  render(c, 'admin/sms_monitor.html', { received, providers, ...(await counts()) });
});

/** Fetches every active provider right now (ignores the polling interval). */
POST('monitor.run_cycle', '/monitor/run', adminRequired, async (c) => {
  const providers = await db.query(`select id from providers where is_active`);
  const results = await Promise.allSettled(providers.map((p) => pollProvider(p.id, true)));
  const out = results.map((r) => (r.status === 'fulfilled' ? r.value : { status: 'error', error: errMsg((r as any).reason) })).filter(Boolean) as any[];
  const saved = out.reduce((s, r) => s + (r.saved || 0), 0);
  const failed = out.filter((r) => r.status === 'error');
  await logActivity(c.user.id, 'monitor_run', `providers=${providers.length} new_otp=${saved} failed=${failed.length}`, c.ip);
  if (c.req.headers['x-requested-with'] === 'XMLHttpRequest' || c.json) return c.jsonOut({ success: true, providers: providers.length, new_otp: saved, results: out });
  c.flash(`Fetched ${providers.length} provider(s): ${saved} new OTP, ${failed.length} failed.`, failed.length ? 'warning' : 'success');
  c.redirect(urlFor('monitor.index'));
});

GET('monitor.get_messages', '/monitor/messages', adminRequired, async (c) => {
  const limit = Math.min(Math.max(c.query.int('limit') || 50, 1), 200);
  const rows = await latest(limit);
  c.jsonOut({
    success: true,
    messages: rows.map((r: any) => ({
      id: r.id,
      number: r.sms_number?.number || r.destination || '—',
      message: r.message || '',
      source: r.cli || 'external',
      date: r.created_at ? r.created_at.strftime('%Y-%m-%d %H:%M:%S') : '',
      agent: r.owner?.username || r.sms_number?.agent?.username || '—',
    })),
    ...(await counts()),
  });
});

GET('monitor.get_status', '/monitor/status', adminRequired, async (c) => {
  c.jsonOut({ providers: await db.query(`select id, name, is_active, last_fetch_at, last_status, last_error from providers order by name`) });
});
