import { GET, POST, ANY, urlFor, abort, Ctx } from '../http';
import { db, tx, likeEscape, isUniqueViolation } from '../db';
import { render } from '../views';
import { adminRequired, loginRequired, hashPassword, agentRequired, memberRequired } from '../auth';
import { attachRanges, attachUsers, hydrateNumbers, listAgents, logActivity, roleByName, withRangeCounts, getUserById } from '../models';
import { paginate, Where } from '../page';
import { UserError, chunk, digitsOnly, startOfUtcDay, toCsv, parseDateInput, ymd } from '../util';
import { ensureTestPool, resetNumbersToPool, syncTestNumber } from '../services/lifecycle';
import { allocateFromRange, limitsForUser, setLimit } from '../services/numbers';
import { requestPage } from './main';

const A = adminRequired;

// ───────────────────────── helpers ─────────────────────────

/** Extracts digit-only numbers from pasted text or a CSV (first column), normalised to the range prefix. */
export function extractNumbers(text: string, prefix: string): string[] {
  const seen = new Set<string>();
  for (const line of text.split(/\r?\n/)) {
    for (const cell of line.split(/[,;\t ]+/).slice(0, 1)) {
      let d = digitsOnly(cell);
      if (d.length < 5) continue;
      if (prefix && !d.startsWith(prefix)) d = prefix + d;
      if (d.length > 30) continue;
      seen.add(d);
    }
  }
  return [...seen];
}

/** Inserts numbers into a range in bulk; numbers that already exist anywhere are skipped. */
export async function addNumbersToRange(t: { query: any; exec: any }, range: any, numbers: string[]) {
  let created = 0;
  for (const part of chunk(numbers, 2000)) {
    const rows = await t.query(
      `insert into sms_numbers (range_id, number, prefix, status, is_active)
       select $1, n, $2, 'available', true from unnest($3::text[]) as n
       on conflict (number) do nothing returning id`,
      [range.id, range.prefix, part],
    );
    created += rows.length;
  }
  return { created, skipped: numbers.length - created };
}

const fileText = (c: Ctx, name: string): string => {
  const f = c.files[name];
  if (!f || !f.filename || !f.data.length) return '';
  const buf = f.data;
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch {
    return buf.toString('latin1');
  }
};

// ───────────────────────── ranges ─────────────────────────

GET('admin.sms_ranges', '/admin/ranges', A, async (c) => {
  const w = new Where();
  const search = c.query.str('search');
  if (search) { const l = `%${likeEscape(search)}%`; w.add('(prefix ilike ? or country ilike ? or coalesce(name,\'\') ilike ?)', l, l, l); }
  const ranges = await paginate(`select * from sms_ranges${w.sql}`, w.params, 'country, prefix', c.query.int('page'), 25, 25);
  await withRangeCounts(ranges.items);
  render(c, 'admin/sms_ranges.html', { ranges });
});

const rangeFields = (c: Ctx, cur: any = {}) => {
  const f = c.form;
  const has = (k: string) => f.has(k);
  const num = (k: string, d: number) => (has(k) ? f.float(k, d) : cur[k] ?? d);
  const txt = (k: string) => (has(k) ? f.str(k) || null : cur[k] ?? null);
  return {
    name: has('name') ? f.str('name') : cur.name ?? null,
    prefix: has('prefix') ? digitsOnly(f.get('prefix', '')) : cur.prefix,
    country: has('country') ? f.str('country') : cur.country,
    application: txt('application'),
    operator: txt('operator'),
    network_type: txt('network_type'),
    mcc: txt('mcc'),
    mnc: txt('mnc'),
    memo: txt('memo'),
    test_number: txt('test_number'),
    currency: has('currency') ? (f.str('currency') || 'USD').slice(0, 3).toUpperCase() : cur.currency ?? 'USD',
    daily_limit: Math.max(0, Math.round(num('daily_limit', cur.daily_limit ?? 50))),
    payout: Math.max(0, num('payout', cur.payout ?? 0)),
    cost_per_sms: Math.max(0, num('cost_per_sms', cur.cost_per_sms ?? 0.005)),
    rate: Math.max(0, num('rate', cur.rate ?? 0)),
  };
};

ANY('admin.create_sms_range', '/admin/ranges/create', A, async (c) => {
  if (c.method !== 'POST') return render(c, 'admin/range_form.html', { range_obj: null });
  const r = rangeFields(c);
  const back = (m: string) => (c.flash(m, 'danger'), c.redirect(urlFor('admin.create_sms_range')));
  if (!r.prefix || !r.country) return back('Range country and numeric prefix are required.');
  const numbers = extractNumbers(fileText(c, 'csv_file') + '\n' + (c.form.get('numbers_text', '') as string), r.prefix);
  let out: { id: number; created: number; skipped: number; pool: number };
  try {
    out = await tx(async (t) => {
      const range = (await t.one(
        `insert into sms_ranges (name,prefix,country,application,operator,network_type,mcc,mnc,memo,test_number,currency,daily_limit,payout,cost_per_sms,rate,is_active,created_by)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,true,$16) returning *`,
        [r.name, r.prefix, r.country, r.application, r.operator, r.network_type, r.mcc, r.mnc, r.memo, r.test_number, r.currency, r.daily_limit, r.payout, r.cost_per_sms, r.rate, c.user.id],
      ))!;
      await syncTestNumber(t, range, r.test_number);
      const add = await addNumbersToRange(t, range, numbers);
      const pool = await ensureTestPool(t, range);
      return { id: range.id, ...add, pool: pool.length };
    });
  } catch (e: any) {
    if (isUniqueViolation(e) || /already belongs/.test(e?.message)) return back('Range could not be created. The test number is already used by another range.');
    throw e;
  }
  await logActivity(c.user.id, 'admin_create_range', `Created range ${r.prefix} and added ${out.created} numbers`, c.ip);
  let msg = `Range ${r.prefix} created with ${out.created} numbers and ${out.pool} fixed test numbers.`;
  if (out.skipped) msg += ` (${out.skipped} skipped - already exist)`;
  c.flash(msg, 'success');
  c.redirect(urlFor('admin.sms_ranges'));
});

ANY('admin.edit_sms_range', '/admin/ranges/<int:range_id>/edit', A, async (c) => {
  const cur = await db.one(`select * from sms_ranges where id = $1`, [c.params.range_id]);
  if (!cur) return abort(404);
  if (c.method !== 'POST') return render(c, 'admin/range_form.html', { range_obj: cur });
  const r = rangeFields(c, cur);
  const back = (m: string) => (c.flash(m, 'danger'), c.redirect(urlFor('admin.edit_sms_range', { range_id: cur.id })));
  if (!r.prefix || !r.country) return back('Range country and numeric prefix are required.');
  try {
    await tx(async (t) => {
      const range = (await t.one(
        `update sms_ranges set name=$2,prefix=$3,country=$4,application=$5,operator=$6,network_type=$7,mcc=$8,mnc=$9,memo=$10,test_number=$11,currency=$12,daily_limit=$13,payout=$14,cost_per_sms=$15,rate=$16,is_active=$17 where id=$1 returning *`,
        [cur.id, r.name, r.prefix, r.country, r.application, r.operator, r.network_type, r.mcc, r.mnc, r.memo, r.test_number, r.currency, r.daily_limit, r.payout, r.cost_per_sms, r.rate, c.form.has('is_active')],
      ))!;
      if (r.prefix !== cur.prefix) await t.exec(`update sms_numbers set prefix = $2 where range_id = $1`, [cur.id, r.prefix]);
      await syncTestNumber(t, range, r.test_number);
      await ensureTestPool(t, range);
      const add = extractNumbers(fileText(c, 'csv_file') + '\n' + (c.form.get('numbers_text', '') as string), r.prefix);
      if (add.length) {
        const res = await addNumbersToRange(t, range, add);
        c.flash(`${res.created} numbers added to the range${res.skipped ? ` (${res.skipped} already existed)` : ''}.`, 'info');
      }
    });
  } catch (e: any) {
    if (/already belongs/.test(e?.message)) return back(e.message);
    throw e;
  }
  await logActivity(c.user.id, 'admin_edit_range', `Edited range ${r.prefix}`, c.ip);
  c.flash(`Range ${r.prefix} updated.`, 'success');
  c.redirect(urlFor('admin.sms_ranges'));
});

/** NEW: add more numbers (paste or CSV) to an existing range. */
POST('admin.range_add_numbers', '/admin/ranges/<int:range_id>/add-numbers', A, async (c) => {
  const range = await db.one(`select * from sms_ranges where id = $1`, [c.params.range_id]);
  if (!range) return abort(404);
  const nums = extractNumbers(fileText(c, 'csv_file') + '\n' + (c.form.get('numbers_text', '') as string), range.prefix);
  if (!nums.length) {
    c.flash('Paste at least one number (one per line) or choose a CSV file.', 'danger');
    return c.redirect(urlFor('admin.sms_ranges'));
  }
  const res = await tx(async (t) => {
    const out = await addNumbersToRange(t, range, nums);
    await ensureTestPool(t, range);
    return out;
  });
  await logActivity(c.user.id, 'admin_range_add_numbers', `Added ${res.created} numbers to range ${range.prefix}`, c.ip);
  c.flash(`${res.created} numbers added to +${range.prefix}${res.skipped ? ` — ${res.skipped} skipped (already exist)` : ''}.`, res.created ? 'success' : 'warning');
  c.redirect(urlFor('admin.sms_ranges'));
});

POST('admin.add_range_test_numbers', '/admin/ranges/<int:range_id>/test-numbers', A, async (c) => {
  const range = await db.one(`select * from sms_ranges where id = $1`, [c.params.range_id]);
  if (!range) return abort(404);
  const back = () => c.redirect(urlFor('admin.sms_ranges'));
  const cands = extractNumbers(c.form.get('test_numbers', '') as string, range.prefix);
  if (!cands.length) { c.flash('Enter at least one test number, one number per line.', 'danger'); return back(); }
  try {
    const res = await tx(async (t) => {
      const pool = await t.query(`select number from sms_numbers where range_id = $1 and status = 'test_pool'`, [range.id]);
      const have = new Set(pool.map((p) => p.number));
      const fresh = cands.filter((n) => !have.has(n));
      if (pool.length + fresh.length > 10) throw new UserError('A range can have a maximum of 10 fixed test numbers.');
      let added = 0, skipped = 0;
      for (const n of cands) {
        const ex = await t.one(`select * from sms_numbers where number = $1`, [n]);
        if (ex && ex.range_id !== range.id) throw new UserError(`${n} already belongs to another range.`);
        if (ex && (ex.status === 'test' || ex.status === 'test_pool')) { skipped++; continue; }
        if (!ex) await t.exec(`insert into sms_numbers (range_id, number, prefix, status, is_active) values ($1,$2,$3,'test_pool',true)`, [range.id, n, range.prefix]);
        else await t.exec(`update sms_numbers set status='test_pool', agent_id=null, client_id=null, assigned_at=null, is_active=true where id=$1`, [ex.id]);
        added++;
      }
      return { added, skipped };
    });
    c.flash(`${res.added} fixed test number(s) saved for ${range.country} / +${range.prefix}.${res.skipped ? ` ${res.skipped} skipped.` : ''}`, 'success');
    await logActivity(c.user.id, 'admin_add_range_test_numbers', `Added ${res.added} test numbers to range ${range.prefix}`, c.ip);
  } catch (e) {
    if (!(e instanceof UserError)) throw e;
    c.flash(e.message, 'danger');
  }
  back();
});

ANY('admin.delete_sms_range', '/admin/ranges/<int:range_id>/delete', A, async (c) => {
  if (c.method !== 'POST') return c.redirect(urlFor('admin.sms_ranges'));
  const range = await db.one(`select * from sms_ranges where id = $1`, [c.params.range_id]);
  if (!range) return abort(404);
  try {
    await tx(async (t) => {
      const id = range.id;
      await t.exec(`update sms_cdr set range_id = null, number_id = null where range_id = $1 or number_id in (select id from sms_numbers where range_id = $1)`, [id]);
      await t.exec(`update otp_logs set number_id = null where number_id in (select id from sms_numbers where range_id = $1)`, [id]);
      await t.exec(`delete from test_number_assignments where range_id = $1`, [id]);
      await t.exec(`delete from sms_numbers where range_id = $1`, [id]);
      await t.exec(`delete from agent_range_limits where range_id = $1`, [id]);
      await t.exec(`delete from sms_ranges where id = $1`, [id]);
    });
  } catch (e) {
    console.error('[delete_range]', e);
    c.flash('Range could not be deleted safely. No data was changed.', 'danger');
    return c.redirect(urlFor('admin.sms_ranges'));
  }
  await logActivity(c.user.id, 'admin_delete_range', `Deleted range ${range.name || range.prefix} - ${range.country}`, c.ip);
  c.flash(`Range ${range.name || range.prefix} - ${range.country} deleted.`, 'success');
  c.redirect(urlFor('admin.sms_ranges'));
});

GET('admin.agent_limits', '/admin/agent-limits', A, async (c) => {
  const ranges = await withRangeCounts(await db.query(`select * from sms_ranges where is_active order by country`));
  render(c, 'admin/agent_limits.html', { ranges });
});
POST('admin.set_range_limit', '/admin/agent-limits/set/<int:range_id>', A, async (c) => {
  const range = await db.one(`update sms_ranges set daily_limit = $2 where id = $1 returning country`, [c.params.range_id, Math.max(0, c.form.int('daily_limit', 50) || 0)]);
  if (!range) return abort(404);
  c.flash(`${range.country} daily limit updated.`, 'success');
  c.redirect(c.form.get('back') === 'ranges' ? urlFor('admin.sms_ranges') : urlFor('admin.agent_limits'));
});
POST('admin.set_range_payout', '/admin/ranges/set-payout/<int:range_id>', A, async (c) => {
  const payout = Math.max(0, c.form.float('payout', 0) || 0);
  const range = await db.one(`update sms_ranges set payout = $2 where id = $1 returning country`, [c.params.range_id, payout]);
  if (!range) return abort(404);
  c.flash(`${range.country} payout set to $${payout.toFixed(4)}/OTP!`, 'success');
  c.redirect(urlFor('admin.sms_ranges'));
});

// ───────────────────────── NEW: per-user, per-range self-service limits ─────────────────────────

ANY('admin.user_limits', '/admin/users/<int:user_id>/limits', A, async (c) => {
  const user = await getUserById(c.params.user_id);
  if (!user) return abort(404);
  if (!user.is_agent() && !user.is_client()) {
    c.flash('Limits only apply to agent and client accounts.', 'danger');
    return c.redirect(urlFor('admin.users'));
  }
  const self = () => c.redirect(urlFor('admin.user_limits', { user_id: user.id }));
  if (c.method === 'POST') {
    const action = c.form.get('action', 'save');
    if (action === 'increase') {
      const rid = c.form.int('range_id');
      const by = c.form.int('amount', 0) || 0;
      if (!rid || by < 1) { c.flash('Enter an amount greater than zero.', 'danger'); return self(); }
      await db.exec(
        `insert into agent_range_limits (agent_id, range_id, total_limit, taken_count) values ($1,$2,$3,0)
         on conflict (agent_id, range_id) do update set total_limit = agent_range_limits.total_limit + $3`,
        [user.id, rid, by],
      );
      await logActivity(c.user.id, 'admin_increase_limit', `+${by} on range ${rid} for ${user.username}`, c.ip);
      c.flash(`Limit increased by ${by}.`, 'success');
      return self();
    }
    const ranges = await db.query(`select id from sms_ranges where is_active`);
    let changed = 0;
    await tx(async (t) => {
      for (const r of ranges) {
        const k = `limit_${r.id}`;
        if (!c.form.has(k)) continue;
        const total = Math.max(0, c.form.int(k, 0) || 0);
        const daily = Math.max(0, c.form.int(`daily_${r.id}`, 0) || 0);
        const prev = await t.one(`select total_limit, daily_limit from agent_range_limits where agent_id=$1 and range_id=$2`, [user.id, r.id]);
        if (!prev && total === 0 && daily === 0) continue;
        if (prev && Number(prev.total_limit) === total && Number(prev.daily_limit) === daily && !c.form.has(`reset_${r.id}`)) continue;
        await setLimit(t, user.id, r.id, total, daily, c.form.has(`reset_${r.id}`));
        changed++;
      }
    });
    await logActivity(c.user.id, 'admin_set_user_limits', `Updated ${changed} range limits for ${user.username}`, c.ip);
    c.flash(changed ? `${changed} range limit(s) saved for ${user.username}.` : 'No changes.', changed ? 'success' : 'info');
    return self();
  }
  const rows = await limitsForUser(db, user.id);
  const search = c.query.str('search').toLowerCase();
  const shown = search ? rows.filter((r) => `${r.name || ''} ${r.country} ${r.prefix}`.toLowerCase().includes(search)) : rows;
  const totals = { total: rows.reduce((s, r) => s + Number(r.total_limit), 0), taken: rows.reduce((s, r) => s + Number(r.taken_count), 0) };
  const owner = user.is_agent() ? 'agent_id' : 'client_id';
  const current = Number(await db.scalar(`select count(*) from sms_numbers where ${owner} = $1`, [user.id]));
  render(c, 'admin/user_limits.html', { user, rows: shown, totals, search, current_numbers: current });
});

/** Give every agent (or client) the same limit on one range. */
POST('admin.set_range_limit_all', '/admin/ranges/<int:range_id>/limit-all', A, async (c) => {
  const range = await db.one(`select id, prefix, country from sms_ranges where id = $1`, [c.params.range_id]);
  if (!range) return abort(404);
  const role = c.form.get('role') === 'client' ? 'client' : 'agent';
  const total = Math.max(0, c.form.int('total_limit', 0) || 0);
  const onlyMissing = c.form.has('only_missing');
  const n = await db.exec(
    `insert into agent_range_limits (agent_id, range_id, total_limit, taken_count)
     select u.id, $1, $2, 0 from users u join roles r on r.id = u.role_id where r.name = $3 and u.is_active
     on conflict (agent_id, range_id) do update set total_limit = excluded.total_limit
       where not $4::boolean or agent_range_limits.total_limit = 0`,
    [range.id, total, role, onlyMissing],
  );
  await logActivity(c.user.id, 'admin_set_range_limit_all', `Set limit ${total} on range ${range.prefix} for ${n} ${role}s`, c.ip);
  c.flash(`Limit ${total} applied to ${n} ${role}(s) on +${range.prefix}.`, 'success');
  c.redirect(c.form.get('back') || urlFor('admin.sms_ranges'));
});

// ───────────────────────── numbers (admin) ─────────────────────────

GET('admin.sms_numbers', '/admin/sms/numbers', A, async (c) => {
  const w = new Where();
  const search = c.query.str('search');
  if (search) w.add('number ilike ?', `%${likeEscape(search)}%`);
  const agent = c.query.str('agent');
  if (agent === 'none') w.raw('agent_id is null');
  else if (agent && /^\d+$/.test(agent)) w.add('agent_id = ?', Number(agent));
  const status = c.query.str('status');
  if (status) w.add('status = ?', status);
  const frange = c.query.int('frange');
  if (frange) w.add('range_id = ?', frange);
  const per = c.query.int('per_page') ?? 50;
  const numbers = await paginate(`select * from sms_numbers${w.sql}`, w.params, 'created_at desc, id desc', c.query.int('page'), per, 50);
  await hydrateNumbers(numbers.items);
  render(c, 'admin/sms_numbers.html', { numbers, agents: await listAgents(), per_page: per });
});

const ids = (c: Ctx) => c.form.getlist('number_ids').map((x) => parseInt(x, 10)).filter((n) => Number.isInteger(n));

POST('admin.bulk_delete_numbers', '/admin/sms/numbers/bulk-delete', A, async (c) => {
  const list = ids(c);
  if (!list.length) { c.flash('No numbers selected!', 'danger'); return c.redirect(urlFor('admin.sms_numbers')); }
  const n = await tx(async (t) => {
    await t.exec(`update sms_cdr set number_id = null where number_id = any($1::int[])`, [list]);
    await t.exec(`update otp_logs set number_id = null where number_id = any($1::int[])`, [list]);
    await t.exec(`delete from test_number_assignments where number_id = any($1::int[])`, [list]);
    return t.exec(`delete from sms_numbers where id = any($1::int[])`, [list]);
  });
  await logActivity(c.user.id, 'admin_bulk_delete_numbers', `Bulk deleted ${n} numbers`, c.ip);
  c.flash(`${n} numbers permanently deleted!`, 'success');
  c.redirect(urlFor('admin.sms_numbers'));
});

POST('admin.admin_reclaim_numbers', '/admin/sms/numbers/reclaim', A, async (c) => {
  const list = ids(c);
  if (!list.length) { c.flash('No numbers selected!', 'danger'); return c.redirect(urlFor('admin.sms_numbers')); }
  const owned = (await db.query(`select id from sms_numbers where id = any($1::int[]) and (agent_id is not null or client_id is not null) and status <> 'test'`, [list])).map((r) => r.id);
  const n = await resetNumbersToPool(db, owned);
  await logActivity(c.user.id, 'admin_reclaim_numbers', `Reclaimed ${n} numbers back to range`, c.ip);
  c.flash(`${n} numbers reclaimed and returned to range!`, 'success');
  c.redirect(urlFor('admin.sms_numbers'));
});
POST('admin.admin_reclaim_single', '/admin/sms/numbers/<int:number_id>/reclaim', A, async (c) => {
  const num = await db.one(`select * from sms_numbers where id = $1`, [c.params.number_id]);
  if (!num) return abort(404);
  await resetNumbersToPool(db, [num.id]);
  await logActivity(c.user.id, 'admin_reclaim_single', `Reclaimed number ${num.number} back to range`, c.ip);
  c.flash(`Number ${num.number} reclaimed and returned to range!`, 'success');
  c.redirect(urlFor('admin.sms_numbers'));
});
POST('admin.delete_number', '/admin/sms/numbers/<int:number_id>/delete', A, async (c) => {
  const num = await db.one(`select * from sms_numbers where id = $1`, [c.params.number_id]);
  if (!num) return abort(404);
  await tx(async (t) => {
    await t.exec(`update sms_cdr set number_id = null where number_id = $1`, [num.id]);
    await t.exec(`update otp_logs set number_id = null where number_id = $1`, [num.id]);
    await t.exec(`delete from test_number_assignments where number_id = $1`, [num.id]);
    await t.exec(`delete from sms_numbers where id = $1`, [num.id]);
  });
  await logActivity(c.user.id, 'admin_delete_number', `Permanently deleted number ${num.number}`, c.ip);
  c.flash(`Number ${num.number} permanently deleted.`, 'success');
  c.redirect(urlFor('admin.sms_numbers'));
});

ANY('admin.return_numbers_from_agent', '/admin/sms/numbers/return', A, async (c) => {
  const agents = await db.query(`select u.* from users u join roles r on r.id = u.role_id where r.name = 'agent' order by u.is_active desc, u.username`);
  const agentId = c.query.int('agent_id') ?? c.form.int('agent_id');
  const selected = agentId ? await getUserById(agentId) : null;
  if (c.method === 'POST') {
    if (!selected || !selected.is_agent()) { c.flash('Choose a valid agent first.', 'danger'); return c.redirect(urlFor('admin.return_numbers_from_agent')); }
    const sel = ids(c);
    const rangeId = c.form.int('range_id');
    const qty = c.form.int('quantity', 0) || 0;
    const w = new Where().add('agent_id = ?', selected.id);
    if (rangeId) w.add('range_id = ?', rangeId);
    let sql = `select id from sms_numbers${w.sql}`;
    const params = [...w.params];
    if (sel.length) { params.push(sel); sql += ` and id = any($${params.length}::int[])`; }
    else if (qty > 0) sql += ` order by assigned_at asc nulls first, id limit ${Math.min(qty, 10000)}`;
    else { c.flash('Select numbers or enter a quantity to return.', 'danger'); return c.redirect(urlFor('admin.return_numbers_from_agent', { agent_id: selected.id })); }
    const list = (await db.query(sql, params)).map((r) => r.id);
    await resetNumbersToPool(db, list);
    await logActivity(c.user.id, 'admin_return_numbers', `Returned ${list.length} numbers from agent ${selected.username}`, c.ip);
    c.flash(`${list.length} numbers returned to the available pool.`, 'success');
    return c.redirect(urlFor('admin.return_numbers_from_agent', { agent_id: selected.id }));
  }
  let numbers: any[] = [], ranges: any[] = [];
  if (selected) {
    numbers = await db.query(`select * from sms_numbers where agent_id = $1 order by assigned_at asc nulls first, number limit 5000`, [selected.id]);
    await hydrateNumbers(numbers, { received: true });
    const rids = [...new Set(numbers.map((n) => n.range_id))];
    ranges = rids.length ? await db.query(`select * from sms_ranges where id = any($1::int[]) order by country, prefix`, [rids]) : [];
  }
  render(c, 'admin/return_numbers.html', { agents, selected_agent: selected, numbers, ranges });
});

GET('admin.sms_cdr', '/admin/sms/cdr', A, async (c) => {
  const today = ymd(new Date());
  const fdate1 = c.query.get('fdate1', today) as string;
  const fdate2 = c.query.get('fdate2', today) as string;
  const d1 = parseDateInput(fdate1);
  const e = parseDateInput(fdate2);
  const d2 = new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), 23, 59, 59));
  const w = new Where().add('created_at >= ?', d1).add('created_at <= ?', d2);
  const cdr_records = await paginate(`select * from sms_cdr${w.sql}`, w.params, 'created_at desc, id desc', c.query.int('page'), 50, 50);
  const { hydrateCdrs } = await import('../models');
  await hydrateCdrs(cdr_records.items);
  await attachUsers(cdr_records.items, 'user_id', 'agent');
  await attachUsers(cdr_records.items, 'client_id', 'client');
  const totals = await db.one(`select count(*) as total, coalesce(sum(profit),0) as total_profit from sms_cdr${w.sql}`, w.params);
  render(c, 'admin/sms_cdr.html', { cdr_records, totals, fdate1, fdate2 });
});

// ───────────────────────── admin: add numbers to an agent ─────────────────────────

ANY('admin.add_numbers_to_agent', '/admin/add-numbers-to-agent', A, async (c) => {
  if (c.method === 'POST') {
    const agentId = c.form.int('agent_id'), rangeId = c.form.int('range_id'), count = c.form.int('count', 0) || 0;
    const back = () => c.redirect(urlFor('admin.add_numbers_to_agent'));
    if (!agentId || !rangeId || count <= 0 || count > 10000) { c.flash('All fields are required!', 'danger'); return back(); }
    const agent = await getUserById(agentId);
    if (!agent || !agent.is_agent()) { c.flash('Invalid agent or range!', 'danger'); return back(); }
    try {
      const res = await tx(async (t) => {
        const range = await t.one(`select * from sms_ranges where id = $1 and is_active`, [rangeId]);
        if (!range) throw new UserError('Invalid agent or range!');
        const got = await allocateFromRange(t, { range, role: 'agent', ownerId: agent.id, count, random: c.form.get('mode') === 'random' });
        if (!got.length) throw new UserError('No available numbers in this range!');
        return { range, got };
      });
      await logActivity(c.user.id, 'admin_add_numbers_to_agent', `Added ${res.got.length} numbers from ${res.range.prefix} to agent ${agent.username}`, c.ip);
      c.flash(`${res.got.length} numbers added to ${agent.username} successfully!${res.got.length < count ? ` (only ${res.got.length} were available)` : ''}`, 'success');
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      c.flash(e.message, 'warning');
    }
    return back();
  }
  const search = c.query.str('search');
  const w = new Where().raw(`r.name = 'agent'`);
  if (search) { const l = `%${likeEscape(search)}%`; w.add(`(u.username ilike ? or coalesce(u.name,'') ilike ?)`, l, l); }
  const agents = await db.query(`select u.* from users u join roles r on r.id = u.role_id${w.sql} order by u.username`, w.params);
  const ranges = await withRangeCounts(await db.query(`select * from sms_ranges where is_active order by country, prefix`));
  render(c, 'admin/add_numbers_to_agent.html', { agents, ranges, search });
});

// ───────────────────────── agent area (agents + admin) ─────────────────────────

/** Old "add numbers" entry point now goes through the quota-checked self-service flow. */
ANY('admin.agent_add_numbers', '/agent/add-numbers', memberRequired, requestPage);

GET('admin.agent_my_numbers', '/agent/my-numbers', agentRequired, async (c) => {
  const uid = c.user.id;
  const w = new Where().add('agent_id = ?', uid);
  const search = c.query.str('search');
  if (search) w.add('number ilike ?', `%${likeEscape(search)}%`);
  const frange = c.query.int('frange');
  if (frange) w.add('range_id = ?', frange);
  const fclient = c.query.str('fclient');
  if (fclient === 'none') w.raw('client_id is null');
  else if (fclient && /^\d+$/.test(fclient)) w.add('client_id = ?', Number(fclient));
  const per = c.query.int('per_page') ?? 25;
  const numbers = await paginate(`select * from sms_numbers${w.sql}`, w.params, 'number', c.query.int('page'), per, 25);
  await hydrateNumbers(numbers.items);
  const cnt = await db.one(`select count(*) as total, count(client_id) as assigned from sms_numbers where agent_id = $1`, [uid]);
  const ranges = await db.query(`select * from sms_ranges where id in (select distinct range_id from sms_numbers where agent_id = $1) order by country`, [uid]);
  const clients = await db.query(`select id, username from users where agent_id = $1 order by username`, [uid]);
  render(c, 'admin/agent_my_numbers.html', { numbers, total_numbers: cnt!.total, assigned_count: cnt!.assigned, free_count: cnt!.total - cnt!.assigned, ranges, clients, per_page: per });
});

const back = (c: Ctx) => c.redirect(urlFor('admin.agent_my_numbers'));

POST('admin.agent_bulk_assign', '/agent/bulk-assign', agentRequired, async (c) => {
  const list = ids(c);
  const clientId = c.form.int('client_id');
  const payout = Math.max(0, c.form.float('client_payout', 0) || 0);
  if (!list.length) { c.flash('No numbers selected!', 'danger'); return back(c); }
  if (!clientId) { c.flash('Please select a client!', 'danger'); return back(c); }
  const client = await db.one(`select id, username from users where id = $1 and agent_id = $2`, [clientId, c.user.id]);
  if (!client) { c.flash('Invalid client!', 'danger'); return back(c); }
  const mine = Number(await db.scalar(`select count(*) from sms_numbers where id = any($1::int[]) and agent_id = $2`, [list, c.user.id]));
  const n = await db.exec(
    `update sms_numbers set client_id = $3, client_payout = $4, status = 'activated', assigned_at = now()
     where id = any($1::int[]) and agent_id = $2 and (client_id is null or client_id = $3)`,
    [list, c.user.id, client.id, payout],
  );
  let msg = `${n} numbers assigned to ${client.username} at $${payout}/OTP!`;
  if (mine > n) msg += ` (${mine - n} skipped — already assigned to another client)`;
  c.flash(msg, 'success');
  back(c);
});
POST('admin.agent_bulk_unassign', '/agent/bulk-unassign', agentRequired, async (c) => {
  const list = ids(c);
  if (!list.length) { c.flash('No numbers selected!', 'danger'); return back(c); }
  const n = await db.exec(`update sms_numbers set client_id = null, client_payout = 0, status = 'reserved' where id = any($1::int[]) and agent_id = $2 and status <> 'test'`, [list, c.user.id]);
  c.flash(`${n} numbers unassigned!`, 'success');
  back(c);
});
POST('admin.agent_return_numbers', '/agent/return-numbers', agentRequired, async (c) => {
  const list = ids(c);
  if (!list.length) { c.flash('No numbers selected!', 'danger'); return back(c); }
  const mine = (await db.query(`select id from sms_numbers where id = any($1::int[]) and agent_id = $2 and status <> 'test'`, [list, c.user.id])).map((r) => r.id);
  const n = await resetNumbersToPool(db, mine);
  c.flash(`${n} numbers returned to range!`, 'success');
  back(c);
});
POST('admin.agent_download_numbers', '/agent/download-numbers', loginRequired, async (c) => {
  const list = ids(c);
  const col = c.user.is_client() ? 'client_id' : 'agent_id';
  const rows = list.length
    ? await db.query(`select * from sms_numbers where id = any($1::int[]) and ${col} = $2 order by number`, [list, c.user.id])
    : await db.query(`select * from sms_numbers where ${col} = $1 order by number`, [c.user.id]);
  await hydrateNumbers(rows);
  const out: any[][] = [['Number', 'Range', 'Client', 'Status', 'OTP Price', 'Assigned At']];
  for (const n of rows as any[]) out.push([n.number, n.sms_range ? `+${n.sms_range.prefix} - ${n.sms_range.country}` : '', n.client?.username || 'Unassigned', n.status, n.client_payout, n.assigned_at ? n.assigned_at.strftime('%Y-%m-%d %H:%M') : '']);
  c.download(toCsv(out), 'numbers.csv');
});
ANY('admin.agent_create_client', '/agent/create-client', agentRequired, async (c) => {
  if (c.method !== 'POST') return render(c, 'admin/agent_create_client.html');
  const f = c.form;
  const username = f.str('username'), email = f.str('email').toLowerCase(), password = f.get('password', '') as string;
  const fail = (m: string) => (c.flash(m, 'danger'), c.redirect(urlFor('admin.agent_create_client')));
  if (!username || !email || password.length < 6) return fail('Username, email, and a password of at least 6 characters are required.');
  if (await db.scalar(`select 1 from users where lower(username)=lower($1)`, [username])) return fail('Username already exists.');
  if (await db.scalar(`select 1 from users where lower(email)=$1`, [email])) return fail('Email already registered.');
  const role = await roleByName('client');
  if (!role) return fail('Client role not found.');
  try {
    await db.exec(`insert into users (username,email,password_hash,role_id,name,company,country,agent_id,is_active) values ($1,$2,$3,$4,$5,$6,$7,$8,true)`,
      [username, email, await hashPassword(password), role.id, f.get('name'), f.get('company'), f.get('country'), c.user.id]);
  } catch (e) {
    if (isUniqueViolation(e)) return fail('Username or email already exists.');
    throw e;
  }
  await logActivity(c.user.id, 'agent_create_client', `Created client ${username}`, c.ip);
  c.flash(`Client ${username} created successfully!`, 'success');
  c.redirect(urlFor('admin.agent_clients'));
});
GET('admin.agent_clients', '/agent/clients', agentRequired, async (c) => {
  const w = new Where().add('agent_id = ?', c.user.id);
  const search = c.query.str('search');
  if (search) { const l = `%${likeEscape(search)}%`; w.add(`(username ilike ? or email ilike ? or coalesce(name,'') ilike ?)`, l, l, l); }
  const clients = await paginate(`select * from users${w.sql}`, w.params, 'created_at desc', c.query.int('page'), 25, 25);
  render(c, 'admin/agent_clients.html', { clients });
});
void startOfUtcDay;
