import { GET, POST, ANY, urlFor, Ctx } from '../http';
import { db, likeEscape, tx, isUniqueViolation } from '../db';
import { render } from '../views';
import { loginRequired, notClient, clientOnly, memberRequired, hashPassword, checkPassword } from '../auth';
import { attachRanges, hydrateCdrs, hydrateNumbers, logActivity, withRangeCounts, roleByName } from '../models';
import { paginate, Where } from '../page';
import { addDays, parseDateInput, startOfUtcDay, toCsv, ymd, UserError } from '../util';
import { addTestNumbersForUser } from '../services/lifecycle';
import { limitsForUser, requestNumbers } from '../services/numbers';

// ───────────────────────── dashboard ─────────────────────────

const dashboard = async (c: Ctx) => {
  const u = c.user;
  const col = u.is_client() ? 'client_id' : 'user_id';
  const today = startOfUtcDay();
  const weekAgo = addDays(today, -7);
  const firstOfMonth = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
  const tomorrow = addDays(today, 1);

  const cnt = await db.one(
    `select count(*) filter (where created_at >= $2 and created_at < $3) as today,
            count(*) filter (where created_at >= $4) as week,
            count(*) filter (where created_at >= $5) as month
     from sms_cdr where ${col} = $1`,
    [u.id, today, tomorrow, weekAgo, firstOfMonth],
  );
  const days = await db.query(
    `select (created_at at time zone 'UTC')::date as d, count(*) as n from sms_cdr
     where ${col} = $1 and created_at >= $2 group by 1`,
    [u.id, addDays(today, -6)],
  );
  const dm = new Map(days.map((r) => [r.d as string, r.n as number]));
  const chart_data = [];
  for (let i = 6; i >= 0; i--) {
    const d = ymd(addDays(today, -i));
    chart_data.push({ date: d, count: dm.get(d) ?? 0 });
  }
  const [ranges_count, numbers_count, clients_count, news, recent_clients] = await Promise.all([
    db.scalar(`select count(*) from sms_ranges where is_active`),
    db.scalar(`select count(*) from sms_numbers where ${u.is_client() ? 'client_id' : 'agent_id'} = $1`, [u.id]),
    db.scalar(`select count(*) from users where agent_id = $1`, [u.id]),
    db.query(`select * from news where is_active order by created_at desc limit 5`),
    db.query(`select * from users where agent_id = $1 order by created_at desc limit 5`, [u.id]),
  ]);
  render(c, 'main/dashboard.html', {
    today_sms: cnt!.today,
    week_sms: cnt!.week,
    month_total: cnt!.month,
    ranges_count,
    numbers_count,
    clients_count,
    news,
    recent_clients,
    chart_data,
  });
};
GET('main.dashboard', ['/agent/dashboard', '/agent/'], loginRequired, dashboard);

GET('main.api_docs', '/agent/api-docs', loginRequired, (c) => render(c, 'main/api_docs.html', { api_user: c.user }));

GET('main.notifications', '/agent/Notifications', loginRequired, async (c) => {
  const news = await db.query(`select * from news where is_active order by created_at desc limit 50`);
  render(c, 'main/notifications.html', { news });
});

// ───────────────────────── ranges / self-service numbers ─────────────────────────

GET('main.sms_ranges', '/agent/SMSRanges', loginRequired, async (c) => {
  const w = new Where().raw('is_active');
  const search = c.query.str('search');
  if (search) w.add(`(prefix ilike ? or country ilike ?)`, `%${likeEscape(search)}%`, `%${likeEscape(search)}%`);
  const ranges = await paginate(`select * from sms_ranges${w.sql}`, w.params, 'country, prefix', c.query.int('page'), c.query.int('per_page'));
  await withRangeCounts(ranges.items, c.user.id);
  render(c, 'main/sms_ranges.html', { ranges });
});

POST('main.add_test_numbers', '/agent/test-numbers/<int:range_id>', loginRequired, async (c) => {
  const range = await db.one(`select * from sms_ranges where id = $1 and is_active`, [c.params.range_id]);
  if (!range) {
    c.flash('Range not found.', 'danger');
    return c.redirect(urlFor('main.sms_ranges'));
  }
  if (c.user.is_developer() && !c.user.is_admin()) {
    c.flash('This account cannot request test numbers.', 'danger');
    return c.redirect(urlFor('main.sms_ranges'));
  }
  try {
    const added = await tx((t) => addTestNumbersForUser(t, c.user, range));
    if (added.length) c.flash(`${added.length} fixed test numbers added from ${range.country} / +${range.prefix}.`, 'success');
    else {
      const already = Number(await db.scalar(`select count(*) from test_number_assignments where user_id = $1 and range_id = $2`, [c.user.id, range.id]));
      c.flash(already ? 'These test numbers are already in your account.' : 'No fixed test numbers are available for this range.', 'info');
    }
  } catch (e) {
    console.error('[add_test_numbers]', e);
    c.flash('Test pool is unavailable right now. Please try again.', 'danger');
    return c.redirect(urlFor('main.sms_ranges'));
  }
  c.redirect(c.user.is_client() ? urlFor('main.client_my_numbers') : urlFor('main.sms_ranges'));
});

/** Page where agents/clients take random numbers by themselves, within the limit set by the admin. */
export const requestPage = async (c: Ctx) => {
  const u = c.user;
  const role = u.is_client() ? 'client' : 'agent';
  if (c.method === 'POST') {
    const rangeId = c.form.int('range_id');
    const count = c.form.int('numbers_count', 0)!;
    try {
      if (!rangeId) throw new UserError('Please select a range.');
      const res = await requestNumbers({ id: u.id, role }, rangeId, count);
      await logActivity(u.id, 'self_request_numbers', `Took ${res.got.length} random numbers from range ${res.range.prefix} (${res.range.country})`, c.ip);
      let msg = `${res.got.length} numbers added to your account from ${res.range.country} / +${res.range.prefix}.`;
      if (res.clamped) msg += ` You asked for ${res.requested}, but only ${res.got.length} were allowed by your limit.`;
      msg += res.remaining > 0 ? ` Remaining limit on this range: ${res.remaining}.` : ' You have used your whole limit on this range.';
      c.flash(msg, 'success');
      return c.redirect(role === 'client' ? urlFor('main.client_my_numbers') : urlFor('admin.agent_my_numbers'));
    } catch (e) {
      if (e instanceof UserError) c.flash(e.message, 'danger');
      else {
        console.error('[request_numbers]', e);
        c.flash('Could not add numbers right now. Please try again.', 'danger');
      }
      return c.redirect(urlFor('main.request_numbers'));
    }
  }
  const search = c.query.str('search').toLowerCase();
  let rows = await limitsForUser(db, u.id);
  if (search) rows = rows.filter((r) => `${r.name || ''} ${r.country} ${r.prefix}`.toLowerCase().includes(search));
  const mine = rows.filter((r) => Number(r.total_limit) > 0);
  const others = rows.filter((r) => Number(r.total_limit) <= 0);
  const current = Number(await db.scalar(`select count(*) from sms_numbers where ${role === 'client' ? 'client_id' : 'agent_id'} = $1`, [u.id]));
  render(c, 'main/request_numbers.html', { mine, others, current_numbers: current, search });
};
ANY('main.request_numbers', '/agent/request-numbers', memberRequired, requestPage);

/** "Ask for more": logs a request the admin can see on his dashboard. */
POST('main.request_limit_increase', '/agent/request-limit/<int:range_id>', memberRequired, async (c) => {
  const range = await db.one(`select id, name, prefix, country from sms_ranges where id = $1`, [c.params.range_id]);
  if (!range) {
    c.flash('Range not found.', 'danger');
    return c.redirect(urlFor('main.request_numbers'));
  }
  const note = c.form.str('note').slice(0, 200);
  await logActivity(c.user.id, 'limit_increase_request', `range=${range.id}|${range.name || range.country} +${range.prefix}${note ? '|' + note : ''}`, c.ip);
  c.flash('Your request was sent to the administrator.', 'success');
  c.redirect(urlFor('main.request_numbers'));
});

// ───────────────────────── test panel ─────────────────────────

const maskDigits = (s: string | null) => (s ? s.replace(/\d{4,}/g, (m) => '•'.repeat(m.length)) : s);
const maskNumber = (s: string | null) => (s && s.length > 6 ? s.slice(0, 4) + '•'.repeat(s.length - 6) + s.slice(-2) : s);

GET('main.sms_test_panel', '/agent/SMSTestPanel', loginRequired, async (c) => {
  const w = new Where();
  const frange = c.query.int('frange');
  if (frange) w.add('range_id = ?', frange);
  const cdr = await paginate(`select * from sms_cdr${w.sql}`, w.params, 'created_at desc, id desc', c.query.int('page'), c.query.int('per_page'));
  await hydrateCdrs(cdr.items);
  if (!c.user.is_admin()) {
    // The live feed shows which platforms deliver OTPs; codes and full numbers stay private.
    for (const r of cdr.items) {
      r.message = maskDigits(r.message);
      r.destination = maskNumber(r.destination);
      if (r.sms_number) r.sms_number = { ...r.sms_number, number: maskNumber(r.sms_number.number) };
    }
  }
  const total = await db.scalar(`select count(*) from sms_cdr`);
  const ranges = await db.query(`select * from sms_ranges where is_active order by country`);
  render(c, 'main/sms_test_panel.html', { cdr_records: cdr, total_sms: total, ranges });
});

// ───────────────────────── client numbers ─────────────────────────

GET('main.client_my_numbers', '/agent/MyAssignedNumbers', clientOnly, async (c) => {
  const u = c.user;
  const w = new Where().add('client_id = ?', u.id);
  const search = c.query.str('search');
  if (search) w.add('number ilike ?', `%${likeEscape(search)}%`);
  const frange = c.query.int('frange');
  if (frange) w.add('range_id = ?', frange);
  const per = c.query.int('per_page');
  const numbers = await paginate(`select * from sms_numbers${w.sql}`, w.params, 'number', c.query.int('page'), per);
  await hydrateNumbers(numbers.items);
  const test_assignments = await db.query(
    `select a.*, n.number from test_number_assignments a join sms_numbers n on n.id = a.number_id where a.user_id = $1 order by a.range_id, a.number_id`,
    [u.id],
  );
  await attachRanges(test_assignments, 'range_id', 'range_info');
  const own = Number(await db.scalar(`select count(*) from sms_numbers where client_id = $1`, [u.id]));
  const ranges = await db.query(`select * from sms_ranges where id in (select distinct range_id from sms_numbers where client_id = $1) order by country`, [u.id]);
  render(c, 'main/client_numbers.html', {
    numbers,
    total_numbers: own + test_assignments.length,
    per_page: per ?? 25,
    ranges,
    test_assignments,
  });
});

GET('main.client_download_numbers', '/agent/DownloadMyAssignedNumbers', clientOnly, async (c) => {
  const rows = await hydrateNumbers(await db.query(`select * from sms_numbers where client_id = $1 order by number`, [c.user.id]));
  const out: any[][] = [['Number', 'Range', 'OTP Price', 'Status', 'Assigned Date']];
  for (const n of rows as any[]) {
    out.push([n.number, n.sms_range ? `+${n.sms_range.prefix} - ${n.sms_range.country}` : '', n.client_payout, n.status, n.assigned_at ? n.assigned_at.strftime('%Y-%m-%d %H:%M') : '']);
  }
  c.download(toCsv(out), 'my_numbers.csv');
});

// ───────────────────────── CDR reports ─────────────────────────

GET('main.sms_cdr_reports', '/agent/SMSCDRReports', loginRequired, async (c) => {
  const u = c.user;
  const todayStr = ymd(new Date());
  const fdate1 = c.query.get('fdate1', todayStr) as string;
  const fdate2 = c.query.get('fdate2', todayStr) as string;
  const date1 = parseDateInput(fdate1);
  const d2 = parseDateInput(fdate2);
  const date2 = new Date(Date.UTC(d2.getUTCFullYear(), d2.getUTCMonth(), d2.getUTCDate(), 23, 59, 59));

  const w = new Where().add(`c.${u.is_client() ? 'client_id' : 'user_id'} = ?`, u.id).add('c.created_at >= ?', date1).add('c.created_at <= ?', date2);
  const frange = c.query.int('frange');
  if (frange) w.add('c.range_id = ?', frange);
  if (!u.is_client()) {
    const fclient = c.query.int('fclient');
    if (fclient) w.add('c.client_id = ?', fclient);
  }
  const fnum = c.query.str('fnum');
  if (fnum) w.add('c.number_id in (select id from sms_numbers where number ilike ?)', `%${likeEscape(fnum)}%`);

  const cdr = await paginate(`select c.* from sms_cdr c${w.sql}`, w.params, 'c.created_at desc, c.id desc', c.query.int('page'), c.query.int('per_page'));
  await hydrateCdrs(cdr.items);
  const totals = await db.one(
    `select count(*) as total_sms, coalesce(sum(c.agent_payout),0) as total_payout, coalesce(sum(c.client_payout),0) as total_client from sms_cdr c${w.sql}`,
    w.params,
  );
  const ranges = await db.query(`select * from sms_ranges where is_active order by country`);
  const clients = u.is_client() ? [] : await db.query(`select id, username from users where agent_id = $1 order by username`, [u.id]);
  render(c, 'main/sms_cdr_reports.html', { cdr_records: cdr, totals, ranges, clients, fdate1, fdate2 });
});

// ───────────────────────── clients ─────────────────────────

GET('main.clients', '/agent/Clients', notClient, async (c) => {
  const clients = await paginate(`select * from users where agent_id = $1`, [c.user.id], 'created_at desc', c.query.int('page'), 25, 25);
  render(c, 'main/clients.html', { clients });
});

ANY('main.create_client', '/agent/CreateClient', notClient, async (c) => {
  if (c.method !== 'POST') return render(c, 'main/create_client.html');
  const username = c.form.str('username');
  const email = c.form.str('email').toLowerCase();
  const password = c.form.get('password', '') as string;
  if (!username || !email || password.length < 6) {
    c.flash('Username, email and a password of at least 6 characters are required.', 'danger');
    return c.redirect(urlFor('main.create_client'));
  }
  if (await db.scalar(`select 1 from users where lower(username) = lower($1)`, [username])) {
    c.flash('Username already exists!', 'danger');
    return c.redirect(urlFor('main.create_client'));
  }
  if (await db.scalar(`select 1 from users where lower(email) = lower($1)`, [email])) {
    c.flash('Email already exists!', 'danger');
    return c.redirect(urlFor('main.create_client'));
  }
  const role = await roleByName('client');
  try {
    await db.exec(
      `insert into users (username, email, name, company, contact, country, role_id, agent_id, password_hash, is_active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,true)`,
      [username, email, c.form.get('name'), c.form.get('company'), c.form.get('contact'), c.form.get('country'), role?.id, c.user.id, await hashPassword(password)],
    );
  } catch (e) {
    if (!isUniqueViolation(e)) throw e;
    c.flash('Username or email already exists!', 'danger');
    return c.redirect(urlFor('main.create_client'));
  }
  await logActivity(c.user.id, 'create_client', `Created client ${username}`, c.ip);
  c.flash('Client created successfully!', 'success');
  c.redirect(urlFor('main.clients'));
});

// ───────────────────────── profile / activity ─────────────────────────

ANY('main.profile', '/agent/Profile', loginRequired, async (c) => {
  if (c.method === 'POST') {
    if (c.form.get('action') === 'change_password') {
      const cur = c.form.get('current_password', '') as string;
      const np = c.form.get('new_password', '') as string;
      const cp = c.form.get('confirm_password', '') as string;
      const row = await db.one(`select password_hash from users where id = $1`, [c.user.id]);
      if (!row || !(await checkPassword(cur, row.password_hash))) c.flash('Current password is wrong!', 'danger');
      else if (np !== cp) c.flash('New passwords do not match!', 'danger');
      else if (np.length < 6) c.flash('Password must be at least 6 characters!', 'danger');
      else {
        const hash = await hashPassword(np);
        await db.exec(`update users set password_hash = $2 where id = $1`, [c.user.id, hash]);
        const { loginUser } = await import('../auth');
        loginUser(c, c.user, hash); // keep this session alive after the password change
        c.flash('Password changed successfully!', 'success');
      }
    } else {
      const email = c.form.str('email').toLowerCase();
      if (!/^[^@\s]+@[^@\s]+$/.test(email)) c.flash('Please enter a valid email address.', 'danger');
      else if (await db.scalar(`select 1 from users where lower(email) = $1 and id <> $2`, [email, c.user.id])) c.flash('Email already registered by another user.', 'danger');
      else {
        await db.exec(
          `update users set name=$2, company=$3, email=$4, skype=$5, contact=$6, country=$7, address=$8 where id = $1`,
          [c.user.id, c.form.get('name'), c.form.get('company'), email, c.form.get('skype'), c.form.get('contact'), c.form.get('country'), c.form.get('address')],
        );
        c.flash('Profile updated successfully.', 'success');
      }
    }
    return c.redirect(urlFor('main.profile'));
  }
  render(c, 'main/profile.html');
});

GET('main.my_activity', '/agent/MyActivity', loginRequired, async (c) => {
  const activities = await paginate(`select * from activity_logs where user_id = $1`, [c.user.id], 'created_at desc, id desc', c.query.int('page'), 50, 50);
  render(c, 'main/my_activity.html', { activities });
});
