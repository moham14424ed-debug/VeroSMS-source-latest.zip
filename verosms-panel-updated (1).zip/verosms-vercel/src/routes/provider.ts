import { PyDict } from '../util';
import { GET, POST, ANY, urlFor, abort } from '../http';
import { db } from '../db';
import { render } from '../views';
import { adminRequired, loginRequired } from '../auth';
import { paginate, Where } from '../page';
import { pollProvider } from '../fetchers';
import { logActivity } from '../models';

/** Known panels (the hard-coded third-party entries of the original project were removed). */
export const BUILTIN_PANELS: Record<string, Record<string, string>> = {
  'Hadi SMS API': {
    url: 'http://147.135.212.197/crapi/had/viewstats', ptype: 'api', auth_mode: 'token', request_method: 'GET', request_format: 'query',
    request_params: '{"token":"{{password}}","records":"200","dt1":"","dt2":""}', response_path: 'data', number_field: 'num', sender_field: 'cli', message_field: 'message', date_field: 'dt',
  },
  'RouteCore / Root Corona (INTS)': {
    url: 'http://148.113.242.198/ints', ptype: 'ints', auth_mode: 'basic', request_method: 'GET', request_format: 'query',
    request_params: '{}', response_path: 'data', number_field: 'num', sender_field: 'cli', message_field: 'message', date_field: 'dt',
  },
  ChoiceSMS: { url: 'http://51.77.52.79/ints', ptype: 'ints' },
  FlynSMS: { url: 'http://91.232.105.47/ints', ptype: 'ints' },
  Gaza: { url: 'http://144.217.71.192/ints', ptype: 'ints' },
  GoatPanel: { url: 'http://167.114.117.67/ints', ptype: 'ints' },
  ImsPanel: { url: 'https://www.imssms.org', ptype: 'ims' },
  KmSms: { url: 'http://54.36.173.235/ints', ptype: 'ints' },
  Konekta: { url: 'https://konektapremium.net', ptype: 'konekta' },
  NumberPanel: { url: 'http://51.89.99.105/NumberPanel', ptype: 'numberpanel' },
  ProofSMS: { url: 'http://217.182.195.194/ints', ptype: 'proofsms' },
  PurplePanel: { url: 'http://85.195.94.50/sms', ptype: 'standard' },
  RoxySMS: { url: 'http://www.roxysms.net', ptype: 'roxy' },
  Seven1Tel: { url: 'http://94.23.120.156/ints', ptype: 'ints' },
  SharkSMS: { url: 'http://65.109.111.158/ints', ptype: 'ints' },
  TrueSMS: { url: 'https://truesms.net', ptype: 'standard' },
  VoiceGate: { url: 'http://51.89.7.175/sms', ptype: 'voicegate' },
  Wolf: { url: 'http://213.32.24.208/ints', ptype: 'ints' },
  GreenSMS: { url: 'http://139.99.9.4/ints', ptype: 'ints' },
  FireSMS: { url: 'http://54.39.104.241/ints', ptype: 'ints' },
  SniperPanel: { url: 'http://135.125.222.224/ints', ptype: 'sniper' },
  MAIT: { url: 'http://168.119.13.175/ints', ptype: 'ints' },
  TimeSMS: { url: 'https://www.timesms.org', ptype: 'timesms' },
};

const validJson = (s: string) => {
  try {
    JSON.parse(s || '{}');
    return true;
  } catch {
    return false;
  }
};

function fields(c: any, cur: any = {}) {
  const f = c.form;
  const g = (k: string, d: string) => (f.has(k) ? f.str(k) : cur[k] ?? d);
  return {
    name: f.has('name') ? f.str('name') : cur.name,
    url: g('url', '').replace(/\/+$/, ''),
    ptype: g('ptype', 'ints'),
    username: f.has('username') ? f.get('username', '') : cur.username ?? '',
    password: f.has('password') && f.get('password', '') !== '' ? f.get('password', '') : cur.password ?? '',
    fetch_interval: Math.min(Math.max(f.int('fetch_interval', cur.fetch_interval ?? 10) || 10, 5), 3600),
    auth_mode: g('auth_mode', 'basic'),
    request_method: g('request_method', 'GET').toUpperCase(),
    request_format: g('request_format', 'query'),
    request_params: g('request_params', '{}') || '{}',
    request_headers: g('request_headers', '{}') || '{}',
    response_path: g('response_path', 'data'),
    number_field: g('number_field', 'num'),
    sender_field: g('sender_field', 'cli'),
    message_field: g('message_field', 'message'),
    date_field: g('date_field', 'dt'),
  };
}

GET('provider.providers', '/admin/providers', adminRequired, async (c) => {
  const providers = await db.query(`select * from providers order by created_at desc`);
  render(c, 'admin/providers.html', { providers, builtin_panels: BUILTIN_PANELS });
});

ANY('provider.add_provider', '/admin/providers/add', adminRequired, async (c) => {
  if (c.method === 'POST') {
    const p = fields(c);
    if (!p.name || !p.url) {
      c.flash('Name and URL are required.', 'danger');
      return c.redirect(urlFor('provider.add_provider'));
    }
    if (!/^https?:\/\//i.test(p.url)) {
      c.flash('URL must start with http:// or https://', 'danger');
      return c.redirect(urlFor('provider.add_provider'));
    }
    if (!validJson(p.request_params) || !validJson(p.request_headers)) {
      c.flash('Request parameters and headers must be valid JSON.', 'danger');
      return c.redirect(urlFor('provider.add_provider'));
    }
    if (await db.scalar(`select 1 from providers where name = $1`, [p.name])) {
      c.flash('Provider name already exists!', 'danger');
      return c.redirect(urlFor('provider.add_provider'));
    }
    const row = await db.one(
      `insert into providers (name,url,ptype,username,password,fetch_interval,auth_mode,request_method,request_format,request_params,request_headers,response_path,number_field,sender_field,message_field,date_field,is_active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,true) returning id`,
      [p.name, p.url, p.ptype, p.username, p.password, p.fetch_interval, p.auth_mode, p.request_method, p.request_format, p.request_params, p.request_headers, p.response_path, p.number_field, p.sender_field, p.message_field, p.date_field],
    );
    await logActivity(c.user.id, 'add_provider', `Added provider ${p.name}`, c.ip);
    // first fetch right away so problems (wrong password, blocked IP) show up immediately
    const res = await pollProvider(row!.id, true).catch(() => null);
    if (res?.status === 'error') c.flash(`Provider ${p.name} added, but the first fetch failed: ${res.error}`, 'warning');
    else c.flash(`Provider ${p.name} added and connected.`, 'success');
    return c.redirect(urlFor('provider.providers'));
  }
  const builtin_name = c.query.str('builtin');
  render(c, 'admin/provider_add.html', { builtin_name, builtin_data: new PyDict(Object.entries(BUILTIN_PANELS[builtin_name] || {})), builtin_panels: BUILTIN_PANELS });
});

ANY('provider.edit_provider', '/admin/providers/<int:provider_id>/edit', adminRequired, async (c) => {
  const cur = await db.one(`select * from providers where id = $1`, [c.params.provider_id]);
  if (!cur) abort(404);
  if (c.method === 'POST') {
    const p = fields(c, cur);
    if (!validJson(p.request_params) || !validJson(p.request_headers)) {
      c.flash('Request parameters and headers must be valid JSON.', 'danger');
      return c.redirect(urlFor('provider.edit_provider', { provider_id: cur.id }));
    }
    await db.exec(
      `update providers set url=$2,ptype=$3,username=$4,password=$5,fetch_interval=$6,auth_mode=$7,request_method=$8,request_format=$9,request_params=$10,request_headers=$11,
         response_path=$12,number_field=$13,sender_field=$14,message_field=$15,date_field=$16,session_state=null,last_error=null where id=$1`,
      [cur.id, p.url, p.ptype, p.username, p.password, p.fetch_interval, p.auth_mode, p.request_method, p.request_format, p.request_params, p.request_headers, p.response_path, p.number_field, p.sender_field, p.message_field, p.date_field],
    );
    c.flash(`Provider ${cur.name} updated!`, 'success');
    return c.redirect(urlFor('provider.providers'));
  }
  render(c, 'admin/provider_edit.html', { provider: cur });
});

POST('provider.delete_provider', '/admin/providers/<int:provider_id>/delete', adminRequired, async (c) => {
  const p = await db.one(`select name from providers where id = $1`, [c.params.provider_id]);
  if (!p) abort(404);
  await db.exec(`delete from providers where id = $1`, [c.params.provider_id]); // otp_logs keep history (provider_id set null)
  await logActivity(c.user.id, 'delete_provider', `Deleted provider ${p.name}`, c.ip);
  c.flash(`Provider ${p.name} deleted!`, 'success');
  c.redirect(urlFor('provider.providers'));
});

POST('provider.toggle_provider', '/admin/providers/<int:provider_id>/toggle', adminRequired, async (c) => {
  const p = await db.one(`update providers set is_active = not is_active, last_error = null where id = $1 returning is_active`, [c.params.provider_id]);
  if (!p) abort(404);
  c.jsonOut({ status: p.is_active ? 'started' : 'stopped' });
});

/** Fetch now, bypassing the interval (button "Fetch now"). */
POST('provider.poll_now', '/admin/providers/<int:provider_id>/poll', adminRequired, async (c) => {
  const res = await pollProvider(c.params.provider_id, true);
  c.jsonOut(res ?? { status: 'error', error: 'not found' });
});

GET('provider.otp_logs', '/admin/otp-logs', adminRequired, async (c) => {
  const logs = await paginate(`select * from otp_logs`, [], 'received_at desc, id desc', c.query.int('page'), 50, 50);
  const pm = new Map((await db.query(`select id, name from providers`)).map((r) => [r.id, r.name]));
  for (const l of logs.items) l.provider = l.provider_id ? { name: pm.get(l.provider_id) || '' } : null;
  render(c, 'admin/otp_logs.html', { logs });
});

const inboxWhere = (c: any) => (c.user.is_admin() ? new Where() : new Where().add('user_id = ?', c.user.id));

GET('provider.otp_inbox', '/agent/otp-inbox', loginRequired, async (c) => {
  const w = inboxWhere(c);
  const logs = await paginate(`select * from otp_logs${w.sql}`, w.params, 'received_at desc, id desc', c.query.int('page'), 50, 50);
  render(c, 'main/otp_inbox.html', { logs });
});

GET('provider.otp_inbox_api', '/api/otp-inbox', loginRequired, async (c) => {
  const w = inboxWhere(c);
  const rows = await db.query(`select * from otp_logs${w.sql} order by received_at desc, id desc limit 50`, w.params);
  c.jsonOut(rows.map((l) => ({ id: l.id, number: l.number, otp: l.otp, sender: l.sender, message: l.message, received_at: l.received_at.strftime('%Y-%m-%d %H:%M:%S') })));
});
