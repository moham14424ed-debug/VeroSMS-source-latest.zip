import { PyDict } from '../util';
import bcrypt from 'bcryptjs';
import { GET, POST, ANY, urlFor, abort, Ctx } from '../http';
import { db, tx, isUniqueViolation, likeEscape } from '../db';
import { render } from '../views';
import { adminRequired } from '../auth';
import { hashPassword } from '../auth';
import { USER_SQL, UserView, getRoles, getUserById, listAgents, logActivity, roleByName } from '../models';
import { paginate, Where } from '../page';
import { UserError, parseCsv, randomToken, startOfUtcDay, addDays, toCsv } from '../util';
import { allocateFromRange } from '../services/numbers';
import { addNumbersToRange, extractNumbers } from './ranges';
import { resetNumbersToPool, ensureTestPool } from '../services/lifecycle';

const A = adminRequired;


// Calling-code metadata used by the TXT importer. The longest matching prefix wins.
const PHONE_META: Array<[string, string, string]> = [
  ['1', '🇺🇸', 'United States / Canada'], ['7', '🇷🇺', 'Russia / Kazakhstan'],
  ['20', '🇪🇬', 'Egypt'], ['27', '🇿🇦', 'South Africa'], ['30', '🇬🇷', 'Greece'],
  ['31', '🇳🇱', 'Netherlands'], ['32', '🇧🇪', 'Belgium'], ['33', '🇫🇷', 'France'],
  ['34', '🇪🇸', 'Spain'], ['36', '🇭🇺', 'Hungary'], ['39', '🇮🇹', 'Italy'],
  ['40', '🇷🇴', 'Romania'], ['41', '🇨🇭', 'Switzerland'], ['43', '🇦🇹', 'Austria'],
  ['44', '🇬🇧', 'United Kingdom'], ['45', '🇩🇰', 'Denmark'], ['46', '🇸🇪', 'Sweden'],
  ['47', '🇳🇴', 'Norway'], ['48', '🇵🇱', 'Poland'], ['49', '🇩🇪', 'Germany'],
  ['51', '🇵🇪', 'Peru'], ['52', '🇲🇽', 'Mexico'], ['53', '🇨🇺', 'Cuba'],
  ['54', '🇦🇷', 'Argentina'], ['55', '🇧🇷', 'Brazil'], ['56', '🇨🇱', 'Chile'],
  ['57', '🇨🇴', 'Colombia'], ['58', '🇻🇪', 'Venezuela'], ['60', '🇲🇾', 'Malaysia'],
  ['61', '🇦🇺', 'Australia'], ['62', '🇮🇩', 'Indonesia'], ['63', '🇵🇭', 'Philippines'],
  ['64', '🇳🇿', 'New Zealand'], ['65', '🇸🇬', 'Singapore'], ['66', '🇹🇭', 'Thailand'],
  ['81', '🇯🇵', 'Japan'], ['82', '🇰🇷', 'South Korea'], ['84', '🇻🇳', 'Vietnam'],
  ['86', '🇨🇳', 'China'], ['90', '🇹🇷', 'Turkey'], ['91', '🇮🇳', 'India'],
  ['92', '🇵🇰', 'Pakistan'], ['93', '🇦🇫', 'Afghanistan'], ['94', '🇱🇰', 'Sri Lanka'],
  ['95', '🇲🇲', 'Myanmar'], ['98', '🇮🇷', 'Iran'], ['211', '🇸🇸', 'South Sudan'],
  ['212', '🇲🇦', 'Morocco'], ['213', '🇩🇿', 'Algeria'], ['216', '🇹🇳', 'Tunisia'],
  ['218', '🇱🇾', 'Libya'], ['220', '🇬🇲', 'Gambia'], ['221', '🇸🇳', 'Senegal'],
  ['222', '🇲🇷', 'Mauritania'], ['223', '🇲🇱', 'Mali'], ['224', '🇬🇳', 'Guinea'],
  ['225', '🇨🇮', 'Côte d’Ivoire'], ['226', '🇧🇫', 'Burkina Faso'], ['227', '🇳🇪', 'Niger'],
  ['228', '🇹🇬', 'Togo'], ['229', '🇧🇯', 'Benin'], ['230', '🇲🇺', 'Mauritius'],
  ['231', '🇱🇷', 'Liberia'], ['234', '🇳🇬', 'Nigeria'], ['237', '🇨🇲', 'Cameroon'],
  ['249', '🇸🇩', 'Sudan'], ['250', '🇷🇼', 'Rwanda'], ['251', '🇪🇹', 'Ethiopia'],
  ['252', '🇸🇴', 'Somalia'], ['253', '🇩🇯', 'Djibouti'], ['254', '🇰🇪', 'Kenya'],
  ['255', '🇹🇿', 'Tanzania'], ['256', '🇺🇬', 'Uganda'], ['257', '🇧🇮', 'Burundi'],
  ['258', '🇲🇿', 'Mozambique'], ['260', '🇿🇲', 'Zambia'], ['263', '🇿🇼', 'Zimbabwe'],
  ['264', '🇳🇦', 'Namibia'], ['265', '🇲🇼', 'Malawi'], ['266', '🇱🇸', 'Lesotho'],
  ['267', '🇧🇼', 'Botswana'], ['268', '🇸🇿', 'Eswatini'], ['269', '🇰🇲', 'Comoros'],
  ['971', '🇦🇪', 'United Arab Emirates'], ['972', '🇮🇱', 'Israel'], ['973', '🇧🇭', 'Bahrain'],
  ['974', '🇶🇦', 'Qatar'], ['975', '🇧🇹', 'Bhutan'], ['976', '🇲🇳', 'Mongolia'],
  ['977', '🇳🇵', 'Nepal'], ['992', '🇹🇯', 'Tajikistan'], ['993', '🇹🇲', 'Turkmenistan'],
  ['994', '🇦🇿', 'Azerbaijan'], ['995', '🇬🇪', 'Georgia'], ['996', '🇰🇬', 'Kyrgyzstan'],
  ['998', '🇺🇿', 'Uzbekistan'],
];

function detectPhoneMeta(number: string): { prefix: string; flag: string; country: string } {
  const d = number.replace(/\D/g, '').replace(/^00/, '');
  const hit = PHONE_META.filter(([p]) => d.startsWith(p)).sort((a, b) => b[0].length - a[0].length)[0];
  return hit ? { prefix: hit[0], flag: hit[1], country: hit[2] } : { prefix: d.slice(0, 3), flag: '🌐', country: 'Unknown' };
}

// ───────────────────────── dashboard ─────────────────────────

GET('admin.index', ['/admin/', '/admin'], A, async (c) => {
  const today = startOfUtcDay();
  const tomorrow = addDays(today, 1);
  const s = await db.one(
    `select (select count(*) from users) as total_users,
            (select count(*) from users where is_active) as active_users,
            (select count(*) from sms_numbers) as total_numbers,
            (select count(*) from sms_numbers where agent_id is null and client_id is null and is_active and status in ('available','reserved')) as free_numbers,
            (select count(*) from sms_ranges) as total_ranges,
            (select count(*) from sms_cdr) as total_cdr,
            (select count(*) from sms_cdr where created_at >= $1 and created_at < $2) as today_sms,
            (select count(*) from users where is_active and last_login >= $1 and last_login < $2) as active_today_users,
            (select count(*) from withdrawal_requests where status = 'pending') as pending_withdrawals,
            (select count(*) from providers where is_active) as active_providers,
            (select count(*) from providers where is_active and last_status = 'error') as failing_providers`,
    [today, tomorrow],
  );
  const top_users = await db.query(
    `select u.username, u.email, count(*) as code_count from sms_cdr c
     join users u on u.id = coalesce(c.client_id, c.user_id)
     where c.created_at >= $1 and c.created_at < $2 group by u.id, u.username, u.email order by count(*) desc limit 10`,
    [today, tomorrow],
  );
  const recent_news = await db.query(`select * from news where is_active order by created_at desc limit 5`);
  const limit_requests = await db.query(
    `select a.id, a.details, a.created_at, u.id as user_id, u.username from activity_logs a join users u on u.id = a.user_id
     where a.action = 'limit_increase_request' and a.created_at > now() - interval '14 days' order by a.created_at desc limit 10`,
  );
  for (const r of limit_requests) {
    const parts = String(r.details || '').split('|');
    r.range_id = Number(String(parts[0]).replace('range=', '')) || null;
    r.range_label = parts[1] || '';
    r.note = parts[2] || '';
  }
  render(c, 'admin/index.html', { stats: s, recent_news, top_users, limit_requests });
});

// ───────────────────────── users ─────────────────────────

const wrapUsers = (p: any) => ((p.items = p.items.map((r: any) => new UserView(r))), p);

GET('admin.users', '/admin/users', A, async (c) => {
  const w = new Where();
  const search = c.query.str('search');
  if (search) {
    const like = `%${likeEscape(search)}%`;
    w.add(`(u.username ilike ? or u.email ilike ? or coalesce(u.name,'') ilike ?)`, like, like, like);
  }
  const role = c.query.str('role');
  if (role) w.add('r.name = ?', role);
  const users = wrapUsers(await paginate(`${USER_SQL}${w.sql}`, w.params, 'u.created_at desc, u.id desc', c.query.int('page'), 25, 25));
  render(c, 'admin/users.html', { users, roles: await getRoles(), agents: await listAgents() });
});

GET('admin.export_users', '/admin/users/export', A, async (c) => {
  const rows = await db.query(`${USER_SQL} order by u.id`);
  const out: any[][] = [['id', 'username', 'email', 'name', 'company', 'country', 'contact', 'role', 'agent', 'is_active', 'api_enabled', 'sms_count', 'sms_limit', 'created_at', 'last_login']];
  for (const u of rows) {
    out.push([u.id, u.username, u.email, u.name || '', u.company || '', u.country || '', u.contact || '', u.role_name || '', u.agent_username || '', !!u.is_active, !!u.api_enabled, u.sms_count || 0, u.sms_limit || 0, u.created_at ? u.created_at.toISOString() : '', u.last_login ? u.last_login.toISOString() : '']);
  }
  c.download(toCsv(out), 'users_export.csv', 'text/csv; charset=utf-8');
});

function parseUserExport(text: string): Record<string, string>[] {
  const rows: Record<string, string>[] = [];
  const pats: Record<string, RegExp> = {
    username: /Username:\s*([^|\n]+)/i, role: /Role:\s*([^\n]+)/i, name: /Name:\s*([^|\n]*)/i, email: /Email:\s*([^|\n]+)/i, is_active: /Active:\s*([^\n]+)/i,
    agent: /Agent:\s*([^|\n]*)/i, company: /Company:\s*([^|\n]*)/i, country: /Country:\s*([^\n]+)/i, contact: /Contact:\s*([^|\n]*)/i, skype: /Skype:\s*([^\n]+)/i,
    sms_limit: /SMS count\/limit:\s*\d+\s*\/\s*(\d+)/i, api_enabled: /API enabled:\s*([^|\n]+)/i,
  };
  for (let block of text.split(/\n-{8,}\n?/)) {
    block = block.trim();
    if (!block || (!block.startsWith('USER EXPORT') && !block.includes('Username:'))) continue;
    const row: Record<string, string> = {};
    for (const [k, re] of Object.entries(pats)) {
      const m = block.match(re);
      if (m) {
        const v = m[1].trim();
        row[k] = ['none', 'null', '-'].includes(v.toLowerCase()) ? '' : v;
      }
    }
    if (row.username && row.email) rows.push(row);
  }
  return rows;
}

ANY('admin.import_users_backup', '/admin/users/import-backup', A, async (c) => {
  if (c.method !== 'POST') return render(c, 'admin/import_users_backup.html');
  const up = c.files['backup_file'];
  const back = () => c.redirect(urlFor('admin.import_users_backup'));
  if (!up || !up.filename) {
    c.flash('Please select a backup text file.', 'danger');
    return back();
  }
  let rows: Record<string, any>[];
  try {
    if (up.data.length > 2 * 1024 * 1024) throw new Error('The backup file must be smaller than 2 MB.');
    const text = up.data.toString('utf8').replace(/^﻿/, '');
    const st = text.trimStart();
    if (st.startsWith('USER EXPORT')) rows = parseUserExport(text);
    else if (st.startsWith('{') || st.startsWith('[')) {
      const payload = JSON.parse(text);
      rows = Array.isArray(payload) ? payload : payload.users || [];
    } else {
      const first = text.split(/\r?\n/, 1)[0];
      const delim = [',', ';', '\t', '|'].map((d) => [d, first.split(d).length] as const).sort((a, b) => b[1] - a[1])[0][0];
      const table = parseCsv(text, delim).filter((r) => r.some((x) => x.trim()));
      const head = table[0].map((h) => h.trim().toLowerCase());
      rows = table.slice(1).map((r) => Object.fromEntries(head.map((h, i) => [h, r[i] ?? ''])));
    }
  } catch (e: any) {
    c.flash(`Could not read the backup file: ${e.message}`, 'danger');
    return back();
  }
  if (!rows.length || rows.length > 1000) {
    c.flash('The file must contain between 1 and 1000 user records.', 'danger');
    return back();
  }
  const roles = new Map((await getRoles()).map((r) => [String(r.name).toLowerCase(), r]));
  let created = 0, updated = 0, skipped = 0;
  const generated: string[] = [];
  const errors: string[] = [];
  try {
    await tx(async (t) => {
      let idx = 1;
      for (const raw of rows) {
        idx++;
        const row: Record<string, string> = {};
        for (const [k, v] of Object.entries(raw)) if (k) row[String(k).trim().toLowerCase()] = v == null ? '' : String(v).trim();
        const username = row.username, email = (row.email || '').toLowerCase();
        if (!username || !email) { errors.push(`Row ${idx}: username and email are required.`); skipped++; continue; }
        const rn = (row.role || 'client').toLowerCase();
        const role = roles.get(rn) || roles.get(({ user: 'client', administrator: 'admin' } as any)[rn] || '');
        if (!role) { errors.push(`Row ${idx}: unknown role "${rn}".`); skipped++; continue; }
        const ex = await t.one(`select * from users where username = $1 or lower(email) = $2`, [username, email]);
        const active = !['0', 'false', 'no', 'inactive', 'blocked'].includes((row.is_active ?? 'true').toLowerCase());
        const apiOn = ['1', 'true', 'yes', 'enabled'].includes((row.api_enabled ?? 'false').toLowerCase());
        let agentId: number | null = null;
        if (row.agent) agentId = (await t.one(`select id from users where username = $1`, [row.agent]))?.id ?? null;
        let hash: string | null = row.password_hash || null;
        if (!hash && row.password) hash = await hashPassword(row.password);
        if (!hash && !ex) {
          const tmp = randomToken(9);
          hash = await bcrypt.hash(tmp, 10);
          generated.push(`${username}: ${tmp}`);
        }
        const lim = parseInt(row.sms_limit || '', 10);
        if (!ex) {
          await t.exec(
            `insert into users (username,email,password_hash,role_id,is_active,api_enabled,name,company,country,skype,contact,agent_id,sms_limit) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
            [username, email, hash, role.id, active, apiOn, row.name || null, row.company || null, row.country || null, row.skype || null, row.contact || null, agentId, Number.isFinite(lim) ? lim : 0],
          );
          created++;
        } else {
          await t.exec(
            `update users set email=$2, role_id=$3, is_active=$4, api_enabled=$5, api_token = case when $5 then api_token else null end,
               name=coalesce($6,name), company=coalesce($7,company), country=coalesce($8,country), skype=coalesce($9,skype), contact=coalesce($10,contact),
               agent_id=coalesce($11,agent_id), sms_limit=coalesce($12,sms_limit), password_hash=coalesce($13,password_hash) where id=$1`,
            [ex.id, email, role.id, active, apiOn, row.name || null, row.company || null, row.country || null, row.skype || null, row.contact || null, agentId, Number.isFinite(lim) ? lim : null, hash],
          );
          updated++;
        }
      }
    });
  } catch (e: any) {
    c.flash(`Import failed and no records were saved: ${e.message}`, 'danger');
    return back();
  }
  await logActivity(c.user.id, 'admin_import_users_backup', `Imported users backup: ${created} created, ${updated} updated, ${skipped} skipped`, c.ip);
  c.flash(`Backup imported: ${created} created, ${updated} updated, ${skipped} skipped.`, 'success');
  if (generated.length) c.flash('Generated passwords: ' + generated.join(' | '), 'warning');
  errors.slice(0, 10).forEach((e) => c.flash(e, 'warning'));
  c.redirect(urlFor('admin.users'));
});

GET('admin.view_user', '/admin/users/view/<int:user_id>', A, async (c) => {
  const user = await getUserById(c.params.user_id);
  if (!user) return abort(404);
  const owner = user.is_agent() ? 'agent_id' : 'client_id';
  const numbers = Number(await db.scalar(`select count(*) from sms_numbers where ${owner} = $1`, [user.id]));
  render(c, 'admin/user_view.html', { user, number_count: numbers });
});

const userForm = async (c: Ctx, user: any) => render(c, 'admin/user_form.html', { roles: await getRoles(), agents: await listAgents(), user });

ANY('admin.create_user', '/admin/users/create', A, async (c) => {
  if (c.method !== 'POST') return userForm(c, null);
  const f = c.form;
  const username = f.str('username'), email = f.str('email').toLowerCase(), password = f.get('password', '') as string;
  const fail = (m: string) => (c.flash(m, 'danger'), c.redirect(urlFor('admin.create_user')));
  if (!username || !email || !password) return fail('Username, email, and password are required.');
  if (password.length < 6) return fail('Password must be at least 6 characters.');
  if (await db.scalar(`select 1 from users where lower(username)=lower($1)`, [username])) return fail('Username already exists.');
  if (await db.scalar(`select 1 from users where lower(email)=$1`, [email])) return fail('Email already registered.');
  const role = await db.one(`select * from roles where id = $1`, [f.int('role_id')]);
  if (!role) return fail('Invalid role selected.');
  try {
    await db.exec(
      `insert into users (username,email,password_hash,role_id,name,company,country,agent_id,sms_limit,is_active) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,true)`,
      [username, email, await hashPassword(password), role.id, f.get('name'), f.get('company'), f.get('country'), f.int('agent_id') || null, f.int('sms_limit', 0) || 0],
    );
  } catch (e) {
    if (isUniqueViolation(e)) return fail('Username or email already exists.');
    throw e;
  }
  await logActivity(c.user.id, 'admin_create_user', `Created user ${username} with role ${role.display_name}`, c.ip);
  c.flash(`User ${username} created successfully.`, 'success');
  c.redirect(urlFor('admin.users'));
});

ANY('admin.edit_user', '/admin/users/<int:user_id>/edit', A, async (c) => {
  const user = await getUserById(c.params.user_id);
  if (!user) return abort(404);
  if (c.method !== 'POST') return userForm(c, user);
  const f = c.form;
  const back = () => c.redirect(urlFor('admin.edit_user', { user_id: user.id }));
  const email = f.str('email').toLowerCase();
  if (!email) { c.flash('Email is required.', 'danger'); return back(); }
  if (await db.scalar(`select 1 from users where lower(email)=$1 and id<>$2`, [email, user.id])) { c.flash('Email already registered by another user.', 'danger'); return back(); }
  const roleId = f.int('role_id') || user.role_id;
  const isActive = user.id === c.user.id ? true : f.has('is_active');
  if (user.id === c.user.id && roleId !== user.role_id) { c.flash('You cannot change your own role.', 'danger'); return back(); }
  const pw = f.get('password', '') as string;
  const hash = pw && pw.length >= 6 ? await hashPassword(pw) : null;
  if (pw && pw.length < 6) { c.flash('Password must be at least 6 characters.', 'danger'); return back(); }
  await db.exec(
    `update users set email=$2,name=$3,company=$4,country=$5,skype=$6,contact=$7,sms_limit=$8,agent_id=$9,role_id=$10,is_active=$11,password_hash=coalesce($12,password_hash), login_attempts=0, locked_until=null where id=$1`,
    [user.id, email, f.get('name'), f.get('company'), f.get('country'), f.get('skype'), f.get('contact'), f.int('sms_limit', 0) || 0, f.int('agent_id') || null, roleId, isActive, hash],
  );
  await logActivity(c.user.id, 'admin_edit_user', `Edited user ${user.username}`, c.ip);
  c.flash(`User ${user.username} updated.`, 'success');
  c.redirect(urlFor('admin.users'));
});

POST('admin.delete_user', '/admin/users/<int:user_id>/delete', A, async (c) => {
  const user = await getUserById(c.params.user_id);
  if (!user) return abort(404);
  if (user.id === c.user.id) { c.flash('Cannot delete your own account.', 'danger'); return c.redirect(urlFor('admin.users')); }
  try {
    await tx(async (t) => {
      // give the user's numbers back to the pool before removing the account
      const ids = (await t.query(`select id from sms_numbers where agent_id = $1 or client_id = $1`, [user.id])).map((r) => r.id);
      await resetNumbersToPool(t, ids);
      await t.exec(`update users set agent_id = null where agent_id = $1`, [user.id]);
      await t.exec(`delete from users where id = $1`, [user.id]);
    });
  } catch (e: any) {
    console.error('[delete_user]', e);
    c.flash('This user cannot be deleted because other records depend on it. Deactivate the account instead.', 'danger');
    return c.redirect(urlFor('admin.users'));
  }
  await logActivity(c.user.id, 'admin_delete_user', `Deleted user ${user.username}`, c.ip);
  c.flash(`User ${user.username} deleted.`, 'success');
  c.redirect(urlFor('admin.users'));
});

POST('admin.toggle_user_status', '/admin/users/<int:user_id>/toggle-status', A, async (c) => {
  const ajax = c.req.headers['x-requested-with'] === 'XMLHttpRequest' || String(c.req.headers.accept || '').includes('application/json');
  if (c.params.user_id === c.user.id) {
    if (ajax) return c.jsonOut({ error: 'Cannot toggle own status' }, 400);
    c.flash('You cannot block your own account.', 'danger');
    return c.redirect(urlFor('admin.users'));
  }
  const r = await db.one(`update users set is_active = not is_active where id = $1 returning is_active, username`, [c.params.user_id]);
  if (!r) return abort(404);
  await logActivity(c.user.id, 'admin_toggle_user', `${r.username} -> ${r.is_active ? 'active' : 'blocked'}`, c.ip);
  if (ajax) return c.jsonOut({ success: true, is_active: r.is_active });
  c.flash(`${r.username} is now ${r.is_active ? 'active' : 'blocked'}.`, 'success');
  c.redirect(c.form.get('back') === 'view' ? urlFor('admin.view_user', { user_id: c.params.user_id }) : urlFor('admin.users'));
});

/** Admin hands numbers to a user directly (random or in order). */
ANY('admin.add_numbers_to_user', '/admin/users/<int:user_id>/add-number', A, async (c) => {
  const user = await getUserById(c.params.user_id);
  if (!user) return abort(404);
  const role = user.role?.name;
  if (role !== 'agent' && role !== 'client') {
    c.flash('Numbers can only be assigned to agent or client users.', 'danger');
    return c.redirect(urlFor('admin.users'));
  }
  const back = () => c.redirect(urlFor('admin.add_numbers_to_user', { user_id: user.id }));
  if (c.method === 'POST') {
    const uploaded = c.files['numbers_file'];
    // TXT mode: detect country/prefix automatically, create/reuse ranges, and assign all numbers.
    if (uploaded?.data?.length) {
      if (uploaded.data.length > 8 * 1024 * 1024) { c.flash('The TXT file must be smaller than 8 MB.', 'danger'); return back(); }
      const nums = extractNumbers(uploaded.data.toString('utf8'), '');
      if (!nums.length) { c.flash('No valid phone numbers were found in the TXT file.', 'danger'); return back(); }
      try {
        const result = await tx(async (t) => {
          const groups = new Map<string, string[]>();
          for (const n of nums) { const meta = detectPhoneMeta(n); groups.set(meta.prefix, [...(groups.get(meta.prefix) || []), n]); }
          let assigned = 0, createdRanges = 0, skipped = 0;
          for (const [prefix, list] of groups) {
            const meta = detectPhoneMeta(list[0]);
            let range = await t.one(`select * from sms_ranges where prefix = $1 order by id limit 1`, [prefix]);
            if (!range) {
              range = await t.one(`insert into sms_ranges (name,prefix,country,memo,created_by,is_active) values ($1,$2,$3,$4,$5,true) returning *`,
                [`${meta.flag} ${meta.country} +${prefix}`, prefix, meta.country, 'Auto-created from TXT import', c.user.id]);
              createdRanges++;
            }
            const activeRange = range;
            if (!activeRange) throw new UserError(`Could not create or find range +${prefix}.`);
            const add = await addNumbersToRange(t, activeRange, list);
            skipped += add.skipped;
            const got = await allocateFromRange(t, { range: activeRange, role, ownerId: user.id, count: add.created, random: false });
            assigned += got.length;
            await ensureTestPool(t, activeRange);
          }
          return { assigned, createdRanges, skipped, groups: groups.size };
        });
        await logActivity(c.user.id, 'admin_import_txt_to_user', `Imported and assigned ${result.assigned} TXT numbers to ${user.username}`, c.ip);
        c.flash(`${result.assigned} numbers imported and assigned to ${user.username}. ${result.createdRanges} ranges created, ${result.skipped} duplicates skipped.`, 'success');
        return c.redirect(urlFor('admin.users'));
      } catch (e: any) { c.flash(`TXT import failed: ${e?.message || 'Unknown error'}`, 'danger'); return back(); }
    }
    const rangeId = c.form.int('range_id');
    const count = c.form.int('numbers_count', 0) || 0;
    if (!rangeId || count < 1) { c.flash('Select a range and enter a valid number of numbers.', 'danger'); return back(); }
    if (count > 10000) { c.flash('You can add a maximum of 10,000 numbers at a time.', 'danger'); return back(); }
    const random = c.form.get('mode') === 'random';
    try {
      const res = await tx(async (t) => {
        const range = await t.one(`select * from sms_ranges where id = $1 and is_active`, [rangeId]);
        if (!range) throw new UserError('Invalid or inactive range.');
        const got = await allocateFromRange(t, { range, role, ownerId: user.id, count, random });
        if (got.length < count) throw new UserError(`Only ${got.length} numbers are available in this range.`);
        return { range, got };
      });
      await logActivity(c.user.id, 'admin_add_numbers_to_user', `Assigned ${res.got.length} numbers from range ${res.range.prefix} to ${user.username}`, c.ip);
      c.flash(`${res.got.length} numbers added to ${user.username} successfully.`, 'success');
      return c.redirect(urlFor('admin.users'));
    } catch (e) {
      if (!(e instanceof UserError)) throw e;
      c.flash(e.message, 'warning');
      return back();
    }
  }
  const ranges = await db.query(`select * from sms_ranges where is_active order by country, prefix`);
  const current_numbers = Number(await db.scalar(`select count(*) from sms_numbers where ${role === 'agent' ? 'agent_id' : 'client_id'} = $1`, [user.id]));
  const av = await db.query(`select range_id, count(*) as n from sms_numbers where agent_id is null and client_id is null and is_active and status in ('available','reserved') group by range_id`);
  const available_counts: Record<string, number> = {};
  for (const r of av) available_counts[r.range_id] = r.n;
  render(c, 'admin/add_numbers_to_user.html', { user, ranges, current_numbers, available_counts: new PyDict(Object.entries(available_counts).map(([k, v]) => [Number(k), v])) });
});

// ───────────────────────── API access ─────────────────────────

ANY('admin.api_access', '/admin/api-access', A, async (c) => {
  if (c.method === 'POST') {
    const user = await getUserById(c.form.int('user_id') || 0);
    if (!user) return abort(404);
    const action = c.form.get('action', 'enable');
    if (user.is_admin() && (action === 'revoke' || action === 'disable')) c.flash('The administrator API access cannot be changed from this page.', 'danger');
    else if (action === 'revoke' || action === 'disable') {
      await db.exec(`update users set api_token = null, api_enabled = false where id = $1`, [user.id]);
      c.flash(`API access revoked for ${user.username}.`, 'success');
    } else {
      await db.exec(`update users set api_token = coalesce(api_token, $2), api_enabled = true where id = $1`, [user.id, randomToken(24)]);
      c.flash(`API access enabled for ${user.username}. Copy the new key from the table.`, 'success');
    }
    return c.redirect(urlFor('admin.api_access'));
  }
  const search = c.query.str('search');
  const w = new Where();
  if (search) { const l = `%${likeEscape(search)}%`; w.add('(u.username ilike ? or u.email ilike ?)', l, l); }
  const users = (await db.query(`${USER_SQL}${w.sql} order by u.username`, w.params)).map((r) => new UserView(r));
  // api_token is intentionally visible here (admin-only page); UserView keeps it
  render(c, 'admin/api_access.html', { users, search });
});

// ───────────────────────── activity / news / stats ─────────────────────────

GET('admin.activity_logs', '/admin/activity', A, async (c) => {
  const w = new Where();
  const uid = c.query.int('user');
  if (uid) w.add('user_id = ?', uid);
  const act = c.query.str('action');
  if (act) w.add('action = ?', act);
  const activities = await paginate(`select * from activity_logs${w.sql}`, w.params, 'created_at desc, id desc', c.query.int('page'), 50, 50);
  const { attachUsers } = await import('../models');
  await attachUsers(activities.items, 'user_id', 'user');
  const users = await db.query(`select id, username from users order by username`);
  render(c, 'admin/activity.html', { activities, users });
});

GET('admin.news', '/admin/news', A, async (c) => {
  const news_list = await paginate(`select * from news`, [], 'created_at desc, id desc', c.query.int('page'), 20, 20);
  render(c, 'admin/news.html', { news_list });
});
ANY('admin.create_news', '/admin/news/create', A, async (c) => {
  if (c.method !== 'POST') return render(c, 'admin/news_form.html', { news: null });
  const headline = c.form.str('headline');
  if (!headline) { c.flash('Headline is required.', 'danger'); return c.redirect(urlFor('admin.create_news')); }
  await db.exec(`insert into news (headline, content, created_by, is_active) values ($1,$2,$3,true)`, [headline, c.form.get('content'), c.user.id]);
  c.flash('News created.', 'success');
  c.redirect(urlFor('admin.news'));
});
ANY('admin.edit_news', '/admin/news/<int:news_id>/edit', A, async (c) => {
  const news = await db.one(`select * from news where id = $1`, [c.params.news_id]);
  if (!news) return abort(404);
  if (c.method !== 'POST') return render(c, 'admin/news_form.html', { news });
  await db.exec(`update news set headline=$2, content=$3, is_active=$4 where id=$1`, [news.id, c.form.str('headline') || news.headline, c.form.get('content'), c.form.has('is_active')]);
  c.flash('News updated.', 'success');
  c.redirect(urlFor('admin.news'));
});
POST('admin.delete_news', '/admin/news/<int:news_id>/delete', A, async (c) => {
  await db.exec(`delete from news where id = $1`, [c.params.news_id]);
  c.flash('News deleted.', 'success');
  c.redirect(urlFor('admin.news'));
});

GET('admin.agent_otp_stats', '/admin/agent-otp-stats', A, async (c) => {
  const today = startOfUtcDay();
  const rows = await db.query(
    `select u.id, u.username, u.name, u.email,
        count(o.id) filter (where o.received_at >= $1) as today,
        count(o.id) filter (where o.received_at >= $2) as week,
        count(o.id) filter (where o.received_at >= $3) as month,
        count(o.id) as total
     from users u join roles r on r.id = u.role_id and r.name = 'agent'
     left join sms_numbers n on n.agent_id = u.id
     left join otp_logs o on o.number_id = n.id
     group by u.id order by count(o.id) desc, u.username`,
    [today, addDays(today, -7), new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1))],
  );
  const stats = rows.map((r) => ({ agent: { id: r.id, username: r.username, name: r.name, email: r.email }, today: r.today, week: r.week, month: r.month, total: r.total }));
  render(c, 'admin/agent_otp_stats.html', { stats });
});
