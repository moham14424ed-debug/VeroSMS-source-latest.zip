#!/usr/bin/env python3
"""Production entry point for the legacy Flask application.

The application factory owns database initialization, roles, and safe migrations.
This runner only creates the app and starts Flask on Render's assigned port.
"""

from __future__ import annotations

import logging
import os
import sys

from app import create_app


logger = logging.getLogger("verosms")
logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)


def _port() -> int:
    """Return Render's PORT, with a local-development fallback."""
    raw_port = os.environ.get("PORT", "5050").strip()
    try:
        port = int(raw_port)
    except ValueError as exc:
        raise RuntimeError(f"Invalid PORT value: {raw_port!r}") from exc
    if not 1 <= port <= 65535:
        raise RuntimeError(f"PORT must be between 1 and 65535, got {port}")
    return port


def main() -> None:
    config_name = os.environ.get("FLASK_CONFIG", "production").strip() or "production"
    port = _port()

    logger.info("Starting VeroSMS Flask application")
    logger.info("FLASK_CONFIG=%s PORT=%s", config_name, port)

    # create_app performs the database initialization and safe migrations.
    # Keep this outside a broad try/except so Render receives the real traceback
    # if a required environment variable or database connection is invalid.
    application = create_app(config_name)

    application.run(
        host="0.0.0.0",
        port=port,
        debug=False,
        threaded=True,
        use_reloader=False,
    )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Shutdown requested")
    except Exception:
        logger.exception("Flask startup failed")
        sys.exit(1)
